import Contact from "../models/Contact.js";
import sendEmail from "../utils/sendEmail.js";
import sendWhatsApp from "../utils/sendWhatsApp.js";

export const submitContactForm = async (req, res) => {
  try {
    const { name, email, phone, message } = req.body;

    if (!name || !email || !phone || !message) {
      return res.status(400).json({
        message: "All fields are required",
      });
    }

    const contact = await Contact.create({
      name,
      email,
      phone,
      message,
    });

    await sendEmail({
      to: process.env.ADMIN_EMAIL,
      subject: "New Contact Form Submission",
      html: `
        <h2>New Contact Request</h2>

        <p><strong>Name:</strong> ${name}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Phone:</strong> ${phone}</p>
        <p><strong>Message:</strong></p>

        <p>${message}</p>
      `,
    });

    await sendEmail({
      to: email,
      subject: "We've Received Your Message",
      html: `
  <div style="font-family:Arial,sans-serif;padding:30px;">
    <h2 style="color:#7b3ff2;">
      Thank You For Contacting MyFamilyAnchor
    </h2>

    <p>Hi ${name},</p>

    <p>
      We have received your message and our team
      will get back to you shortly.
    </p>

    <div style="
      background:#f8f3ff;
      padding:15px;
      border-radius:10px;
      margin-top:20px;
    ">
      <strong>Your Message</strong>

      <p>${message}</p>
    </div>

    <p style="margin-top:20px;">
      Regards,<br/>
      MyFamilyAnchor Team
    </p>
  </div>
  `,
    });

    await sendWhatsApp({
      to: process.env.ADMIN_WHATSAPP_NUMBER,
      messageData: `
📩 New Contact Request

👤 Name: ${name}

📧 Email: ${email}

📱 Phone: ${phone}

💬 Message:
${message}
      `,
    });

    await sendWhatsApp({
      to: phone,
      messageData: `
✅ Message Received

Hi ${name},

Thank you for contacting MyFamilyAnchor.

We have received your message and our team will respond shortly.

💬 "${message}"

– MyFamilyAnchor
`,
    });

    return res.status(201).json({
      success: true,
      message: "Message sent successfully",
      contactId: contact._id,
    });
  } catch (error) {
    // console.error("Contact form error:", error);
    console.error("CONTACT ERROR");
    console.error(error);
    console.error(error.message);

    return res.status(500).json({
      success: false,
      message: error.message,
      //   message: "Unable to send message right now",
    });
  }
};

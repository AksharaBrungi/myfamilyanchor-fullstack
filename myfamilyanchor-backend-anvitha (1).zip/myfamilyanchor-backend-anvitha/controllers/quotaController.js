import QuotaUsage from "../models/QuotaUsage.js";
import { INCLUDED_QUOTAS } from "../constants/planQuotas.js";
import { getCurrentCycleBounds } from "../services/quotaService.js";

export const getMyQuotaUsage = async (req, res) => {
  try {
    const user = req.user;
    const planQuotas = INCLUDED_QUOTAS[user.currentPlan] || {};
    const cycle = getCurrentCycleBounds(user);

    if (!cycle) {
      return res.status(200).json({
        cycleStart: null,
        cycleEnd: null,
        services: [],
      });
    }

    const usageDocs = await QuotaUsage.find({
      user: user._id,
      cycleStart: cycle.start,
    });

    const usageByService = Object.fromEntries(
      usageDocs.map((d) => [d.serviceType, d.usedCount]),
    );

    const services = Object.entries(planQuotas).map(([serviceType, limit]) => ({
      serviceType,
      limit, // null = unlimited
      used: usageByService[serviceType] || 0,
      remaining:
        limit === null
          ? null
          : Math.max(limit - (usageByService[serviceType] || 0), 0),
    }));

    res.status(200).json({
      cycleStart: cycle.start,
      cycleEnd: cycle.end,
      services,
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

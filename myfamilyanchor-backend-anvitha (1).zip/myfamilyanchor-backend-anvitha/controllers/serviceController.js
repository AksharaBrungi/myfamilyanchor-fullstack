import ServiceRequest from "../models/ServiceRequest.js";
import Staff from "../models/Staff.js";
import Vendor from "../models/vendor.js";
import sendEmail from "../utils/sendEmail.js";
import sendWhatsApp from "../utils/sendWhatsApp.js";
import { getIO } from "../socket/socket.js";
import {
  findServiceEntry,
  getAllowedCategories,
} from "../constants/serviceCatalog.js";
import {
  checkAndConsumeQuota,
  releaseQuota,
} from "../services/quotaService.js";

export const createRequest = async (req, res) => {
  try {
    const user = req.user;

    const allowedCategories = getAllowedCategories(user.currentPlan);

    if (!allowedCategories.includes(req.body.category)) {
      return res.status(403).json({
        message: "Your plan does not support this service category",
      });
    }

    const serviceEntry = findServiceEntry(
      user.currentPlan,
      req.body.category,
      req.body.serviceType,
    );

    if (!serviceEntry) {
      return res.status(403).json({
        message: "This service is not available on your current plan",
      });
    }

    let quotaResult = null;

    if (serviceEntry.type === "included") {
      quotaResult = await checkAndConsumeQuota({
        user,
        planName: user.currentPlan,
        serviceType: req.body.serviceType,
        category: req.body.category,
      });

      if (!quotaResult.allowed) {
        if (quotaResult.reason === "no-active-cycle") {
          return res.status(403).json({
            message:
              "Your subscription cycle isn't active. Please contact support.",
          });
        }

        return res.status(403).json({
          message: `You've used all ${quotaResult.limit} included "${req.body.serviceType}" requests for this cycle (resets ${quotaResult.cycleEnd?.toLocaleDateString("en-IN")}). Contact support to arrange this as an additional paid visit.`,
        });
      }
    }

    const request = await ServiceRequest.create({
      user: req.user._id,

      serviceType: req.body.serviceType,

      category: req.body.category,

      serviceCategory: serviceEntry.type,

      quote: {
        status: serviceEntry.type === "on_demand" ? "pending" : "not_required",
      },

      quotaConsumed: !!(quotaResult && !quotaResult.unlimited),
      quotaCycleStart: quotaResult?.cycleStart,

      description: req.body.description,

      address: req.body.address,

      preferredDate: req.body.preferredDate,

      priority: req.body.priority || "normal",
    });

    try {
      getIO().emit("new-service-request", request);

      getIO().emit("request-updated", {
        type: "created",
        request,
      });
    } catch (socketError) {
      console.log("Socket error:", socketError.message);
    }

    await sendEmail({
      to: process.env.ADMIN_EMAIL,

      subject: "New Service Request Submitted",

      html: `
  <h2>New Service Request</h2>

  <p><strong>Customer:</strong> ${req.user.name}</p>

  <p><strong>Email:</strong> ${req.user.email}</p>

  <p><strong>Service:</strong> ${request.serviceType}</p>

  <p><strong>Category:</strong> ${request.category}</p>

  <p><strong>Address:</strong> ${request.address}</p>

  <p><strong>Priority:</strong> ${request.priority}</p>

  <p><strong>Description:</strong></p>

  <p>${request.description}</p>
  `,
    });

    try {
      await sendEmail({
        to: req.user.email,

        subject: "Service Request Received",

        html: `
      <div style="
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        padding: 40px 20px;
      ">
        <div style="
          max-width: 700px;
          margin: auto;
          background: #ffffff;
          padding: 40px;
          border-radius: 10px;
          box-shadow: 0 0 10px rgba(0,0,0,0.08);
        ">

          <h1 style="
            color: #8b7cf6;
            margin-bottom: 30px;
          ">
            Service Request Received ✅
          </h1>

          <p style="font-size:16px;">
            Hi ${req.user.name || "User"},
          </p>

          <p style="
            font-size:16px;
            line-height:1.6;
          ">
            Your service request has been successfully submitted.
            Our team will review it shortly.
          </p>

          <hr style="margin:30px 0;" />

          <h3 style="color:#333;">
            Request Details
          </h3>

          <p>
            <strong>Service Type:</strong>
            ${request.serviceType}
          </p>

          <p>
            <strong>Category:</strong>
            ${request.category}
          </p>

          <p>
            <strong>Description:</strong>
            ${request.description}
          </p>

          <p>
            <strong>Address:</strong>
            ${request.address}
          </p>

          <p>
            <strong>Preferred Date:</strong>
            ${new Date(request.preferredDate).toLocaleDateString("en-IN")}
          </p>

          <hr style="margin:30px 0;" />

          <h3 style="color:#333;">
            Request Status
          </h3>

          <p>
            <strong>Status:</strong>
            Pending Review
          </p>

          <p>
            <strong>Request Created:</strong>
            ${new Date().toLocaleString("en-IN", {
              timeZone: "Asia/Kolkata",
            })}
          </p>

          <hr style="margin:30px 0;" />

          <p style="
            margin-top:30px;
            font-size:14px;
            color:#777;
          ">
            Thank you for choosing MyFamilyAnchor ❤️
          </p>

        </div>
      </div>
      `,
      });
    } catch (err) {
      console.error("Email failed:", err.message);
    }

    // if (request.priority === "emergency" && process.env.ADMIN_PHONE) {
    //   try {
    //     await sendWhatsApp({
    //       to: process.env.ADMIN_PHONE,
    //       messageData: `
    // 🚨 Emergency Request

    // Service: ${request.serviceType}
    // Customer: ${req.user.name}
    // Email: ${req.user.email}
    // Address: ${request.address}
    // `,
    //     });
    //   } catch (err) {
    //     console.error("Emergency WhatsApp failed:", err.message);
    //   }
    // }

    await sendWhatsApp({
      to: process.env.ADMIN_WHATSAPP_NUMBER,

      messageData: `
🛠 New Service Request

👤 ${req.user.name}
📧 ${req.user.email}

🏠 ${request.serviceType}

📍 ${request.address}

⚠ Priority: ${request.priority}
`,
    });

    await sendWhatsApp({
      to: req.user.phone,

      messageData: `
✅ Service Request Received

Service:
${request.serviceType}

Category:
${request.category}

Status:
Pending Review

Our team will review and assign your request shortly.

– MyFamilyAnchor
`,
    });

    res.status(201).json(request);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

export const getUserRequests = async (req, res) => {
  try {
    const requests = await ServiceRequest.find({
      user: req.user._id,
    }).sort({
      createdAt: -1,
    });

    res.status(200).json(requests);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

export const getAllRequests = async (req, res) => {
  try {
    const requests = await ServiceRequest.find()
      .populate("user", "name email")
      .sort({
        createdAt: -1,
      });

    res.status(200).json(requests);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

export const cancelRequest = async (req, res) => {
  try {
    const request = await ServiceRequest.findOne({
      _id: req.params.id,
      user: req.user._id,
    });

    if (!request) {
      return res.status(404).json({
        message: "Request not found",
      });
    }

    if (["completed", "cancelled"].includes(request.status)) {
      return res.status(400).json({
        message: "This request cannot be cancelled",
      });
    }

    const hasBeforePhotos = (request.jobPhotos || []).some(
      (p) => p.photoType === "before",
    );
    if (hasBeforePhotos) {
      return res.status(400).json({
        message:
          "Work has already started on this request (before photos uploaded), so it cannot be cancelled.",
      });
    }

    if (request.quote?.status === "paid") {
      return res.status(400).json({
        message:
          "This request has been paid for. Contact support to cancel and process a refund.",
      });
    }

    request.status = "cancelled";
    request.completionPercentage = 0;
    request.auditLogs.push({
      action: "Service cancelled by user",
      actor: "User",
    });

    await request.save();

    if (request.quotaConsumed && request.quotaCycleStart) {
      await releaseQuota({
        user: req.user,
        serviceType: request.serviceType,
        cycleStart: request.quotaCycleStart,
      });
      request.quotaConsumed = false;
      await request.save();
    }

    getIO().emit("request-updated", {
      type: "cancelled",
      request,
    });

    res.status(200).json(request);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

export const editRequestService = async (req, res) => {
  try {
    const {
      category,
      serviceType,
      description,
      address,
      preferredDate,
      priority,
    } = req.body;

    if (
      !category ||
      !serviceType ||
      !description ||
      !address ||
      !preferredDate
    ) {
      return res.status(400).json({
        message: "Service request details are required",
      });
    }

    const allowedCategories = getAllowedCategories(req.user.currentPlan);

    if (!allowedCategories.includes(category)) {
      return res.status(403).json({
        message: "Your plan does not support this service category",
      });
    }

    const serviceEntry = findServiceEntry(
      req.user.currentPlan,
      category,
      serviceType,
    );

    if (!serviceEntry) {
      return res.status(403).json({
        message: "This service is not available on your current plan",
      });
    }

    const request = await ServiceRequest.findOne({
      _id: req.params.id,
      user: req.user._id,
    });

    if (!request) {
      return res.status(404).json({
        message: "Request not found",
      });
    }

    if (["completed", "cancelled"].includes(request.status)) {
      return res.status(400).json({
        message: "This request cannot be edited",
      });
    }

    const hasBeforePhotos = (request.jobPhotos || []).some(
      (p) => p.photoType === "before",
    );
    if (hasBeforePhotos) {
      return res.status(400).json({
        message:
          "Work has already started on this request (before photos uploaded), so it cannot be edited.",
      });
    }

    if (["approved", "paid"].includes(request.quote?.status)) {
      return res.status(400).json({
        message:
          "This request has an approved/paid quote and cannot be edited. Cancel it and submit a new request instead.",
      });
    }

    request.auditLogs.push({
      action: "Service request edited by user",
      actor: "User",
    });

    const serviceTypeChanged = request.serviceType !== serviceType;

    if (serviceTypeChanged) {
      let quotaResult = null;

      // Consume the NEW quota first. Only release the old one once this
      // succeeds — avoids leaving the user with neither if something fails.
      if (serviceEntry.type === "included") {
        quotaResult = await checkAndConsumeQuota({
          user: req.user,
          planName: req.user.currentPlan,
          serviceType,
          category,
        });

        if (!quotaResult.allowed) {
          return res.status(403).json({
            message:
              quotaResult.reason === "no-active-cycle"
                ? "Your subscription cycle isn't active. Please contact support."
                : `You've used all ${quotaResult.limit} included "${serviceType}" requests for this cycle. Contact support to arrange this as an additional paid visit.`,
          });
        }
      }

      if (request.quotaConsumed && request.quotaCycleStart) {
        await releaseQuota({
          user: req.user,
          serviceType: request.serviceType,
          cycleStart: request.quotaCycleStart,
        });
      }

      request.quotaConsumed = !!(quotaResult && !quotaResult.unlimited);
      request.quotaCycleStart = quotaResult?.cycleStart;

      // Service type changed, so any prior quote no longer applies to the
      // new service — reset it rather than leaving a stale price attached.
      request.quote = {
        status: serviceEntry.type === "on_demand" ? "pending" : "not_required",
      };
    }

    request.serviceType = serviceType;
    request.category = category;
    request.serviceCategory = serviceEntry.type;
    request.description = description;
    request.address = address;
    request.preferredDate = preferredDate;
    request.priority = priority || request.priority;

    await request.save();

    getIO().emit("request-updated", {
      type: "edited",
      request,
    });

    res.status(200).json(request);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

export const updateRequestStatus = async (req, res) => {
  try {
    const request = await ServiceRequest.findById(req.params.id);

    if (!request) {
      return res.status(404).json({
        message: "Request not found",
      });
    }

    const oldStatus = request.status;

    if (req.body.status && req.body.status !== oldStatus) {
      request.auditLogs.push({
        action: `Status changed to ${req.body.status}`,
      });
    }

    request.status = req.body.status || request.status;

    if (request.status === "pending") {
      request.completionPercentage = 10;
    }

    if (request.status === "in-progress") {
      request.completionPercentage = 50;
    }

    if (request.status === "completed") {
      request.completionPercentage = 100;
    }

    request.assignedTo = req.body.assignedTo || request.assignedTo;

    request.adminNotes = req.body.adminNotes || request.adminNotes;

    await request.save();

    getIO().emit("request-updated", {
      type: "status",
      request,
    });

    getIO().emit("activity-feed", {
      id: Date.now(),

      type: "request",

      message: `Request moved to ${request.status}`,

      time: new Date().toLocaleTimeString(),
    });

    await request.populate("user");

    try {
      if (request.user?.phone) {
        await sendWhatsApp({
          to: request.user.phone,
          messageData: `
    📢 Service Update

    Service: ${request.serviceType}

    Status: ${request.status}

    Thank you,
    MyFamilyAnchor
    `,
        });
      }
    } catch (err) {
      console.error("WhatsApp failed:", err.message);
    }

    res.status(200).json(request);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

export const updateRequestMeta = async (req, res) => {
  try {
    const { assignedTo, assignedVendor, adminNotes } = req.body;

    const request = await ServiceRequest.findById(req.params.id);

    if (!request) {
      return res.status(404).json({
        message: "Request not found",
      });
    }

    if (assignedTo && assignedTo !== request.assignedTo) {
      request.auditLogs.push({
        action: `Assigned to ${assignedTo}`,
      });
    }

    if (adminNotes && adminNotes !== request.adminNotes) {
      request.auditLogs.push({
        action: "Admin notes updated",
      });
    }

    if (assignedTo) {
      const staff = await Staff.findById(assignedTo);

      if (!staff) {
        return res.status(404).json({
          message: "Staff member not found",
        });
      }

      request.assignedTo = staff.name;
      request.assignedStaffId = staff._id;
    }

    if (assignedVendor) {
      const vendor = await Vendor.findById(assignedVendor);

      if (!vendor) {
        return res.status(404).json({
          message: "Vendor not found",
        });
      }

      request.assignedVendor = vendor.businessName;
      request.assignedVendorId = vendor._id;

      request.auditLogs.push({
        action: `Vendor assigned: ${vendor.businessName}`,
      });
    }

    request.adminNotes = adminNotes;

    await request.save();

    getIO().emit("request-updated", {
      type: "assignment",
      request,
    });

    getIO().emit("activity-feed", {
      id: Date.now(),

      type: "assignment",

      message: `Assigned to ${assignedTo}`,

      time: new Date().toLocaleTimeString(),
    });

    res.json(request);
  } catch (error) {
    res.status(500).json({
      message: "Failed to update request",
    });
  }
};

export const addComment = async (req, res) => {
  try {
    const { message } = req.body;

    if (!message?.trim()) {
      return res.status(400).json({
        message: "Comment required",
      });
    }

    const request = await ServiceRequest.findById(req.params.id);

    if (!request) {
      return res.status(404).json({
        message: "Request not found",
      });
    }

    request.comments.push({
      message: message.trim(),
    });

    request.auditLogs.push({
      action: `Comment added`,
    });

    await request.save();

    getIO().emit("activity-feed", {
      id: Date.now(),

      type: "comment",

      message: "Internal comment added",

      time: new Date().toLocaleTimeString(),
    });

    res.json(request);
  } catch (error) {
    res.status(500).json({
      message: "Failed to add comment",
    });
  }
};

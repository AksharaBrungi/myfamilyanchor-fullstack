import Subscriber from "../models/Subscriber.js";

export const subscribe = async (req, res) => {
  const { email } = req.body;

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (!email || !emailRegex.test(email)) {
    return res.status(400).json({
      message: "Valid email required",
    });
  }

  try {
    const existing = await Subscriber.findOne({
      email,
    });

    if (existing) {
      return res.status(400).json({
        message: "Already subscribed!",
      });
    }

    await Subscriber.create({
      email,
    });

    res.status(201).json({
      message: "Subscribed successfully!",
    });
  } catch (error) {
    console.error("Subscribe Error:", error);

    res.status(500).json({
      message: "Unable to subscribe right now",
    });
  }
};

export const getSubscribers = async (req, res) => {
  try {
    const subscribers = await Subscriber.find().sort({ subscribedAt: -1 });

    res.json(subscribers);
  } catch (error) {
    res.status(500).json({
      message: "Failed to load subscribers",
    });
  }
};

export const deactivateSubscriber = async (req, res) => {
  try {
    const subscriber = await Subscriber.findByIdAndUpdate(
      req.params.id,
      {
        isActive: false,
      },
      {
        new: true,
      },
    );

    if (!subscriber) {
      return res.status(404).json({
        message: "Subscriber not found",
      });
    }

    res.json({
      success: true,
      message: "Subscriber deactivated",
    });
  } catch (error) {
    res.status(500).json({
      message: "Failed to deactivate subscriber",
    });
  }
};

export const activateSubscriber = async (req, res) => {
  try {
    const subscriber = await Subscriber.findByIdAndUpdate(
      req.params.id,
      {
        isActive: true,
      },
      {
        new: true,
      },
    );

    if (!subscriber) {
      return res.status(404).json({
        message: "Subscriber not found",
      });
    }

    res.json({
      success: true,
      message: "Subscriber activated",
    });
  } catch (error) {
    res.status(500).json({
      message: "Failed to activate subscriber",
    });
  }
};

export const deleteSubscriber = async (req, res) => {
  try {
    const subscriber = await Subscriber.findByIdAndDelete(req.params.id);

    if (!subscriber) {
      return res.status(404).json({
        message: "Subscriber not found",
      });
    }

    res.json({
      success: true,
      message: "Subscriber deleted",
    });
  } catch (error) {
    res.status(500).json({
      message: "Failed to delete subscriber",
    });
  }
};

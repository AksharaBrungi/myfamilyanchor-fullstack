import User from "../models/User.js";
import Payment from "../models/Payment.js";

export const getDashboardData = async (req, res) => {
  try {
    // authMiddleware now sets req.user as the full user object (with _id).
    if (!req.user?._id) {
      return res.status(401).json({ message: "Not authorized" });
    }

    const [user, payments] = await Promise.all([
      User.findById(req.user._id).select("-password"),
      Payment.find({ user: req.user._id }).sort({ createdAt: -1 }),
    ]);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    res.status(200).json({ user, payments });
  } catch (error) {
    console.error("getDashboardData error:", error);
    res.status(500).json({ message: "Server error fetching dashboard" });
  }
};

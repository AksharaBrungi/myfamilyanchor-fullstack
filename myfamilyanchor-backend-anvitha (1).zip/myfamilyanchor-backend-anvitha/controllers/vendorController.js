import bcrypt from "bcryptjs";
import Vendor from "../models/vendor.js";
import ServiceRequest from "../models/ServiceRequest.js";
import VendorCategory from "../models/vendorCategory.js";
import { getIO } from "../socket/socket.js";

export const createVendor = async (req, res) => {
  try {
    const tempPassword = "Vendor@123";

    const hashedPassword = await bcrypt.hash(tempPassword, 10);

    const vendor = await Vendor.create({
      ...req.body,
      password: hashedPassword,
    });

    res.status(201).json({
      ...vendor.toObject(),
      temporaryPassword: tempPassword,
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

export const getAllVendors = async (req, res) => {
  try {
    const vendors = await Vendor.find().sort({
      createdAt: -1,
    });

    res.json(vendors);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

export const updateVendor = async (req, res) => {
  try {
    const vendor = await Vendor.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });

    res.json(vendor);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

export const deleteVendor = async (req, res) => {
  try {
    await Vendor.findByIdAndDelete(req.params.id);

    res.json({
      success: true,
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

export const createCategory = async (req, res) => {
  try {
    const category = await VendorCategory.create({
      name: req.body.name,
      description: req.body.description,
    });

    res.status(201).json(category);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

export const getCategories = async (req, res) => {
  try {
    const categories = await VendorCategory.find({
      active: true,
    }).sort({
      name: 1,
    });

    res.json(categories);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

export const seedCategories = async (req, res) => {
  try {
    await VendorCategory.insertMany([
      {
        name: "Plumber",
        description: "Home plumbing services",
      },
      {
        name: "Electrician",
        description: "Electrical maintenance and repairs",
      },
      {
        name: "Gardener",
        description: "Garden maintenance",
      },
      {
        name: "Caretaker",
        description: "Elder care services",
      },
      {
        name: "Medical Assistant",
        description: "Medical support services",
      },
      {
        name: "Driver",
        description: "Transportation services",
      },
      {
        name: "Cook",
        description: "Meal preparation services",
      },
      {
        name: "Cleaner",
        description: "Cleaning services",
      },
      {
        name: "Painter",
        description: "Painting services",
      },
      {
        name: "Security",
        description: "Security services",
      },
    ]);

    res.json({
      success: true,
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

export const getAssignedVendorJobs = async (req, res) => {
  try {
    const jobs = await ServiceRequest.find({
      assignedVendorId: req.vendor._id,
    })
      .populate("user", "name email phone")
      .sort({
        createdAt: -1,
      });

    res.json(jobs);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

export const addVendorNote = async (req, res) => {
  try {
    const request = await ServiceRequest.findById(req.params.id);

    if (!request) {
      return res.status(404).json({
        message: "Request not found",
      });
    }

    request.vendorNotes.push({
      note: req.body.note,
      vendorId: req.vendor._id,
    });

    request.auditLogs.push({
      action: "Vendor note added",
      actor: "Vendor",
    });

    await request.save();

    getIO().emit("request-updated", {
      type: "vendor-note",
      request,
    });

    res.json(request);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

export const uploadJobPhotos = async (req, res) => {
  try {
    const request = await ServiceRequest.findById(req.params.id);

    if (!request) {
      return res.status(404).json({
        message: "Request not found",
      });
    }

    const photoType = req.body.photoType || "before";

    // For on-demand jobs, "before" photos mean work is starting — gate
    // that on payment actually having landed. Included services and any
    // later photoType (after/completion) on an already-paid job pass
    // through untouched.
    if (
      request.serviceCategory === "on_demand" &&
      photoType === "before" &&
      request.quote.status !== "paid"
    ) {
      return res.status(400).json({
        message: `Payment must be completed before work begins (current quote status: "${request.quote.status}")`,
      });
    }

    const photos = req.files.map((file) => ({
      url: file.path,

      photoType,

      uploadedBy: "Vendor",
    }));

    request.jobPhotos.push(...photos);

    request.auditLogs.push({
      action: `${photos.length} photos uploaded`,
      actor: "Vendor",
    });

    await request.save();

    res.json(request);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

export const requestCompletion = async (req, res) => {
  try {
    const request = await ServiceRequest.findById(req.params.id);

    if (!request) {
      return res.status(404).json({
        message: "Request not found",
      });
    }

    const beforePhotos = request.jobPhotos.filter(
      (p) => p.photoType === "before",
    );

    const afterPhotos = request.jobPhotos.filter(
      (p) => p.photoType === "after",
    );

    if (!beforePhotos.length || !afterPhotos.length) {
      return res.status(400).json({
        message:
          "Before and After photos are required before requesting completion",
      });
    }

    request.verificationStatus = "submitted";
    request.auditLogs.push({
      action: "Waiting for staff verification",
      actor: "System",
    });

    request.completionPercentage = 90;

    request.auditLogs.push({
      action: "Completion submitted by vendor",
      actor: "Vendor",
    });

    await request.save();

    res.json(request);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

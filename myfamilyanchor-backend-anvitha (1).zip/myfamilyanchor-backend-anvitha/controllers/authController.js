import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { validationResult } from "express-validator";
import User from "../models/User.js";

const PASSWORD_REGEX =
  /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#^()_+\-=[\]{};':"\\|,.<>/?]).{8,}$/;

export const registerUser = async (req, res) => {
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const { name, password, phone } = req.body;

    const email = req.body.email.toLowerCase().trim();

    const existingEmail = await User.findOne({ email });

    if (existingEmail) {
      return res.status(400).json({
        message: "Email already registered",
      });
    }

    const existingPhone = await User.findOne({ phone });

    if (existingPhone) {
      return res.status(400).json({
        message: "Phone number already registered",
      });
    }

    if (!/^\+\d{10,15}$/.test(phone)) {
      return res.status(400).json({
        message:
          "Phone number must be in international format. Example: +919505227777",
      });
    }

    if (!PASSWORD_REGEX.test(password)) {
      return res.status(400).json({
        message:
          "Password must contain at least 8 characters, one uppercase letter, one lowercase letter, one number and one special character",
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = await User.create({
      name,
      email,
      password: hashedPassword,
      phone,
    });

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: "1d",
    });

    res.status(201).json({
      success: true,
      token,
      message: "Account created successfully. Continue to payment.",
      user: {
        _id: user._id,
        name: user.name,
        email: user.email,
      },
    });
  } catch (error) {
    console.error("registerUser error:", error);

    if (error.code === 11000) {
      const field = Object.keys(error.keyPattern)[0];

      return res.status(400).json({
        message: `${field} already exists`,
      });
    }

    res.status(500).json({
      message: "Server error during registration",
    });
  }
};

export const loginUser = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const { password, identifier } = req.body;

    const normalizedIdentifier = identifier.trim().toLowerCase();

    let phoneVariants = [];

    if (/^\d{10}$/.test(identifier.trim())) {
      phoneVariants.push(`+91${identifier.trim()}`);
    }

    phoneVariants.push(identifier.trim());

    const user = await User.findOne({
      $or: [{ email: normalizedIdentifier }, { phone: { $in: phoneVariants } }],
    });

    // Use the same generic message for missing user AND wrong password
    if (!user) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    // Was returning 403 with no token — frontend couldn't recover to checkout.
    if (!user.paymentCompleted) {
      const pendingToken = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
        expiresIn: "1d",
      });
      return res.status(403).json({
        requiresPayment: true,
        message: "Complete payment before accessing dashboard",
        token: pendingToken, // needed so frontend can reach /checkout
        user: {
          _id: user._id,
          name: user.name,
          email: user.email,
        },
      });
    }

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: "7d",
    });

    const safeUser = {
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
    };

    res.status(200).json({ token, user: safeUser });
  } catch (error) {
    console.error("loginUser error:", error);
    res.status(500).json({ message: "Server error during login" });
  }
};

export const updateProfile = async (req, res) => {
  try {
    const { name, email, phone } = req.body;

    const user = await User.findById(req.user._id);

    if (!user) {
      return res.status(404).json({
        message: "User not found",
      });
    }

    // Update name only if provided
    if (name !== undefined) {
      if (!name.trim()) {
        return res.status(400).json({
          message: "Name cannot be empty",
        });
      }

      user.name = name.trim();
    }

    // Update email only if provided
    if (email !== undefined) {
      const normalizedEmail = email.trim().toLowerCase();

      if (!/\S+@\S+\.\S+/.test(normalizedEmail)) {
        return res.status(400).json({
          message: "Invalid email address",
        });
      }

      const existingUser = await User.findOne({
        email: normalizedEmail,
        _id: { $ne: user._id },
      });

      if (existingUser) {
        return res.status(400).json({
          message: "Email already in use",
        });
      }

      user.email = normalizedEmail;
    }

    // Update phone only if provided
    if (phone !== undefined) {
      if (!/^\+\d{10,15}$/.test(phone)) {
        return res.status(400).json({
          message: "Phone number must be in international format",
        });
      }

      const existingPhone = await User.findOne({
        phone,
        _id: { $ne: user._id },
      });

      if (existingPhone) {
        return res.status(400).json({
          message: "Phone number already in use",
        });
      }

      user.phone = phone;
    }

    await user.save();

    return res.status(200).json({
      success: true,
      user,
      message: "Profile updated successfully",
    });
  } catch (error) {
    console.error("updateProfile error:", error);

    res.status(500).json({
      message: "Failed to update profile",
    });
  }
};

export const changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;

    if (!PASSWORD_REGEX.test(newPassword)) {
      return res.status(400).json({
        message:
          "Password must contain at least 8 characters, one uppercase letter, one lowercase letter, one number and one special character",
      });
    }

    const user = await User.findById(req.user._id);

    const isValid = await bcrypt.compare(currentPassword, user.password);

    if (!isValid) {
      return res.status(400).json({
        message: "Current password is incorrect",
      });
    }

    user.password = await bcrypt.hash(newPassword, 10);

    await user.save();

    res.status(200).json({
      success: true,
      message: "Password updated",
    });
  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Failed to update password",
    });
  }
};

export const verifyPassword = async (req, res) => {
  try {
    const { currentPassword } = req.body;

    if (!currentPassword) {
      return res.status(400).json({
        message: "Current password is required",
      });
    }

    const user = await User.findById(req.user._id);

    const isValid = await bcrypt.compare(currentPassword, user.password);

    if (!isValid) {
      return res.status(400).json({
        message: "Current password is incorrect",
      });
    }

    res.status(200).json({
      success: true,
      message: "Current password verified",
    });
  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Failed to verify password",
    });
  }
};

export const getCurrentUser = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select("-password");
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    res.status(200).json(user);
  } catch (error) {
    console.error("getCurrentUser error:", error);
    res.status(500).json({ message: "Server error" });
  }
};

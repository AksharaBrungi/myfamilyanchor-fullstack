import Subscriber from "../models/Subscriber.js";
import Newsletter from "../models/Newsletter.js";
import NewsletterTemplate from "../models/NewsletterTemplate.js";
import { buildNewsletterHTML } from "../utils/newsletterTemplateBuilder.js";
import transporter from "../config/mail.js";

export const sendNewsletter = async (req, res) => {
  try {
    const { subject, message } = req.body;

    if (!subject || !message) {
      return res.status(400).json({
        message: "Subject and message required",
      });
    }

    const subscribers = await Subscriber.find({
      isActive: true,
    });

    if (!subscribers.length) {
      return res.status(400).json({
        message: "No subscribers found",
      });
    }

    const emails = subscribers.map((s) => s.email).filter(Boolean);

    const html = buildNewsletterHTML({
      title: subject,
      content: message,
    });

    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      bcc: emails,
      subject,
      html,
    });

    await Newsletter.create({
      subject,
      message,
      sentCount: emails.length,
      deliveredCount: emails.length,
      sentBy: req.admin._id,
      sentByName: req.admin.name,
      status: "sent",
    });

    res.json({
      success: true,
      sentTo: emails.length,
      message: "Newsletter sent successfully",
    });
  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Failed to send newsletter",
    });
  }
};

export const getNewsletterHistory = async (req, res) => {
  try {
    const newsletters = await Newsletter.find()
      .sort({ createdAt: -1 })
      .limit(20);

    res.json(newsletters);
  } catch (error) {
    res.status(500).json({
      message: "Failed to load newsletter history",
    });
  }
};

export const getTemplates = async (req, res) => {
  try {
    const templates = await NewsletterTemplate.find();

    res.json(templates);
  } catch (error) {
    res.status(500).json({
      message: "Failed to load templates",
    });
  }
};

export const getNewsletterStats = async (req, res) => {
  try {
    const subscriberCount = await Subscriber.countDocuments({
      isActive: true,
    });

    const campaignCount = await Newsletter.countDocuments();

    const newsletters = await Newsletter.find();

    const emailsDelivered = newsletters.reduce(
      (sum, item) => sum + item.sentCount,
      0,
    );

    res.json({
      subscriberCount,
      campaignCount,
      emailsDelivered,
    });
  } catch (error) {
    res.status(500).json({
      message: "Failed to load newsletter stats",
    });
  }
};

export const sendTestNewsletter = async (req, res) => {
  try {
    const { email, subject, message } = req.body;

    const html = buildNewsletterHTML({
      title: subject,
      content: message,
    });

    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: email,
      subject,
      html,
    });

    res.json({
      success: true,
      message: "Test email sent successfully",
    });
  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Failed to send test email",
    });
  }
};

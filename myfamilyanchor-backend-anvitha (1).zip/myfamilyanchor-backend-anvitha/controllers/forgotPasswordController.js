import bcrypt from "bcryptjs";
import Admin from "../models/Admin.js";
import Staff from "../models/Staff.js";
import Vendor from "../models/vendor.js";
import User from "../models/User.js";
import {
  storeOTP,
  verifyOTP,
  sendOTPEmail,
  sendOTPWhatsApp,
} from "../services/otpService.js";

const PASSWORD_REGEX =
  /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#^()_+\-=[\]{};':"\\|,.<>/?]).{8,}$/;

// Model map

function getModel(role) {
  switch (role) {
    case "admin":  return Admin;
    case "staff":  return Staff;
    case "vendor": return Vendor;
    case "user":   return User;
    default:       return null;
  }
}

// Lookup user by email or phone
async function findUserByIdentifier(Model, identifier) {
  const normalized = identifier.trim().toLowerCase();
  const phoneVariants = [identifier.trim()];
  if (/^\d{10}$/.test(identifier.trim())) {
    phoneVariants.push(`+91${identifier.trim()}`);
  }

  return Model.findOne({
    $or: [
      { email: normalized },
      { phone: { $in: phoneVariants } },
    ],
  });
}

// Request OTP
export const requestOTP = async (req, res) => {
  try {
    const { identifier, role } = req.body;

    if (!identifier || !role) {
      return res.status(400).json({ message: "Identifier and role are required." });
    }

    const Model = getModel(role);
    if (!Model) {
      return res.status(400).json({ message: "Invalid role." });
    }

    const account = await findUserByIdentifier(Model, identifier);

    // Always return same message to prevent enumeration attacks
    if (!account) {
      return res.status(200).json({
        message: "If an account exists, an OTP has been sent.",
        sent: false, // frontend won't know if account exists
      });
    }

    const otp = storeOTP(role, identifier);

    const isEmail = identifier.includes("@");
    const deliveries = [];
    const errors = [];

    if (isEmail && account.email) {
      try {
        await sendOTPEmail(account.email, otp, role);
        deliveries.push("email");
      } catch (err) {
        console.error("Email OTP error:", err.message);
        errors.push("email");
      }
    }

    if (!isEmail && account.phone) {
      try {
        await sendOTPWhatsApp(account.phone, otp, role);
        deliveries.push("whatsapp");
      } catch (err) {
        console.error("WhatsApp OTP error:", err.message);
        errors.push("whatsapp");
      }
    }

    // If we found the account by email but also have phone — send both
    if (isEmail && account.phone) {
      try {
        await sendOTPWhatsApp(account.phone, otp, role);
        if (!deliveries.includes("whatsapp")) deliveries.push("whatsapp");
      } catch {
        // WhatsApp optional — don't fail if email already went through
      }
    }

    if (deliveries.length === 0) {
      return res.status(500).json({
        message: "Failed to send OTP. Please try again.",
      });
    }

    return res.status(200).json({
      message: "OTP sent successfully.",
      sent: true,
      via: deliveries, // ["email", "whatsapp"] etc.
    });
  } catch (error) {
    console.error("requestOTP error:", error);
    res.status(500).json({ message: "Server error. Please try again." });
  }
};

// Verify OTP
export const verifyOTPCode = async (req, res) => {
  try {
    const { identifier, otp, role } = req.body;

    if (!identifier || !otp || !role) {
      return res.status(400).json({ message: "All fields are required." });
    }

    const result = verifyOTP(role, identifier, otp);

    if (!result.valid) {
      return res.status(400).json({ message: result.reason });
    }

    return res.status(200).json({
      message: "OTP verified successfully.",
      verified: true,
    });
  } catch (error) {
    console.error("verifyOTPCode error:", error);
    res.status(500).json({ message: "Server error. Please try again." });
  }
};

// Reset Password
// Called after OTP is verified on the frontend.
// We issue a short-lived reset token server-side to avoid re-verifying OTP.
// Here we use a simple in-memory set of verified reset sessions.
const verifiedResets = new Map(); // `${role}:${identifier}` → expiresAt

export const markVerified = (role, identifier) => {
  const key = `${role}:${identifier.toLowerCase()}`;
  verifiedResets.set(key, Date.now() + 15 * 60 * 1000); // 15 min window
};

// Call this from verifyOTPCode after success
export const verifyOTPAndMark = async (req, res) => {
  try {
    const { identifier, otp, role } = req.body;

    if (!identifier || !otp || !role) {
      return res.status(400).json({ message: "All fields are required." });
    }

    const result = verifyOTP(role, identifier, otp);

    if (!result.valid) {
      return res.status(400).json({ message: result.reason });
    }

    // Mark this identifier as verified for password reset
    const key = `${role}:${identifier.toLowerCase()}`;
    verifiedResets.set(key, Date.now() + 15 * 60 * 1000);

    return res.status(200).json({
      message: "OTP verified. You may now reset your password.",
      verified: true,
    });
  } catch (error) {
    console.error("verifyOTPAndMark error:", error);
    res.status(500).json({ message: "Server error. Please try again." });
  }
};

export const resetPassword = async (req, res) => {
  try {
    const { identifier, newPassword, role } = req.body;

    if (!identifier || !newPassword || !role) {
      return res.status(400).json({ message: "All fields are required." });
    }

    // Check that OTP was verified recently
    const key = `${role}:${identifier.toLowerCase()}`;
    const expiry = verifiedResets.get(key);

    if (!expiry || Date.now() > expiry) {
      return res.status(403).json({
        message: "Session expired. Please verify your OTP again.",
      });
    }

    if (!PASSWORD_REGEX.test(newPassword)) {
      return res.status(400).json({
        message:
          "Password must be at least 8 characters and include uppercase, lowercase, number and special character.",
      });
    }

    const Model = getModel(role);
    if (!Model) return res.status(400).json({ message: "Invalid role." });

    const account = await findUserByIdentifier(Model, identifier);
    if (!account) {
      return res.status(404).json({ message: "Account not found." });
    }

    account.password = await bcrypt.hash(newPassword, 10);
    await account.save();

    // Invalidate the reset session
    verifiedResets.delete(key);

    return res.status(200).json({
      message: "Password reset successfully. You can now log in.",
    });
  } catch (error) {
    console.error("resetPassword error:", error);
    res.status(500).json({ message: "Server error. Please try again." });
  }
};

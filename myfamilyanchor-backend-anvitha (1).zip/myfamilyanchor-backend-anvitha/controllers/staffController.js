import bcrypt from "bcryptjs";
import Staff from "../models/Staff.js";
import ServiceRequest from "../models/ServiceRequest.js";
import { getIO } from "../socket/socket.js";

export const createStaff = async (req, res) => {
  try {
    const tempPassword = "Staff@123";

    const hashedPassword = await bcrypt.hash(tempPassword, 10);

    const staff = await Staff.create({
      ...req.body,
      password: hashedPassword,
    });

    res.status(201).json({
      ...staff.toObject(),
      temporaryPassword: tempPassword,
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

export const getAllStaff = async (req, res) => {
  try {
    const staff = await Staff.find().sort({
      createdAt: -1,
    });

    res.json(staff);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

export const updateStaff = async (req, res) => {
  try {
    const staff = await Staff.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });

    res.json(staff);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

export const deleteStaff = async (req, res) => {
  try {
    await Staff.findByIdAndDelete(req.params.id);

    res.json({
      success: true,
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

export const getAssignedRequests = async (req, res) => {
  try {
    const requests = await ServiceRequest.find({
      assignedStaffId: req.staff._id,
    })
      .populate("user", "name email phone")
      .sort({
        createdAt: -1,
      });

    res.json(requests);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

export const updateStaffRequestStatus = async (req, res) => {
  try {
    const request = await ServiceRequest.findById(req.params.id);

    if (!request) {
      return res.status(404).json({
        message: "Request not found",
      });
    }

    if (String(request.assignedStaffId) !== String(req.staff._id)) {
      return res.status(403).json({
        message: "Unauthorized",
      });
    }

    if (req.body.status === "pending") {
      request.status = "pending";
    }

    if (req.body.status === "in-progress") {
      request.status = "in-progress";
    }

    if (req.body.status === "pending") {
      request.completionPercentage = 10;
    }

    if (req.body.status === "in-progress") {
      request.completionPercentage = 50;
    }

    if (req.body.status === "completed") {
      if (request.verificationStatus !== "submitted") {
        return res.status(400).json({
          message: "Vendor has not requested completion yet",
        });
      }

      request.status = "in-progress";

      request.verificationStatus = "staff-approved";

      request.completionPercentage = 95;

      request.auditLogs.push({
        action: "Completion verified by staff",
        actor: "Staff",
      });
    }

    request.auditLogs.push({
      action: `Status updated by ${req.staff.name}`,
      actor: "Staff",
    });

    await request.save();

    getIO().emit("request-updated", {
      type: "staff-status",
      request,
    });

    res.json(request);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

export const addStaffNote = async (req, res) => {
  try {
    const request = await ServiceRequest.findById(req.params.id);

    if (!request) {
      return res.status(404).json({
        message: "Request not found",
      });
    }

    request.staffNotes.push({
      note: req.body.note,

      staffId: req.staff._id,
    });

    request.auditLogs.push({
      action: `Staff note added`,
      actor: "Staff",
    });

    await request.save();

    res.json(request);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

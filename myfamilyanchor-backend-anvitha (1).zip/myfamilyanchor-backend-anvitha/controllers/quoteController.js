import ServiceRequest from "../models/ServiceRequest.js";
import { computeQuoteAmounts } from "../constants/onDemandPricing.js";
import { getIO } from "../socket/socket.js";
import sendWhatsApp from "../utils/sendWhatsApp.js";

// Vendor submits a price for an on-demand job they've been assigned to assess.
export const submitQuote = async (req, res) => {
  try {
    const { vendorAmount, notes } = req.body;

    if (!vendorAmount || vendorAmount <= 0) {
      return res
        .status(400)
        .json({ message: "A valid vendor amount is required" });
    }

    const request = await ServiceRequest.findById(req.params.id).populate(
      "user",
    );

    if (!request) {
      return res.status(404).json({ message: "Request not found" });
    }

    if (String(request.assignedVendorId) !== String(req.vendor._id)) {
      return res
        .status(403)
        .json({ message: "You are not assigned to this request" });
    }

    if (request.serviceCategory !== "on_demand") {
      return res.status(400).json({
        message: "This is an included service — it doesn't need a quote",
      });
    }

    if (!["pending", "rejected"].includes(request.quote.status)) {
      return res.status(400).json({
        message: `A quote cannot be submitted while status is "${request.quote.status}"`,
      });
    }

    const { marginPercent, marginAmount, customerAmount } = computeQuoteAmounts(
      vendorAmount,
      request.user?.currentPlan,
    );

    request.quote.status = "submitted";
    request.quote.vendorAmount = vendorAmount;
    request.quote.marginPercent = marginPercent;
    request.quote.marginAmount = marginAmount;
    request.quote.customerAmount = customerAmount;
    request.quote.notes = notes || "";
    request.quote.submittedAt = new Date();

    request.auditLogs.push({
      action: `Quote submitted by vendor: ₹${customerAmount}`,
      actor: "Vendor",
    });

    await request.save();

    try {
      getIO().emit("request-updated", { type: "quote-submitted", request });
    } catch (err) {
      console.log("Socket error:", err.message);
    }

    if (request.user?.phone) {
      try {
        await sendWhatsApp({
          to: request.user.phone,
          messageData: `
💰 Quote Ready

Service: ${request.serviceType}
Amount: ₹${customerAmount}

Review and approve in your dashboard to schedule the work.

– MyFamilyAnchor
`,
        });
      } catch (err) {
        console.error("WhatsApp failed:", err.message);
      }
    }

    res.status(200).json(request);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Customer accepts the quoted price. Does NOT charge — that happens via
// POST /api/payment/on-demand/create-order once status is "approved".
export const approveQuote = async (req, res) => {
  try {
    const request = await ServiceRequest.findOne({
      _id: req.params.id,
      user: req.user._id,
    });

    if (!request) {
      return res.status(404).json({ message: "Request not found" });
    }

    if (request.quote.status !== "submitted") {
      return res.status(400).json({
        message: `Only a submitted quote can be approved (current status: "${request.quote.status}")`,
      });
    }

    request.quote.status = "approved";
    request.quote.respondedAt = new Date();

    request.auditLogs.push({
      action: "Quote approved by customer",
      actor: "User",
    });

    await request.save();

    getIO().emit("request-updated", { type: "quote-approved", request });

    res.status(200).json(request);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Customer declines the quote. Resets to "pending" so the assigned vendor
// (or a re-assigned one, via updateRequestMeta) can submit a revised quote.
export const rejectQuote = async (req, res) => {
  try {
    const { reason } = req.body;

    const request = await ServiceRequest.findOne({
      _id: req.params.id,
      user: req.user._id,
    });

    if (!request) {
      return res.status(404).json({ message: "Request not found" });
    }

    if (request.quote.status !== "submitted") {
      return res.status(400).json({
        message: `Only a submitted quote can be rejected (current status: "${request.quote.status}")`,
      });
    }

    request.quote.status = "rejected";
    request.quote.respondedAt = new Date();

    request.auditLogs.push({
      action: `Quote rejected by customer${reason ? `: ${reason}` : ""}`,
      actor: "User",
    });

    await request.save();

    getIO().emit("request-updated", { type: "quote-rejected", request });

    res.status(200).json(request);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

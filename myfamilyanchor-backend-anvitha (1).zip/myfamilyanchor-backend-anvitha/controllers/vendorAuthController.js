import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import Vendor from "../models/vendor.js";

export const vendorLogin = async (req, res) => {
  try {
    const { identifier, password } = req.body;

    if (!identifier || !password) {
      return res.status(400).json({
        message: "Email/Phone and password are required",
      });
    }

    const normalizedIdentifier = identifier.trim().toLowerCase();

    let phoneVariants = [];

    if (/^\d{10}$/.test(identifier.trim())) {
      phoneVariants.push(`+91${identifier.trim()}`);
    }

    phoneVariants.push(identifier.trim());

    const vendor = await Vendor.findOne({
      $or: [
        {
          email: normalizedIdentifier,
        },
        {
          phone: {
            $in: phoneVariants,
          },
        },
      ],
    });

    if (!vendor) {
      return res.status(400).json({
        message: "Invalid credentials",
      });
    }

    const validPassword = await bcrypt.compare(password, vendor.password);

    if (!validPassword) {
      return res.status(400).json({
        message: "Invalid credentials",
      });
    }

    vendor.lastLogin = new Date();

    await vendor.save();

    const token = jwt.sign(
      {
        id: vendor._id,
        role: "vendor",
      },
      process.env.JWT_SECRET,
      {
        expiresIn: "7d",
      },
    );

    res.json({
      token,

      vendor: {
        _id: vendor._id,
        ownerName: vendor.ownerName,
        businessName: vendor.businessName,
        email: vendor.email,
        category: vendor.category,
      },
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

export const getVendorProfile = async (req, res) => {
  try {
    const vendor = await Vendor.findById(req.vendor._id).select("-password");

    res.json(vendor);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

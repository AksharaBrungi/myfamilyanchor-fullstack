import Booking from "../models/Booking.js";
import sendEmail from "../utils/sendEmail.js";
import sendWhatsApp from "../utils/sendWhatsApp.js";

export const createBooking = async (req, res) => {
  try {
    const { name, email, phone, preferredDate, preferredTime, careNeed } =
      req.body;

    if (
      !name ||
      !email ||
      !phone ||
      !preferredDate ||
      !preferredTime ||
      !careNeed
    ) {
      return res.status(400).json({
        message: "All fields are required",
      });
    }

    const booking = await Booking.create({
      name,
      email,
      phone,
      preferredDate,
      preferredTime,
      careNeed,
    });

    // ✅ Email to Admin
    await sendEmail({
      to: process.env.ADMIN_EMAIL,
      subject: "New Free Call Booking Request",
      html: `
        <h2>New Booking Request</h2>
        <p><b>Name:</b> ${name}</p>
        <p><b>Email:</b> ${email}</p>
        <p><b>Phone:</b> ${phone}</p>
        <p><b>Date:</b> ${preferredDate}</p>
        <p><b>Time:</b> ${preferredTime}</p>
        <p><b>Care Need:</b> ${careNeed}</p>
      `,
    });

    // ✅ Confirmation Email to Customer
    await sendEmail({
      // to: "myfamilyanchorofficial@gmail.com",
      to: email,
      subject: "Your Booking is Confirmed – MyFamilyAnchor 🎉",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 30px; border-radius: 12px; border: 1px solid #eee;">
          
          <h2 style="color: #7b3ff2;">Booking Confirmed! 🎉</h2>
          
          <p>Hi <strong>${name}</strong>,</p>
          <p>Thank you for booking a free consultation call with <strong>MyFamilyAnchor</strong>. We have received your request and our team will connect with you shortly.</p>

          <div style="background: #f8f3ff; padding: 16px; border-radius: 10px; margin: 20px 0;">
            <h3 style="margin: 0 0 12px; color: #7b3ff2;">Booking Details</h3>
            <p style="margin: 4px 0;"><b>Name:</b> ${name}</p>
            <p style="margin: 4px 0;"><b>Phone:</b> ${phone}</p>
            <p style="margin: 4px 0;"><b>Preferred Date:</b> ${preferredDate}</p>
            <p style="margin: 4px 0;"><b>Preferred Time:</b> ${preferredTime}</p>
            <p style="margin: 4px 0;"><b>Care Need:</b> ${careNeed}</p>
          </div>

          <p>If you have any questions, feel free to reply to this email.</p>

          <p style="color: #888; font-size: 13px; margin-top: 30px;">– MyFamilyAnchor Team</p>
        </div>
      `,
    });

    // ✅ WhatsApp to Admin
    await sendWhatsApp({
      to: process.env.ADMIN_WHATSAPP_NUMBER,
      messageData: `
📞 NEW FREE CALL BOOKING

👤 Name: ${name}
📧 Email: ${email}
📱 Phone: ${phone}
📅 Date: ${preferredDate}
⏰ Time: ${preferredTime}
🏥 Care Need: ${careNeed}
      `,
    });

    // ✅ Confirmation WhatsApp to Customer
    await sendWhatsApp({
      to: phone,
      messageData: `
🎉 Booking Confirmed

Hi ${name},

Your consultation booking has been received.

📅 Date: ${preferredDate}
⏰ Time: ${preferredTime}
🏠 Service: ${careNeed}

Our team will contact you shortly.

– MyFamilyAnchor
`,
    });

    return res.status(201).json({
      success: true,
      message: "Booking request submitted successfully",
      bookingId: booking._id,
    });
  } catch (error) {
    console.error("BOOKING ERROR:", error);
    return res.status(500).json({
      success: false,
      message: "Unable to create booking",
    });
  }
};

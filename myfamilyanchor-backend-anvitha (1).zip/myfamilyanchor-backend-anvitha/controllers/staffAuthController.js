import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import Staff from "../models/Staff.js";

export const staffLogin = async (req, res) => {
  try {
    const { identifier, password } = req.body;

    if (!identifier || !password) {
      return res.status(400).json({
        message: "Email/Phone and password are required",
      });
    }

    const normalizedIdentifier = identifier.trim().toLowerCase();

    let phoneVariants = [];

    if (/^\d{10}$/.test(identifier.trim())) {
      phoneVariants.push(`+91${identifier.trim()}`);
    }

    phoneVariants.push(identifier.trim());

    const staff = await Staff.findOne({
      $or: [
        {
          email: normalizedIdentifier,
        },
        {
          phone: {
            $in: phoneVariants,
          },
        },
      ],
    });

    if (!staff) {
      return res.status(400).json({
        message: "Invalid credentials",
      });
    }

    const validPassword = await bcrypt.compare(password, staff.password);

    if (!validPassword) {
      return res.status(400).json({
        message: "Invalid credentials",
      });
    }

    staff.lastLogin = new Date();

    await staff.save();

    const token = jwt.sign(
      {
        id: staff._id,
        role: "staff",
      },
      process.env.JWT_SECRET,
      {
        expiresIn: "7d",
      },
    );

    res.json({
      token,

      staff: {
        _id: staff._id,
        name: staff.name,
        email: staff.email,
        designation: staff.designation,
        role: staff.role,
      },
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

export const getStaffProfile = async (req, res) => {
  try {
    const staff = await Staff.findById(req.staff._id).select("-password");

    res.json(staff);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

import crypto from "crypto";
import Payment from "../models/Payment.js";
import Plan from "../models/Plan.js";
import User from "../models/User.js";
import ServiceRequest from "../models/ServiceRequest.js";
import VendorPayout from "../models/vendorPayout.js";
import razorpay from "../config/razorpay.js";
import sendEmail from "../utils/sendEmail.js";
import sendWhatsApp from "../utils/sendWhatsApp.js";
import { getIO } from "../socket/socket.js";

// Create Order
export const createOrder = async (req, res) => {
  try {
    const amount = req.body.amount;

    if (!amount || amount <= 0) {
      return res.status(400).json({
        message: "Invalid amount",
      });
    }

    const options = {
      amount: amount * 100,
      currency: "INR",
      receipt: `receipt_${Date.now()}`,
    };

    const order = await razorpay.orders.create(options);

    res.status(200).json(order);
  } catch (error) {
    console.log("RAZORPAY ERROR:", error);

    res.status(500).json({
      message: error.message,
    });
  }
};

// verify Payment
export const verifyPayment = async (req, res) => {
  try {
    const {
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
      planName,
      billingCycle,
      amount,
    } = req.body;

    // verify signature
    const generatedSignature = crypto
      .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
      .update(razorpay_order_id + "|" + razorpay_payment_id)
      .digest("hex");

    const isAuthentic = generatedSignature === razorpay_signature;

    if (!isAuthentic) {
      return res.status(400).json({
        success: false,
        message: "Invalid signature",
      });
    }

    // check duplicate payment
    const existingPayment = await Payment.findOne({
      razorpayPaymentId: razorpay_payment_id,
    });

    if (existingPayment) {
      return res.status(400).json({
        success: false,
        message: "Payment already processed",
      });
    }

    // find user
    const user = await User.findById(req.user._id);

    // expire date
    const subscriptionStartDate = new Date();
    const expiryDate = new Date(subscriptionStartDate);

    const normalizedCycle = billingCycle?.toLowerCase().trim();

    if (
      normalizedCycle === "monthly" ||
      normalizedCycle === "/month" ||
      normalizedCycle === "month"
    ) {
      expiryDate.setMonth(expiryDate.getMonth() + 1);
    } else if (
      normalizedCycle === "yearly" ||
      normalizedCycle === "/year" ||
      normalizedCycle === "year"
    ) {
      expiryDate.setFullYear(expiryDate.getFullYear() + 1);
    } else {
      expiryDate.setMonth(expiryDate.getMonth() + 1);
    }

    // save payment
    await Payment.create({
      user: req.user._id,
      planName,
      billingCycle,
      amount,
      razorpayOrderId: razorpay_order_id,
      razorpayPaymentId: razorpay_payment_id,
      razorpaySignature: razorpay_signature,
      status: "paid",
      paidAt: subscriptionStartDate,
      subscriptionValidUntil: expiryDate,
    });

    await sendEmail({
      to: process.env.ADMIN_EMAIL,

      subject: "New Subscription Payment Received",

      html: `
  <h2>Payment Received</h2>

  <p><strong>Name:</strong> ${user.name}</p>

  <p><strong>Email:</strong> ${user.email}</p>

  <p><strong>Plan:</strong> ${planName}</p>

  <p><strong>Amount:</strong> ₹${amount}</p>

  <p><strong>Payment ID:</strong>
  ${razorpay_payment_id}</p>

  <p><strong>Billing Cycle:</strong>
  ${billingCycle}</p>
  `,
    });

    // send email
    try {
      await sendEmail({
        to: user.email,
        subject: "Payment Successful - MyFamilyAnchor",
        html: `
      <div style="font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 40px 20px;">
        <div style="max-width: 700px; margin: auto; background: #ffffff; padding: 40px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.08);">

          <h1 style="color: #8b7cf6; margin-bottom: 30px;">
            Payment Successful 🎉
          </h1>

          <p style="font-size: 16px;">Hi ${user.name || "User"},</p>

          <p style="font-size: 16px; line-height: 1.6;">
            Your subscription has been successfully activated.
          </p>

          <hr style="margin: 30px 0;" />

          <h3 style="color:#333;">Payment Details</h3>
          <p><strong>Plan:</strong> ${planName}</p>
          <p><strong>Billing Cycle:</strong> ${billingCycle}</p>
          <p><strong>Total Amount:</strong> ₹${amount}</p>

          <hr style="margin: 30px 0;" />

          <h3 style="color:#333;">Transaction Info</h3>
          <p><strong>Payment ID:</strong> ${razorpay_payment_id}</p>
          <p><strong>Order ID:</strong> ${razorpay_order_id}</p>
          <p><strong>Status:</strong> Paid Successfully</p>
          <p><strong>Payment Date:</strong> ${new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata" })}</p>

          <hr style="margin: 30px 0;" />

          <h3 style="color:#333;">Subscription Details</h3>
          <p><strong>Valid Until:</strong> ${expiryDate.toLocaleString(
            "en-IN",
            {
              timeZone: "Asia/Kolkata",
              dateStyle: "full",
              timeStyle: "short",
            },
          )}</p>

          <hr style="margin: 30px 0;" />

          <p style="margin-top: 30px; font-size: 14px; color: #777;">
            Thank you for choosing MyFamilyAnchor ❤️
          </p>

          <p style="margin-top: 10px; font-size: 14px; color: #555;">
            📞 Contact us: <a href="tel:+919876543210">+91-98765-43210</a><br/>
            ✉️ Email: <a href="mailto:support@myfamilyanchor.com">support@myfamilyanchor.com</a>
          </p>

        </div>
      </div>
      `,
      });
    } catch (err) {
      console.error("Email failed:", err.message);
    }

    await sendWhatsApp({
      to: process.env.ADMIN_WHATSAPP_NUMBER,

      messageData: `
💰 New Subscription Payment

👤 ${user.name}

📧 ${user.email}

📦 Plan: ${planName}

💵 Amount: ₹${amount}

🧾 Payment ID:
${razorpay_payment_id}
`,
    });

    if (user.phone) {
      try {
        await sendWhatsApp({
          to: user.phone,
          messageData: {
            name: user.name,
            amount,
            transactionId: razorpay_payment_id,
            status: "SUCCESS",
            method: "Razorpay",
          },
        });
      } catch (err) {
        console.error("WhatsApp failed:", err.message);
      }
    }

    // update user
    user.subscriptionStatus = "active";
    user.currentPlan = planName;
    user.paymentCompleted = true;
    user.subscriptionExpiresAt = expiryDate;
    // Anchors included-service quota cycles (Phase 2) — reset to "now" on
    // every payment (first purchase or renewal) so quotas roll forward
    // in 30-day windows independent of billingCycle.
    user.currentCycleStartedAt = subscriptionStartDate;
    await user.save();

    // response
    res.status(200).json({
      success: true,
      message: "Payment verified",
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// ---------------------------------------------------------------------
// Phase 3: On-Demand job payments. Separate from subscription payments
// above — same Razorpay account and signature-verification pattern, but
// billed per job against an approved quote, never against the recurring
// subscription charge.
// ---------------------------------------------------------------------

// Create Order for an approved on-demand quote
export const createOnDemandOrder = async (req, res) => {
  try {
    const request = await ServiceRequest.findOne({
      _id: req.params.id,
      user: req.user._id,
    });

    if (!request) {
      return res.status(404).json({ message: "Request not found" });
    }

    if (request.quote.status !== "approved") {
      return res.status(400).json({
        message: `Quote must be approved before payment (current status: "${request.quote.status}")`,
      });
    }

    const options = {
      amount: request.quote.customerAmount * 100,
      currency: "INR",
      receipt: `ondemand_${request._id}_${Date.now()}`,
    };

    const order = await razorpay.orders.create(options);

    res.status(200).json(order);
  } catch (error) {
    console.log("RAZORPAY ERROR (on-demand):", error);
    res.status(500).json({ message: error.message });
  }
};

// Verify Payment for an on-demand job, then release the request to move
// forward (vendor can now upload before-photos) and open a payout ledger
// entry for the vendor.
export const verifyOnDemandPayment = async (req, res) => {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } =
      req.body;

    const generatedSignature = crypto
      .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
      .update(razorpay_order_id + "|" + razorpay_payment_id)
      .digest("hex");

    if (generatedSignature !== razorpay_signature) {
      return res.status(400).json({
        success: false,
        message: "Invalid signature",
      });
    }

    const existingPayment = await Payment.findOne({
      razorpayPaymentId: razorpay_payment_id,
    });

    if (existingPayment) {
      return res.status(400).json({
        success: false,
        message: "Payment already processed",
      });
    }

    const request = await ServiceRequest.findOne({
      _id: req.params.id,
      user: req.user._id,
    }).populate("user");

    if (!request) {
      return res.status(404).json({ message: "Request not found" });
    }

    if (request.quote.status !== "approved") {
      return res.status(400).json({
        message: `Quote must be approved before payment (current status: "${request.quote.status}")`,
      });
    }

    await Payment.create({
      user: req.user._id,
      planName: `On-Demand: ${request.serviceType}`,
      type: "on_demand",
      serviceRequest: request._id,
      amount: request.quote.customerAmount,
      razorpayOrderId: razorpay_order_id,
      razorpayPaymentId: razorpay_payment_id,
      razorpaySignature: razorpay_signature,
      status: "paid",
      paidAt: new Date(),
    });

    if (request.assignedVendorId) {
      await VendorPayout.create({
        vendor: request.assignedVendorId,
        serviceRequest: request._id,
        amount: request.quote.vendorAmount,
        status: "pending",
      });
    } else {
      // Shouldn't happen in practice (a quote requires an assigned
      // vendor to have submitted it) but don't silently lose the payout.
      console.warn(
        `[verifyOnDemandPayment] Request ${request._id} was paid but has no assignedVendorId — no VendorPayout created.`,
      );
    }

    request.quote.status = "paid";
    request.auditLogs.push({
      action: `On-demand payment received: ₹${request.quote.customerAmount}`,
      actor: "System",
    });

    await request.save();

    try {
      getIO().emit("request-updated", { type: "quote-paid", request });
    } catch (err) {
      console.log("Socket error:", err.message);
    }

    try {
      await sendEmail({
        to: process.env.ADMIN_EMAIL,
        subject: "On-Demand Payment Received",
        html: `
  <h2>On-Demand Payment Received</h2>
  <p><strong>Customer:</strong> ${request.user?.name}</p>
  <p><strong>Service:</strong> ${request.serviceType}</p>
  <p><strong>Amount:</strong> ₹${request.quote.customerAmount}</p>
  <p><strong>Vendor payout:</strong> ₹${request.quote.vendorAmount}</p>
  <p><strong>Platform margin:</strong> ₹${request.quote.marginAmount} (${request.quote.marginPercent}%)</p>
  <p><strong>Payment ID:</strong> ${razorpay_payment_id}</p>
  `,
      });
    } catch (err) {
      console.error("Email failed:", err.message);
    }

    if (request.user?.phone) {
      try {
        await sendWhatsApp({
          to: request.user.phone,
          messageData: `
✅ Payment Received

Service: ${request.serviceType}
Amount: ₹${request.quote.customerAmount}

Your vendor will be in touch to schedule the work.

– MyFamilyAnchor
`,
        });
      } catch (err) {
        console.error("WhatsApp failed:", err.message);
      }
    }

    res
      .status(200)
      .json({ success: true, message: "Payment verified", request });
  } catch (error) {
    console.log(error);
    res.status(500).json({ success: false, message: error.message });
  }
};

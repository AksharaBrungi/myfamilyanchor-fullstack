import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import Admin from "../models/Admin.js";
import User from "../models/User.js";
import Payment from "../models/Payment.js";
import ServiceRequest from "../models/ServiceRequest.js";
import VendorPayout from "../models/VendorPayout.js";
import { getIO } from "../socket/socket.js";

const PASSWORD_REGEX =
  /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#^()_+\-=[\]{};':"\\|,.<>/?]).{8,}$/;

export const adminLogin = async (req, res) => {
  try {
    const { password } = req.body;

    if (!password || !req.body.identifier) {
      return res
        .status(400)
        .json({ message: "Email/Phone and password are required" });
    }

    const identifier = req.body.identifier.trim().toLowerCase();

    let phoneVariants = [];

    if (/^\d{10}$/.test(req.body.identifier.trim())) {
      phoneVariants.push(`+91${req.body.identifier.trim()}`);
    }

    phoneVariants.push(req.body.identifier.trim());

    const admin = await Admin.findOne({
      $or: [{ email: identifier }, { phone: { $in: phoneVariants } }],
    });

    // Use same message for both missing admin and wrong password (prevents enumeration)
    if (!admin) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const validPassword = await bcrypt.compare(password, admin.password);
    if (!validPassword) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const token = jwt.sign(
      { id: admin._id, role: "admin" },
      process.env.JWT_SECRET,
      { expiresIn: "7d" },
    );

    const safeAdmin = {
      _id: admin._id,
      name: admin.name,
      email: admin.email,
      role: admin.role,
    };

    res.status(200).json({ token, admin: safeAdmin });
  } catch (error) {
    console.error("adminLogin error:", error);
    res.status(500).json({ message: "Server error during admin login" });
  }
};

export const updateAdminProfile = async (req, res) => {
  try {
    const { name, email, phone } = req.body;

    const admin = await Admin.findById(req.admin._id);

    if (!admin) {
      return res.status(404).json({
        message: "Admin not found",
      });
    }

    if (name !== undefined) {
      if (!name.trim()) {
        return res.status(400).json({
          message: "Name cannot be empty",
        });
      }

      admin.name = name.trim();
    }

    if (email !== undefined) {
      const normalizedEmail = email.trim().toLowerCase();

      if (!/\S+@\S+\.\S+/.test(normalizedEmail)) {
        return res.status(400).json({
          message: "Invalid email address",
        });
      }

      admin.email = normalizedEmail;
    }

    if (phone !== undefined) {
      const existingAdmin = await Admin.findOne({
        phone,
        _id: { $ne: admin._id },
      });

      if (existingAdmin) {
        return res.status(400).json({
          message: "Phone number already in use",
        });
      }

      admin.phone = phone;
    }

    await admin.save();

    res.json({
      success: true,
      admin,
    });
  } catch (error) {
    res.status(500).json({
      message: "Failed to update profile",
    });
  }
};

export const changeAdminPassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;

    if (!PASSWORD_REGEX.test(newPassword)) {
      return res.status(400).json({
        message:
          "Password must contain at least 8 characters, one uppercase letter, one lowercase letter, one number and one special character",
      });
    }

    const admin = await Admin.findById(req.admin._id);

    const validPassword = await bcrypt.compare(
      req.body.currentPassword,
      admin.password,
    );

    if (!validPassword) {
      return res.status(400).json({
        message: "Current password incorrect",
      });
    }

    admin.password = await bcrypt.hash(req.body.newPassword, 10);

    await admin.save();

    res.json({
      success: true,
    });
  } catch (error) {
    res.status(500).json({
      message: "Failed to update password",
    });
  }
};

export const verifyAdminPassword = async (req, res) => {
  try {
    const { currentPassword } = req.body;

    if (!currentPassword) {
      return res.status(400).json({
        message: "Current password is required",
      });
    }

    const admin = await Admin.findById(req.admin._id);

    const validPassword = await bcrypt.compare(currentPassword, admin.password);

    if (!validPassword) {
      return res.status(400).json({
        message: "Current password incorrect",
      });
    }

    res.json({
      success: true,
      message: "Current password verified",
    });
  } catch (error) {
    res.status(500).json({
      message: "Failed to verify password",
    });
  }
};

export const getAdminDashboard = async (req, res) => {
  try {
    const [
      totalUsers,
      activeSubscriptions,
      totalPayments,
      revenueResult,
      recentUsers,
      recentPayments,
      allUsers,
    ] = await Promise.all([
      User.countDocuments(),
      User.countDocuments({ subscriptionStatus: "active" }),
      Payment.countDocuments(),
      Payment.aggregate([
        { $match: { status: "paid" } },
        { $group: { _id: null, total: { $sum: "$amount" } } },
      ]),
      User.find().sort({ createdAt: -1 }).limit(5).select("-password"),
      Payment.find().sort({ createdAt: -1 }).limit(5),
      User.find().select("-password").sort({ createdAt: -1 }),
    ]);

    res.status(200).json({
      totalUsers,
      activeSubscriptions,
      totalPayments,
      revenue: revenueResult[0]?.total ?? 0, // was optional chain only, now nullish coalesces to 0

      users: allUsers,

      payments: recentPayments,

      recentUsers,
      recentPayments,

      requestMetrics: {
        pending: await ServiceRequest.countDocuments({
          status: "pending",
        }),

        inProgress: await ServiceRequest.countDocuments({
          status: "in-progress",
        }),

        completed: await ServiceRequest.countDocuments({
          status: "completed",
        }),

        cancelled: await ServiceRequest.countDocuments({
          status: "cancelled",
        }),
      },

      teamMetrics: await ServiceRequest.aggregate([
        {
          $match: {
            assignedTo: {
              $ne: "",
            },
          },
        },

        {
          $group: {
            _id: "$assignedTo",

            assigned: {
              $sum: 1,
            },

            completed: {
              $sum: {
                $cond: [
                  {
                    $eq: ["$status", "completed"],
                  },
                  1,
                  0,
                ],
              },
            },

            pending: {
              $sum: {
                $cond: [
                  {
                    $eq: ["$status", "pending"],
                  },
                  1,
                  0,
                ],
              },
            },

            inProgress: {
              $sum: {
                $cond: [
                  {
                    $eq: ["$status", "in-progress"],
                  },
                  1,
                  0,
                ],
              },
            },
          },
        },

        {
          $sort: {
            assigned: -1,
          },
        },
      ]),

      vendorMetrics: await ServiceRequest.aggregate([
        {
          $match: {
            assignedVendor: {
              $ne: "",
            },
          },
        },

        {
          $group: {
            _id: "$assignedVendor",

            assigned: {
              $sum: 1,
            },

            completed: {
              $sum: {
                $cond: [
                  {
                    $eq: ["$status", "completed"],
                  },
                  1,
                  0,
                ],
              },
            },
          },
        },

        {
          $sort: {
            assigned: -1,
          },
        },
      ]),
    });
  } catch (error) {
    console.error("getAdminDashboard error:", error);
    res.status(500).json({ message: "Server error fetching dashboard" });
  }
};

export const getAdminProfile = async (req, res) => {
  const admin = await Admin.findById(req.admin._id).select("-password");

  res.json(admin);
};

export const approveCompletion = async (req, res) => {
  try {
    const request = await ServiceRequest.findById(req.params.id);

    if (!request) {
      return res.status(404).json({
        message: "Request not found",
      });
    }

    if (request.verificationStatus !== "staff-approved") {
      return res.status(400).json({
        message: "Staff verification required first",
      });
    }

    request.status = "completed";

    request.verificationStatus = "approved";

    request.completionPercentage = 100;

    request.completedAt = new Date();

    request.auditLogs.push({
      action: "Completion approved by admin",
      actor: "Admin",
    });

    request.completedAt = new Date();

    await request.save();

    // Phase 3: release the vendor's payout now, not before — this is the
    // "released after customer sign-off" point the payout ledger design
    // depends on. Only applies to on-demand jobs; included services never
    // create a VendorPayout in the first place.
    if (request.serviceCategory === "on_demand" && request.assignedVendorId) {
      await VendorPayout.findOneAndUpdate(
        { serviceRequest: request._id, status: "pending" },
        { status: "released", releasedAt: new Date() },
      );
    }

    getIO().emit("request-updated", {
      type: "completion-approved",
      request,
    });

    res.json(request);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

export const rejectCompletion = async (req, res) => {
  try {
    const request = await ServiceRequest.findById(req.params.id);

    if (!request) {
      return res.status(404).json({
        message: "Request not found",
      });
    }

    request.verificationStatus = "rejected";

    request.completionPercentage = 50;

    request.auditLogs.push({
      action: "Completion rejected by admin",
    });

    await request.save();

    getIO().emit("request-updated", {
      type: "completion-rejected",
      request,
    });

    res.json(request);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

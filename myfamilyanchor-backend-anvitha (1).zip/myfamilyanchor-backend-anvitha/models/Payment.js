import mongoose from "mongoose";

const paymentSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    planName: {
      type: String,
      required: true,
    },

    // "subscription" (existing flow) or "on_demand" (Phase 3 quoted jobs).
    // planName stays required for both — on-demand payments store a
    // descriptive label there (e.g. "On-Demand: Painting Service") so
    // nothing that already queries/reads planName elsewhere breaks.
    type: {
      type: String,
      enum: ["subscription", "on_demand"],
      default: "subscription",
    },

    serviceRequest: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "ServiceRequest",
    },

    billingCycle: String,

    amount: {
      type: Number,
      required: true,
    },

    razorpayOrderId: {
      type: String,
      required: true,
    },

    razorpayPaymentId: {
      type: String,
      required: true,
      unique: true,
    },

    razorpaySignature: {
      type: String,
      required: true,
    },

    status: {
      type: String,
      default: "created",
    },

    paidAt: Date,

    subscriptionValidUntil: {
      type: Date,
    },
  },
  {
    timestamps: true,
  },
);

export default mongoose.model("Payment", paymentSchema);

import mongoose from "mongoose";

const vendorSchema = new mongoose.Schema(
  {
    ownerName: {
      type: String,
      required: true,
    },

    businessName: {
      type: String,
      required: true,
    },

    email: {
      type: String,
      lowercase: true,
      trim: true,
    },

    phone: {
      type: String,
      required: true,
    },

    password: String,

    role: {
      type: String,
      default: "vendor",
    },

    lastLogin: Date,

    category: {
      type: String,
      required: true,
    },

    city: {
      type: String,
      default: "",
    },

    serviceAreas: [String],

    status: {
      type: String,
      enum: ["active", "inactive"],
      default: "active",
    },

    rating: {
      type: Number,
      default: 5,
    },

    totalJobs: {
      type: Number,
      default: 0,
    },

    completedJobs: {
      type: Number,
      default: 0,
    },

    notes: {
      type: String,
      default: "",
    },
  },
  {
    timestamps: true,
  },
);

export default mongoose.model("Vendor", vendorSchema);

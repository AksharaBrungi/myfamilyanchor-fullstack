import mongoose from "mongoose";

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },

    email: {
      type: String,
      unique: true,
      required: true,
      trim: true,
      lowercase: true,
    },

    password: {
      type: String,
      required: true,
      minlength: 8,
    },

    phone: {
      type: String,
      trim: true,
      unique: true,
      sparse: true,
    },

    role: {
      type: String,
      default: "customer",
    },

    currentPlan: {
      type: String,
      default: null,
    },

    subscriptionStatus: {
      type: String,
      enum: ["pending", "active", "inactive", "cancelled"],
      default: "pending",
    },

    paymentCompleted: {
      type: Boolean,
      default: false,
    },

    subscriptionExpiresAt: {
      type: Date,
      default: null,
    },

    // Anchor date for included-service quota cycles (Phase 2). Set at
    // first payment and refreshed on renewal in paymentController.js.
    // Quota cycles roll forward every 30 days from this date regardless
    // of billingCycle (monthly/yearly) — see services/quotaService.js.
    currentCycleStartedAt: {
      type: Date,
      default: null,
    },
  },
  {
    timestamps: true,
  },
);

export default mongoose.model("User", userSchema);

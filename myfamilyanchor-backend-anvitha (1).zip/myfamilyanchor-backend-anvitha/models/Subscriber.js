import mongoose from "mongoose";

const subscriberSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true,
  },

  isActive: {
    type: Boolean,
    default: true,
  },

  subscribedAt: {
    type: Date,
    default: Date.now,
  },

  source: {
    type: String,
    default: "footer",
  },

  lastEmailSentAt: {
    type: Date,
  },
});

export default mongoose.model("Subscriber", subscriberSchema);

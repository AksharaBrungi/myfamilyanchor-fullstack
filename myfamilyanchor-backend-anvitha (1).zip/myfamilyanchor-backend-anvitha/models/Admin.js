import mongoose from "mongoose";

const adminSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },

    email: {
      type: String,
      unique: true,
      required: true,
    },

    password: {
      type: String,
      required: true,
      minlength: 8,
    },

    phone: {
      type: String,
      trim: true,
      unique: true,
      sparse: true,
    },

    role: {
      type: String,
      default: "admin",
    },

    permissions: [String],
  },
  {
    timestamps: true,
  },
);

export default mongoose.model("Admin", adminSchema);

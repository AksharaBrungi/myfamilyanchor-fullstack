import mongoose from "mongoose";

const quotaUsageSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    serviceType: {
      type: String,
      required: true,
    },

    // Denormalized for reporting/debugging — not used in lookups.
    category: {
      type: String,
      enum: ["property", "family", "premium"],
    },

    cycleStart: {
      type: Date,
      required: true,
    },

    cycleEnd: {
      type: Date,
      required: true,
    },

    usedCount: {
      type: Number,
      default: 0,
    },
  },
  {
    timestamps: true,
  },
);

// One usage bucket per user+service+cycle. This is what makes the
// check-then-increment in services/quotaService.js safe under concurrent
// requests — see the comment there for how it's used.
quotaUsageSchema.index(
  { user: 1, serviceType: 1, cycleStart: 1 },
  { unique: true },
);

export default mongoose.model("QuotaUsage", quotaUsageSchema);

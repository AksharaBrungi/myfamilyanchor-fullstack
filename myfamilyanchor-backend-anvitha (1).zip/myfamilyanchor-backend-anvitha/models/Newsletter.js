import mongoose from "mongoose";

const newsletterSchema = new mongoose.Schema(
  {
    subject: {
      type: String,
      required: true,
    },

    message: {
      type: String,
      required: true,
    },

    sentCount: {
      type: Number,
      default: 0,
    },

    sentBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Admin",
    },

    sentByName: {
      type: String,
    },

    status: {
      type: String,
      enum: ["draft", "sent"],
      default: "sent",
    },

    openedCount: {
      type: Number,
      default: 0,
    },

    clickedCount: {
      type: Number,
      default: 0,
    },

    deliveredCount: {
      type: Number,
      default: 0,
    },
  },
  {
    timestamps: true,
  },
);

export default mongoose.model("Newsletter", newsletterSchema);

import mongoose from "mongoose";

const serviceRequestSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    serviceType: {
      type: String,
      required: true,
    },

    category: {
      type: String,
      enum: ["property", "family", "premium"],
    },

    // Set from constants/serviceCatalog.js at creation time — not user input.
    // Drives quota enforcement (Phase 2) and the quote-before-work gate (Phase 3).
    serviceCategory: {
      type: String,
      enum: ["included", "on_demand"],
    },

    // Phase 2 quota bookkeeping. quotaCycleStart pins this request to the
    // specific 30-day bucket it was consumed from, so cancelRequest can
    // release the right one even if the user's cycle has since rolled over.
    quotaConsumed: {
      type: Boolean,
      default: false,
    },
    quotaCycleStart: {
      type: Date,
    },

    // Phase 3: on-demand quoting. "not_required" for included services —
    // set once at creation and never touched again for those. On-demand
    // requests move: pending -> submitted -> approved -> paid, or -> rejected.
    quote: {
      status: {
        type: String,
        enum: [
          "not_required",
          "pending",
          "submitted",
          "approved",
          "rejected",
          "paid",
        ],
        default: "not_required",
      },
      vendorAmount: Number,
      marginPercent: Number,
      marginAmount: Number,
      customerAmount: Number,
      notes: String,
      submittedAt: Date,
      respondedAt: Date,
    },

    description: String,

    address: String,

    preferredDate: Date,

    status: {
      type: String,

      enum: ["pending", "in-progress", "completed", "cancelled"],

      default: "pending",
    },

    priority: {
      type: String,

      enum: ["low", "normal", "high", "emergency"],

      default: "normal",
    },

    assignedTo: {
      type: String,
      default: "",
    },

    assignedStaffId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Staff",
    },

    assignedVendor: {
      type: String,
      default: "",
    },

    assignedVendorId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Vendor",
    },

    adminNotes: {
      type: String,
      default: "",
    },

    staffNotes: [
      {
        note: String,

        staffId: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "Staff",
        },

        createdAt: {
          type: Date,
          default: Date.now,
        },
      },
    ],

    vendorNotes: [
      {
        note: String,

        vendorId: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "Vendor",
        },

        createdAt: {
          type: Date,
          default: Date.now,
        },
      },
    ],

    completionPercentage: {
      type: Number,
      default: 0,
    },

    comments: [
      {
        message: String,
        createdAt: {
          type: Date,
          default: Date.now,
        },
      },
    ],

    jobPhotos: [
      {
        url: String,

        photoType: {
          type: String,
          enum: ["before", "after", "completion"],
        },

        uploadedBy: {
          type: String,
          default: "Vendor",
        },

        uploadedAt: {
          type: Date,
          default: Date.now,
        },
      },
    ],

    verificationStatus: {
      type: String,

      enum: ["pending", "submitted", "staff-approved", "approved", "rejected"],

      default: "pending",
    },

    completedAt: Date,

    auditLogs: [
      {
        action: String,

        actor: {
          type: String,
          default: "Admin",
        },

        createdAt: {
          type: Date,
          default: Date.now,
        },
      },
    ],
  },
  {
    timestamps: true,
  },
);

serviceRequestSchema.pre("save", function () {
  if (this.status === "cancelled") {
    this.completionPercentage = 0;
    return;
  }

  const hasAuditLog = (pattern) => {
    return (this.auditLogs || []).some(
      (log) =>
        log.action && log.action.toLowerCase().includes(pattern.toLowerCase()),
    );
  };

  const isRejected = this.verificationStatus === "rejected";

  const isStep1 =
    !!this.assignedTo ||
    !!this.assignedStaffId ||
    this.status !== "pending" ||
    hasAuditLog("Assigned to") ||
    hasAuditLog("Status changed");
  const isStep2 =
    !!this.assignedVendor ||
    !!this.assignedVendorId ||
    hasAuditLog("Vendor assigned");
  const isStep3 =
    (this.jobPhotos || []).some((p) => p.photoType === "before") ||
    hasAuditLog("photos uploaded") ||
    hasAuditLog("photo uploaded");
  const isStep4 = (this.jobPhotos || []).some((p) => p.photoType === "after");
  const isStep5 =
    (this.vendorNotes || []).length > 0 || hasAuditLog("Vendor note added");
  const isStep6 =
    !isRejected &&
    (this.verificationStatus === "submitted" ||
      this.verificationStatus === "staff-approved" ||
      this.verificationStatus === "approved" ||
      hasAuditLog("Completion submitted by vendor"));
  const isStep7 =
    !isRejected &&
    (this.verificationStatus === "submitted" ||
      this.verificationStatus === "staff-approved" ||
      this.verificationStatus === "approved" ||
      hasAuditLog("Waiting for staff verification"));
  const isStep8 =
    !isRejected &&
    ((this.staffNotes || []).length > 0 || hasAuditLog("Staff note added"));
  const isStep9 =
    !isRejected &&
    (this.verificationStatus === "staff-approved" ||
      this.verificationStatus === "approved" ||
      hasAuditLog("Completion verified by staff"));
  const isStep10 =
    !isRejected &&
    (this.verificationStatus === "approved" ||
      this.status === "completed" ||
      hasAuditLog("Completion approved by admin"));

  let s1 = isStep1;
  let s2 = isStep2;
  let s3 = isStep3;
  let s4 = isStep4;
  let s5 = isStep5;
  let s6 = isStep6;
  let s7 = isStep7;
  let s8 = isStep8;
  let s9 = isStep9;
  let s10 = isStep10;

  if (s10) {
    s9 = s8 = s7 = s6 = s5 = s4 = s3 = s2 = s1 = true;
  } else if (s9) {
    s8 = s7 = s6 = s5 = s4 = s3 = s2 = s1 = true;
  } else if (s7 || s6) {
    s5 = s4 = s3 = s2 = s1 = true;
  } else if (s4) {
    s3 = s2 = s1 = true;
  } else if (s3) {
    s2 = s1 = true;
  } else if (s2) {
    s1 = true;
  }

  let percentage = 0;
  if (s10) {
    percentage = 100;
  } else if (s9) {
    percentage = 90;
  } else if (s8) {
    percentage = 80;
  } else if (s7) {
    percentage = 70;
  } else if (s6) {
    percentage = 60;
  } else if (s5) {
    percentage = 50;
  } else if (s4) {
    percentage = 40;
  } else if (s3) {
    percentage = 30;
  } else if (s2) {
    percentage = 20;
  } else if (s1) {
    percentage = 10;
  } else {
    percentage = 0;
  }

  this.completionPercentage = percentage;
});

export default mongoose.model("ServiceRequest", serviceRequestSchema);

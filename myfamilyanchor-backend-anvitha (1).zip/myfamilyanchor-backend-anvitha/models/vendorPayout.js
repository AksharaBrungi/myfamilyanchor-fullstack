import mongoose from "mongoose";

const vendorPayoutSchema = new mongoose.Schema(
  {
    vendor: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Vendor",
      required: true,
    },

    serviceRequest: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "ServiceRequest",
      required: true,
    },

    amount: {
      type: Number,
      required: true,
    },

    status: {
      type: String,
      enum: ["pending", "released", "cancelled"],
      default: "pending",
    },

    releasedAt: Date,

    notes: {
      type: String,
      default: "",
    },
  },
  {
    timestamps: true,
  },
);

// Guards against "Cannot overwrite model once compiled" if this module
// ever gets evaluated twice in the same process (duplicate import path,
// a stray second copy of this file, or certain nodemon hot-reload edge
// cases). Safe to apply to any model, not just this one.
export default mongoose.models.VendorPayout ||
  mongoose.model("VendorPayout", vendorPayoutSchema);

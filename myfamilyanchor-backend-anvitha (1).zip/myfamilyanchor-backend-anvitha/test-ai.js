﻿import "dotenv/config";
import Anthropic from "@anthropic-ai/sdk";
import { createInterface } from "node:readline/promises";
import { stdin, stdout } from "node:process";

const terminal = createInterface({ input: stdin, output: stdout });
const workspaceId = (
  await terminal.question("Paste the FULL workspace ID (not API key): ")
).trim();
terminal.close();

if (
  !workspaceId.startsWith("wrkspc_") ||
  workspaceId.includes("...") ||
  workspaceId.includes("…") ||
  /\s/.test(workspaceId)
) {
  console.error("Please copy the full workspace ID from the Console.");
  process.exit(1);
}

const client = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
  timeout: 30000,
  maxRetries: 0,
});

try {
  console.log("Sending request with workspace header.");

  const models = await client.models.list({}, {
    headers: {
      "anthropic-workspace-id": workspaceId,
    },
  });

  console.log("SUCCESS: Anthropic API connected.");
  console.table(
    models.data.map((model) => ({
      id: model.id,
      name: model.display_name,
    }))
  );
} catch (error) {
  console.error("Status:", error.status ?? "Network/configuration error");
  console.error("Message:", error.message);
  process.exitCode = 1;
}

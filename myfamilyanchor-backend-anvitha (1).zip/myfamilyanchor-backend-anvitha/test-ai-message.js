﻿import dotenv from "dotenv";
import fs from "node:fs";
import Anthropic from "@anthropic-ai/sdk";
import { createInterface } from "node:readline/promises";
import { stdin, stdout } from "node:process";

dotenv.config();

const terminal = createInterface({ input: stdin, output: stdout });
const workspaceId = (
  await terminal.question("Paste the FULL workspace ID: ")
).trim();
terminal.close();

if (
  !workspaceId.startsWith("wrkspc_") ||
  workspaceId.includes("...") ||
  workspaceId.includes("…") ||
  /\s/.test(workspaceId)
) {
  console.error("Please use the full workspace ID.");
  process.exit(1);
}

const model = "claude-haiku-5-5";

let envText = fs.readFileSync(".env", "utf8");
for (const [name, value] of Object.entries({
  ANTHROPIC_WORKSPACE_ID: workspaceId,
  ANTHROPIC_MODEL: model,
})) {
  const pattern = new RegExp(`^\\s*${name}\\s*=.*$`, "gm");
  envText = envText.replace(pattern, "");
  envText = envText.trimEnd() + `\n${name}=${value}\n`;
}
fs.writeFileSync(".env", envText, "utf8");
console.log("Workspace and model settings saved.");

const client = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
  defaultHeaders: {
    "anthropic-workspace-id": workspaceId,
  },
  timeout: 30000,
  maxRetries: 0,
});

try {
  const reply = await client.messages.create({
    model,
    max_tokens: 100,
    messages: [{
      role: "user",
      content: "Reply with one short sentence confirming that this API connection works.",
    }],
  });

  console.log("\nAI REPLY:");
  for (const block of reply.content) {
    if (block.type === "text") console.log(block.text);
  }
  console.log("\nUsage:", reply.usage);
} catch (error) {
  console.error("Status:", error.status ?? "Network/configuration error");
  console.error("Message:", error.message);
  process.exitCode = 1;
}

// Pricing rules for on-demand quotes, per the Services & Pricing Framework:
// customer pays vendor's quoted amount + a platform coordination margin,
// with a loyalty discount on that margin for Guardian Premium.

const BASE_MARGIN_PERCENT = 20; // 15-25% range agreed — 20% is the default
const PREMIUM_MARGIN_DISCOUNT = 0.1; // 10% off the margin fee (relative), not off the vendor's price

export function getEffectiveMarginPercent(planName) {
  if (planName === "Guardian Premium") {
    return BASE_MARGIN_PERCENT * (1 - PREMIUM_MARGIN_DISCOUNT); // 18%
  }
  return BASE_MARGIN_PERCENT;
}

/**
 * vendorAmount = what the vendor is paid (their quoted job price).
 * customerAmount = what the customer is charged (vendorAmount + margin),
 * rounded to the nearest rupee since Razorpay works in paise anyway.
 */
export function computeQuoteAmounts(vendorAmount, planName) {
  const marginPercent = getEffectiveMarginPercent(planName);
  const marginAmount = Math.round((vendorAmount * marginPercent) / 100);
  const customerAmount = vendorAmount + marginAmount;

  return { vendorAmount, marginPercent, marginAmount, customerAmount };
}

// Server-side mirror of apps/website/src/data/planServices.js
//
// This is the SOURCE OF TRUTH for what a plan is allowed to request.
// The frontend catalog is for rendering the dropdown; this one is what
// actually gets enforced. If you add/rename a service, update both files
// (or, once the frontend build supports it, move this into packages/api
// and import it in both places instead of maintaining two copies).
//
// type:
//   "included"   -> covered by the flat monthly subscription, subject to
//                    a quota (see includedQuotas on the Plan model, Phase 2)
//   "on_demand"  -> requires a vendor quote + separate payment before
//                    work can begin (see quoteController, Phase 3)

export const SERVICE_CATALOG = {
  "Property Guardian": {
    property: [
      { name: "Property Inspection", type: "included" },
      { name: "Plumbing Support", type: "on_demand" },
      { name: "Electrical Repair", type: "on_demand" },
      { name: "Painting Service", type: "on_demand" },
      { name: "Gardening", type: "on_demand" },
      { name: "House Cleaning", type: "on_demand" },
      { name: "Pest Control", type: "on_demand" },
      { name: "Tenant Assistance", type: "on_demand" },
      { name: "Renovation Support", type: "on_demand" },
      { name: "Appliance Repair", type: "on_demand" },
      { name: "Water Tank Cleaning", type: "on_demand" },
      { name: "AC Servicing", type: "on_demand" },
      { name: "Emergency Property Visit", type: "included" },
    ],
  },

  "Family Guardian": {
    family: [
      { name: "Doctor Appointment", type: "on_demand" },
      { name: "Hospital Visit Support", type: "on_demand" },
      { name: "Medicine Delivery", type: "on_demand" },
      { name: "Companionship Visit", type: "included" },
      { name: "Emergency Assistance", type: "included" },
      { name: "Wellness Check", type: "included" },
      { name: "Diagnostic Test Support", type: "on_demand" },
      { name: "Bill Payment Assistance", type: "on_demand" },
      { name: "Grocery Assistance", type: "on_demand" },
      { name: "Teleconsultation Setup", type: "on_demand" },
      { name: "Senior Walk Companion", type: "on_demand" },
      { name: "Festival Visit", type: "on_demand" },
      { name: "Caregiver Assistance", type: "on_demand" },
    ],
  },

  "Guardian Premium": {
    property: [
      { name: "Property Inspection", type: "included" },
      { name: "Plumbing Support", type: "on_demand" },
      { name: "Electrical Repair", type: "on_demand" },
      { name: "Painting Service", type: "on_demand" },
      { name: "Gardening", type: "on_demand" },
      { name: "House Cleaning", type: "on_demand" },
      { name: "Pest Control", type: "on_demand" },
      { name: "Tenant Assistance", type: "on_demand" },
      { name: "Renovation Support", type: "on_demand" },
      { name: "Appliance Repair", type: "on_demand" },
    ],
    family: [
      { name: "Doctor Appointment", type: "on_demand" },
      { name: "Hospital Visit Support", type: "on_demand" },
      { name: "Medicine Delivery", type: "on_demand" },
      { name: "Companionship Visit", type: "included" },
      { name: "Emergency Assistance", type: "included" },
      { name: "Wellness Check", type: "included" },
    ],
    premium: [
      { name: "Dedicated Care Manager", type: "included" },
      { name: "Priority Emergency Response", type: "included" },
      { name: "Airport Pickup", type: "on_demand" },
      { name: "Travel Assistance", type: "on_demand" },
      { name: "VIP Hospital Support", type: "on_demand" },
      { name: "Multi Property Management", type: "on_demand" },
      { name: "Premium Concierge", type: "included" },
      { name: "Luxury Property Inspection", type: "on_demand" },
      { name: "Relationship Manager Call", type: "included" },
      { name: "Special Care Assistance", type: "on_demand" },
      { name: "Event Coordination", type: "on_demand" },
    ],
  },
};

/**
 * Returns the catalog entry for a given plan + category + serviceType,
 * or null if that combination isn't valid. Use this instead of trusting
 * req.body.serviceType directly.
 */
export function findServiceEntry(planName, category, serviceType) {
  const categories = SERVICE_CATALOG[planName];
  if (!categories) return null;

  const services = categories[category];
  if (!services) return null;

  return services.find((s) => s.name === serviceType) || null;
}

/**
 * Convenience helper: which categories a plan can access at all.
 * Mirrors the planAccess map that already lives inline in
 * serviceController.js — kept here so there's one place to update.
 */
export function getAllowedCategories(planName) {
  const categories = SERVICE_CATALOG[planName];
  return categories ? Object.keys(categories) : [];
}

// Quota limits for "included" services, per plan.
//
// A number = how many times this service can be requested per 30-day
// cycle before it becomes chargeable/blocked.
// null      = unlimited coordination effort (e.g. emergency response —
//              the ACT of coordinating is free; any resulting on-demand
//              work is billed separately once Phase 3 quoting exists).
//
// NOTE: the Plan model already has a `features` string array and could
// theoretically hold this, but plan names are hardcoded strings all over
// this codebase already (see the old planAccess maps we just removed) —
// the Plan collection isn't actually queried anywhere today. Rather than
// make quota enforcement depend on a DB collection that may not even be
// seeded in production, this lives here as static config, same as
// serviceCatalog.js. If/when you build an admin UI for editable plans,
// migrate both files into the Plan document schema at that point.

export const INCLUDED_QUOTAS = {
  "Property Guardian": {
    "Property Inspection": 1,
    "Emergency Property Visit": null,
  },

  "Family Guardian": {
    "Companionship Visit": 4,
    "Wellness Check": 4,
    "Emergency Assistance": null,
  },

  "Guardian Premium": {
    "Property Inspection": 1,
    "Emergency Property Visit": null,
    "Companionship Visit": 4,
    "Wellness Check": 4,
    "Emergency Assistance": null,
    "Dedicated Care Manager": null,
    "Priority Emergency Response": null,
    "Premium Concierge": null,
    "Relationship Manager Call": 4,
  },
};

/**
 * Returns the numeric limit, null (unlimited), or undefined (not an
 * included service at all / not configured — caller should treat this
 * as "don't enforce a quota" but it's worth logging, since it usually
 * means serviceCatalog.js and this file drifted out of sync).
 */
export function getQuotaLimit(planName, serviceType) {
  const planQuotas = INCLUDED_QUOTAS[planName];
  if (!planQuotas) return undefined;
  return planQuotas[serviceType];
}

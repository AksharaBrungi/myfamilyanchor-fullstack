﻿import aiRoutes from "./routes/aiRoutes.js";
import dotenv from "dotenv";
dotenv.config();

import express from "express";
import cors from "cors";
import http from "http";
import helmet from "helmet";

import { initSocket } from "./socket/socket.js";
import connectDB from "./config/db.js";

import paymentRoutes from "./routes/paymentRoutes.js";
import authRoutes from "./routes/authRoutes.js";
import userRoutes from "./routes/userRoutes.js";
import adminRoutes from "./routes/adminRoutes.js";
import serviceRoutes from "./routes/serviceRoutes.js";
import quotaRoutes from "./routes/quotaRoutes.js";
import quoteRoutes from "./routes/quoteRoutes.js";
import staffRoutes from "./routes/staffRoutes.js";
import staffAuthRoutes from "./routes/staffAuthRoutes.js";
import vendorRoutes from "./routes/vendorRoutes.js";
import vendorAuthRoutes from "./routes/vendorAuthRoutes.js";
import whatsappRoutes from "./routes/whatsappRoutes.js";
import contactRoutes from "./routes/contactRoutes.js";
import bookingRoutes from "./routes/bookingRoutes.js";
import subscribeRoutes from "./routes/SubscribeRoutes.js";
import newsletterRoutes from "./routes/newsletterRoutes.js";
import forgotPasswordRoutes from "./routes/forgotPasswordRoutes.js";

connectDB();

const app = express();

// helmet must come before any routes
app.use(helmet());

// CORS was hardcoded to localhost â€” now reads from env for production
const allowedOrigins = process.env.ALLOWED_ORIGINS
  ? process.env.ALLOWED_ORIGINS.split(",").map((o) => o.trim())
  : ["http://localhost:5173"];

app.use(
  cors({
    origin: (origin, callback) => {
      // Allow requests with no origin (curl, mobile apps, Postman)
      if (!origin) return callback(null, true);
      if (allowedOrigins.includes(origin)) {
        return callback(null, true);
      }
      callback(new Error(`CORS blocked for origin: ${origin}`));
    },
    credentials: true,
  }),
);

app.use(express.json({ limit: "10kb" })); // limit body size to prevent payload attacks

app.use("/api/ai", aiRoutes);
app.use("/api/payment", paymentRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/user", userRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/services", serviceRoutes);
app.use("/api/quota", quotaRoutes);
app.use("/api/quotes", quoteRoutes);
app.use("/api/staff", staffRoutes);
app.use("/api/staff-auth", staffAuthRoutes);
app.use("/api/vendors", vendorRoutes);
app.use("/api/vendors/auth", vendorAuthRoutes);
app.use("/api/whatsapp", whatsappRoutes);
app.use("/api/contact", contactRoutes);
app.use("/api/booking", bookingRoutes);
app.use("/api/subscribe", subscribeRoutes);
app.use("/api/newsletter", newsletterRoutes);
app.use("/api/forgot-password", forgotPasswordRoutes);

// Global error handler â€” prevents stack traces leaking to client in production
app.use((err, req, res, next) => {
  console.error("Unhandled error:", err);
  const status = err.status || 500;
  const message =
    process.env.NODE_ENV === "production"
      ? "Something went wrong"
      : err.message;
  res.status(status).json({ message });
});

app.get("/", (req, res) => {
  res.send("API Running");
});

const PORT = process.env.PORT || 5000;

const server = http.createServer(app);

const io = initSocket(server);

app.use((req, res, next) => {
  req.io = io;
  next();
});

server.listen(PORT, () => {
  console.log(
    `Server running on port ${PORT} [${process.env.NODE_ENV || "development"}]`,
  );
});


﻿import { SERVICE_CATALOG } from "../../constants/serviceCatalog.js";
import { getQuotaLimit } from "../../constants/planQuotas.js";

export function getDemoReply(message) {
  if (typeof message !== "string" || !message.trim()) {
    throw new Error("Please enter a message.");
  }

  const text = message.trim().toLowerCase();
  const plans = Object.keys(SERVICE_CATALOG);

  const result = (reply) => ({
    mode: "demo",
    label: "Demo mode - scripted replies",
    reply,
  });

  // Account access will be connected separately through authenticated tools.
  if (/\b(my|remaining|left|status|book|booking|request)\b/.test(text)) {
    return result(
      "Account lookups and booking are not connected in this demo yet. " +
      "No account data was accessed and no service request was created. " +
      "You can ask me to list plans or explain a plan's services."
    );
  }

  const selectedPlan = plans.find((plan) =>
    text.includes(plan.toLowerCase())
  );

  if (selectedPlan) {
    const lines = [selectedPlan];

    for (const [category, services] of Object.entries(
      SERVICE_CATALOG[selectedPlan]
    )) {
      lines.push(`\n${category.toUpperCase()}`);

      for (const service of services) {
        let details;

        if (service.type === "on_demand") {
          details = "Vendor quote and separate payment required";
        } else {
          const limit = getQuotaLimit(selectedPlan, service.name);

          if (limit === null) {
            details =
              "Unlimited coordination; resulting paid work costs extra";
          } else if (typeof limit === "number") {
            details = `${limit} included per 30-day cycle`;
          } else {
            details = "Included; allowance needs confirmation from support";
          }
        }

        lines.push(`- ${service.name}: ${details}`);
      }
    }

    return result(lines.join("\n"));
  }

  if (/\b(plan|plans|service|services)\b/.test(text)) {
    return result(
      "Available plans:\n" +
      plans.map((plan) => `- ${plan}`).join("\n") +
      "\n\nType a full plan name to see its services and allowances."
    );
  }

  return result(
    "Hello! This is the MyFamilyAnchor demo assistant. " +
    "These are scripted replies, not live AI responses. " +
    'Try "Show plans" or "Explain Family Guardian".'
  );
}

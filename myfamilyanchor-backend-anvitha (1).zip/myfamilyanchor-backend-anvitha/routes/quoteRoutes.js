import express from "express";
import { protect } from "../middleware/authMiddleware.js";
import vendorProtect from "../middleware/vendorMiddleware.js";
import {
  submitQuote,
  approveQuote,
  rejectQuote,
} from "../controllers/quoteController.js";

const router = express.Router();

router.post("/:id/submit", vendorProtect, submitQuote);

router.put("/:id/approve", protect, approveQuote);

router.put("/:id/reject", protect, rejectQuote);

export default router;

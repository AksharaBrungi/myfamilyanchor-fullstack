import express from "express";
import { body } from "express-validator";
import {
  registerUser,
  loginUser,
  getCurrentUser,
  updateProfile,
  changePassword,
  verifyPassword,
} from "../controllers/authController.js";
import { protect } from "../middleware/authMiddleware.js";
import { authLimiter } from "../middleware/rateLimiter.js";

const router = express.Router();

router.post(
  "/register",
  authLimiter,

  [
    body("name").notEmpty(),

    body("email").isEmail(),

    body("password").isLength({
      min: 6,
    }),
  ],

  registerUser,
);

router.post(
  "/login",
  authLimiter,
  [body("identifier").notEmpty(), body("password").notEmpty()],
  loginUser,
);

router.put("/profile", protect, updateProfile);

router.put("/change-password", protect, changePassword);

router.post("/verify-password", protect, verifyPassword);

router.get("/me", protect, getCurrentUser);

export default router;

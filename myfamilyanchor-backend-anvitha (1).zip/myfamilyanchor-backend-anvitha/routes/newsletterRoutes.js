import express from "express";
import adminProtect from "../middleware/adminMiddleware.js";
import {
  sendNewsletter,
  getNewsletterHistory,
  getTemplates,
  getNewsletterStats,
  sendTestNewsletter,
} from "../controllers/newsletterController.js";

const router = express.Router();

router.post("/send", adminProtect, sendNewsletter);

router.get("/history", adminProtect, getNewsletterHistory);

router.get("/templates", adminProtect, getTemplates);

router.get("/stats", adminProtect, getNewsletterStats);

router.post("/test", adminProtect, sendTestNewsletter);

export default router;

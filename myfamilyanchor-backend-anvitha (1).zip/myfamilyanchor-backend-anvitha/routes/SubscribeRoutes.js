import express from "express";

import {
  subscribe,
  getSubscribers,
  deactivateSubscriber,
  activateSubscriber,
  deleteSubscriber,
} from "../controllers/subscribeController.js";

import adminProtect from "../middleware/adminMiddleware.js";

const router = express.Router();

router.post("/", subscribe);

router.get("/all", adminProtect, getSubscribers);

router.put("/:id/deactivate", adminProtect, deactivateSubscriber);

router.put("/:id/activate", adminProtect, activateSubscriber);

router.delete("/:id", adminProtect, deleteSubscriber);

export default router;

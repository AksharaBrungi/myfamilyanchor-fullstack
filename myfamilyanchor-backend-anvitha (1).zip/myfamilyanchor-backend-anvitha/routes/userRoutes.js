import express from "express";
import { protect, activeSubscription } from "../middleware/authMiddleware.js";
import { getDashboardData } from "../controllers/userController.js";

const router = express.Router();

router.get("/dashboard", protect, activeSubscription, getDashboardData);

export default router;

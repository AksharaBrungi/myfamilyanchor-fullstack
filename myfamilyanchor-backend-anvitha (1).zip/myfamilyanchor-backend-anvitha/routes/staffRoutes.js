import express from "express";
import adminProtect from "../middleware/adminMiddleware.js";
import staffProtect from "../middleware/staffMiddleware.js";

import {
  createStaff,
  getAllStaff,
  updateStaff,
  deleteStaff,
  getAssignedRequests,
  updateStaffRequestStatus,
  addStaffNote,
} from "../controllers/staffController.js";

const router = express.Router();

router.get("/", adminProtect, getAllStaff);

router.post("/", adminProtect, createStaff);

router.put("/:id", adminProtect, updateStaff);

router.delete("/:id", adminProtect, deleteStaff);

router.get("/requests", staffProtect, getAssignedRequests);

router.put("/requests/:id", staffProtect, updateStaffRequestStatus);

router.post("/requests/:id/notes", staffProtect, addStaffNote);

export default router;

import express from "express";
import {
  vendorLogin,
  getVendorProfile,
} from "../controllers/vendorAuthController.js";
import vendorProtect from "../middleware/vendorMiddleware.js";

const router = express.Router();

router.post("/login", vendorLogin);

router.get("/me", vendorProtect, getVendorProfile);

export default router; 

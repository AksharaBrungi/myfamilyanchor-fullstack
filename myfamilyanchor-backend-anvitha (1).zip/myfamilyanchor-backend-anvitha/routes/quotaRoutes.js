import express from "express";
import { protect } from "../middleware/authMiddleware.js";
import { getMyQuotaUsage } from "../controllers/quotaController.js";

const router = express.Router();

router.get("/usage", protect, getMyQuotaUsage);

export default router;

import express from "express";
import { protect } from "../middleware/authMiddleware.js";
import adminProtect from "../middleware/adminMiddleware.js";
import {
  createRequest,
  getUserRequests,
  getAllRequests,
  cancelRequest,
  editRequestService,
  updateRequestStatus,
  updateRequestMeta,
  addComment,
} from "../controllers/serviceController.js";

const router = express.Router();

router.post("/create", protect, createRequest);

router.get("/my-requests", protect, getUserRequests);

router.put("/cancel/:id", protect, cancelRequest);

router.put("/edit-service/:id", protect, editRequestService);

router.get("/all", adminProtect, getAllRequests);

router.put("/update/:id", adminProtect, updateRequestStatus);

router.put("/meta/:id", adminProtect, updateRequestMeta);

router.put("/comment/:id", adminProtect, addComment);

export default router;

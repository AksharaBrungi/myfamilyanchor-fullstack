import express from "express";
import sendWhatsApp from "../utils/sendWhatsApp.js";

const router = express.Router();

router.get("/test", async (req, res) => {
  try {
    const result = await sendWhatsApp({
      // to: process.env.ADMIN_PHONE,
      to: process.env.ADMIN_WHATSAPP_NUMBER,
      template: "booking_confirmation",
      parameters: [customerName, bookingDate, bookingTime],
      messageData: "✅ MyFamilyAnchor Meta WhatsApp Cloud API is working",
    });

    res.json(result);
  } catch (err) {
    res.status(500).json({
      error: err.message,
    });
  }
});

export default router;

﻿
import express from "express";
import { getDemoReply } from "../services/ai/demo.js";
import { streamGeminiReply } from "../services/ai/gemini.js";
import { protect } from "../middleware/authMiddleware.js";
import ServiceRequest from "../models/ServiceRequest.js";

const router = express.Router();

router.post("/chat", async (req, res) => {
  const message = req.body?.message;

  if (
    typeof message !== "string" ||
    !message.trim() ||
    message.length > 1000
  ) {
    return res.status(400).json({
      message: "Enter a message between 1 and 1000 characters.",
    });
  }

  const cleanMessage = message.trim();

  console.log("AI CHAT MESSAGE:", cleanMessage);
  res.set("Cache-Control", "no-store");

  // Scripted demo mode.
  if (process.env.AI_MODE === "demo") {
    const fallback = getDemoReply(cleanMessage);
    return res.status(200).type("text/plain").send(fallback.reply);
  }

  // Live mode requires authentication.
  return protect(req, res, async () => {
    try {
      const planName = req.user?.currentPlan;

      if (!planName) {
        return res.status(403).json({
          message:
            "We couldn't verify your current plan. Please contact support.",
        });
      }

      // Retrieve the authenticated customer's service requests.
      const wantsStatus =
        /\b(status|track|tracking|progress|update)\b/i.test(cleanMessage) &&
        /\b(request|service|booking|order)\b/i.test(cleanMessage);

      console.log("STATUS REQUEST DETECTED:", wantsStatus);

      if (wantsStatus) {
        const requests = await ServiceRequest.find({
          user: req.user._id,
        })
          .sort({ createdAt: -1 })
          .limit(5)
          .select(
            "serviceType category status completionPercentage createdAt"
          )
          .lean();

        console.log("USER REQUEST COUNT:", requests.length);

        if (requests.length === 0) {
          return res
            .status(200)
            .type("text/plain")
            .send(
              "I couldn't find any service requests on your account yet. " +
                "You can submit a request through the MyFamilyAnchor website."
            );
        }

        const reply =
          "Here are your latest service requests:\n\n" +
          requests
            .map((request, index) => {
              const submitted = request.createdAt
                ? new Date(request.createdAt).toLocaleDateString("en-IN")
                : "Date unavailable";

              const progress =
                typeof request.completionPercentage === "number"
                  ? `\nProgress: ${request.completionPercentage}%`
                  : "";

              return (
                `${index + 1}. ${request.serviceType || "Service request"}` +
                `${request.category ? ` (${request.category})` : ""}\n` +
                `Status: ${request.status || "Unavailable"}` +
                `${progress}\n` +
                `Submitted: ${submitted}\n` +
                `Request ID: ${request._id}`
              );
            })
            .join("\n\n") +
          "\n\nThese are the current statuses recorded in our system. " +
          "A requested date does not necessarily mean the booking is confirmed.";

        return res.status(200).type("text/plain").send(reply);
      }

      // Ask Gemini for general support questions.
      console.log("Sending non-status question to Gemini.");

      let stream;

      try {
        stream = await streamGeminiReply(cleanMessage, planName);
      } catch (error) {
        console.error("Gemini request failed:", error.message);

        // Fall back to scripted replies for quota and temporary service errors.
        const shouldUseFallback =
          error.message?.includes("RESOURCE_EXHAUSTED") ||
          error.message?.includes("429") ||
          error.message?.includes("UNAVAILABLE") ||
          error.message?.includes("503") ||
          error.status === 429 ||
          error.status === 503 ||
          error.code === 429 ||
          error.code === 503;

        if (shouldUseFallback) {
          const fallback = getDemoReply(cleanMessage);
          return res
            .status(200)
            .type("text/plain")
            .send(fallback.reply);
        }

        return res.status(503).json({
          message:
            "The AI assistant is temporarily unavailable. Please try again.",
        });
      }

      // Stream Gemini's response to the website.
      res.status(200);
      res.set({
        "Content-Type": "text/plain; charset=utf-8",
        "Transfer-Encoding": "chunked",
        "X-Accel-Buffering": "no",
      });

      try {
        for await (const chunk of stream) {
          if (chunk.text) {
            res.write(chunk.text);
          }
        }

        return res.end();
      } catch (error) {
        console.error("Gemini streaming failed:", error.message);

        // A fallback is possible only before response headers are sent.
        if (!res.headersSent) {
          const fallback = getDemoReply(cleanMessage);
          return res
            .status(200)
            .type("text/plain")
            .send(fallback.reply);
        }

        return res.end();
      }
    } catch (error) {
      console.error("AI assistant error:", error.message);

      if (!res.headersSent) {
        return res.status(503).json({
          message:
            "The AI assistant is temporarily unavailable. Please try again.",
        });
      }

      return res.end();
    }
  });
});

export default router;

import express from "express";
import {
  requestOTP,
  verifyOTPAndMark,
  resetPassword,
} from "../controllers/forgotPasswordController.js";

const router = express.Router();

// POST /forgot-password/request-otp
// Body: { identifier: "email or phone", role: "user|admin|staff|vendor" }
router.post("/request-otp", requestOTP);

// POST /forgot-password/verify-otp
// Body: { identifier, otp, role }
router.post("/verify-otp", verifyOTPAndMark);

// POST /forgot-password/reset
// Body: { identifier, newPassword, role }
router.post("/reset", resetPassword);

export default router;

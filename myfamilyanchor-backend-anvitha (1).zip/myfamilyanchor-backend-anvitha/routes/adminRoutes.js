import express from "express";
import {
  adminLogin,
  getAdminDashboard,
  updateAdminProfile,
  changeAdminPassword,
  verifyAdminPassword,
  getAdminProfile,
  approveCompletion,
  rejectCompletion,
} from "../controllers/adminController.js";
import adminProtect from "../middleware/adminMiddleware.js";

const router = express.Router();

router.post("/login", adminLogin);

router.get("/dashboard", adminProtect, getAdminDashboard);

router.put("/profile", adminProtect, updateAdminProfile);

router.put("/change-password", adminProtect, changeAdminPassword);

router.post("/verify-password", adminProtect, verifyAdminPassword);

router.get("/me", adminProtect, getAdminProfile);

router.put("/requests/:id/approve", adminProtect, approveCompletion);

router.put("/requests/:id/reject", adminProtect, rejectCompletion);

export default router;

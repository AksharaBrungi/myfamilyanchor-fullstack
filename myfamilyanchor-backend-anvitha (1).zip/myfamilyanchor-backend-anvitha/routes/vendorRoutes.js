import express from "express";
import adminProtect from "../middleware/adminMiddleware.js";
import vendorProtect from "../middleware/vendorMiddleware.js";
import upload from "../middleware/uploadMiddleware.js";

import {
  createVendor,
  getAllVendors,
  updateVendor,
  deleteVendor,
  createCategory,
  getCategories,
  seedCategories,
  getAssignedVendorJobs,
  addVendorNote,
  uploadJobPhotos,
  requestCompletion,
} from "../controllers/vendorController.js";

const router = express.Router();

router.get("/", adminProtect, getAllVendors);

router.post("/", adminProtect, createVendor);

router.put("/:id", adminProtect, updateVendor);

router.delete("/:id", adminProtect, deleteVendor);

router.get("/categories/list", adminProtect, getCategories);

router.post("/categories", adminProtect, createCategory);

router.post("/categories/seed", adminProtect, seedCategories);

router.get("/jobs", vendorProtect, getAssignedVendorJobs);

router.post("/jobs/:id/notes", vendorProtect, addVendorNote);

router.post(
  "/jobs/:id/photos",
  vendorProtect,
  upload.array("photos", 10),
  uploadJobPhotos,
);

router.post("/jobs/:id/request-completion", vendorProtect, requestCompletion);

export default router;

import express from "express";
import {
  createOrder,
  verifyPayment,
  createOnDemandOrder,
  verifyOnDemandPayment,
} from "../controllers/paymentController.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

router.post("/create-order", protect, createOrder);

router.post("/verify", protect, verifyPayment);

// Phase 3: on-demand job payments, billed against an approved quote.
router.post("/on-demand/:id/create-order", protect, createOnDemandOrder);

router.post("/on-demand/:id/verify", protect, verifyOnDemandPayment);

export default router;

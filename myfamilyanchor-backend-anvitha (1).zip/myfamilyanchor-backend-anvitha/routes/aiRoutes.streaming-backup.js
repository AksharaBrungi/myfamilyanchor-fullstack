﻿import express from "express";
import { getDemoReply } from "../services/ai/demo.js";
import { getGeminiReply } from "../services/ai/gemini.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

router.post("/chat", async (req, res) => {
  const message = req.body?.message;

  if (
    typeof message !== "string" ||
    !message.trim() ||
    message.length > 1000
  ) {
    return res.status(400).json({
      message: "Enter a message between 1 and 1000 characters.",
    });
  }

  res.set("Cache-Control", "no-store");

  if (process.env.AI_MODE === "demo") {
    return res.json(getDemoReply(message));
  }

  return protect(req, res, async () => {
    try {
      const result = await getGeminiReply(
        message.trim(),
        req.user.currentPlan
      );
      return res.json(result);
    } catch (error) {
      console.error("Gemini chatbot error:", error.message);

      return res.status(503).json({
        mode: "error",
        message: "The AI assistant is temporarily unavailable. Please try again.",
      });
    }
  });
});

export default router;

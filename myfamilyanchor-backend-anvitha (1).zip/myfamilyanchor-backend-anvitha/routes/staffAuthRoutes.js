import express from "express";

import {
  staffLogin,
  getStaffProfile,
} from "../controllers/staffAuthController.js";

import staffProtect from "../middleware/staffMiddleware.js";

const router = express.Router();

router.post("/login", staffLogin);

router.get("/me", staffProtect, getStaffProfile);

export default router;

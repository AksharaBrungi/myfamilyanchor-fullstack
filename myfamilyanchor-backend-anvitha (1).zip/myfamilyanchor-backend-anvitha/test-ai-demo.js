﻿import { getDemoReply } from "./services/ai/demo.js";

for (const question of [
  "Show plans",
  "Explain Family Guardian",
  "How many visits do I have left?",
]) {
  console.log("\nQUESTION:", question);
  const response = getDemoReply(question);
  console.log(response.label);
  console.log(response.reply);
}

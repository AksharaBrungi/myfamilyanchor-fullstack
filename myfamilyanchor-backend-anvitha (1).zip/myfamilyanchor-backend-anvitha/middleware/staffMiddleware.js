import jwt from "jsonwebtoken";
import Staff from "../models/Staff.js";

const staffProtect = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({
        message: "Not authorized",
      });
    }

    const token = authHeader.split(" ")[1];

    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const staff = await Staff.findById(decoded.id).select("-password");

    if (!staff) {
      return res.status(401).json({
        message: "Staff not found",
      });
    }

    req.staff = staff;

    next();
  } catch (error) {
    res.status(401).json({
      message: "Not authorized",
    });
  }
};

export default staffProtect;

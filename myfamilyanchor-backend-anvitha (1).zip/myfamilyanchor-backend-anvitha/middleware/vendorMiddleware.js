import jwt from "jsonwebtoken";
import Vendor from "../models/vendor.js";

const vendorProtect = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({
        message: "Not authorized",
      });
    }

    const token = authHeader.split(" ")[1];

    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const vendor = await Vendor.findById(decoded.id).select("-password");

    if (!vendor) {
      return res.status(401).json({
        message: "Vendor not found",
      });
    }

    req.vendor = vendor;

    next();
  } catch {
    res.status(401).json({
      message: "Not authorized",
    });
  }
};

export default vendorProtect;

import jwt from "jsonwebtoken";
import User from "../models/User.js";

export const protect = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ message: "Not authorized, no token" });
    }

    const token = authHeader.split(" ")[1];

    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (err) {
      // Distinguish expired vs invalid
      if (err.name === "TokenExpiredError") {
        return res.status(401).json({ message: "Token expired, please log in again" });
      }
      return res.status(401).json({ message: "Token invalid" });
    }

    // was decoded.id but userController uses req.user._id — ensure both work
    const user = await User.findById(decoded.id).select("-password");

    if (!user) {
      return res.status(401).json({ message: "User not found" });
    }

    req.user = user; // user._id, user.name etc. all available downstream
    next();
  } catch (error) {
    console.error("protect middleware error:", error);
    res.status(401).json({ message: "Not authorized" });
  }
};

export const activeSubscription = async (req, res, next) => {
  try {
    if (!req.user.paymentCompleted || req.user.subscriptionStatus !== "active") {
      return res.status(403).json({
        message: "Active subscription required",
        requiresPayment: !req.user.paymentCompleted,
      });
    }
    next();
  } catch (error) {
    console.error("activeSubscription middleware error:", error);
    res.status(500).json({ message: "Server error" });
  }
};

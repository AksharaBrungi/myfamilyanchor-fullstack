import QuotaUsage from "../models/QuotaUsage.js";
import { getQuotaLimit } from "../constants/planQuotas.js";

const CYCLE_LENGTH_MS = 30 * 24 * 60 * 60 * 1000; // 30 days

/**
 * Rolls a user's cycle anchor forward to find the 30-day window that
 * "now" currently falls in. Independent of billingCycle (monthly/yearly)
 * on purpose — included visits are a monthly cadence regardless of how
 * the subscription itself is billed.
 *
 * Returns null if the user has no active cycle anchor (never paid).
 */
export function getCurrentCycleBounds(user, now = new Date()) {
  if (!user?.currentCycleStartedAt) return null;

  let start = new Date(user.currentCycleStartedAt);

  // Fast-forward in whole cycle lengths rather than looping day-by-day.
  const elapsed = now.getTime() - start.getTime();
  if (elapsed > 0) {
    const cyclesElapsed = Math.floor(elapsed / CYCLE_LENGTH_MS);
    start = new Date(start.getTime() + cyclesElapsed * CYCLE_LENGTH_MS);
  }

  const end = new Date(start.getTime() + CYCLE_LENGTH_MS);
  return { start, end };
}

/**
 * Checks quota for an included service and atomically consumes one unit
 * if available. Safe under concurrent requests from the same user:
 *
 *   1. Ensure a usage bucket exists for this cycle (upsert, no increment).
 *   2. Atomically increment ONLY if usedCount < limit — the $lt filter
 *      and $inc happen as a single atomic operation, so two simultaneous
 *      requests can't both slip through when only one slot is left.
 *
 * Returns:
 *   { allowed: true,  unlimited: true }                     - no cap configured
 *   { allowed: true,  cycleStart, limit, remaining }         - consumed one unit
 *   { allowed: false, reason, limit, used }                  - quota exhausted
 *   { allowed: false, reason: "no-active-cycle" }             - user never paid
 */
export async function checkAndConsumeQuota({
  user,
  planName,
  serviceType,
  category,
}) {
  const limit = getQuotaLimit(planName, serviceType);

  if (limit === undefined) {
    console.warn(
      `[quotaService] No quota configured for "${serviceType}" on plan "${planName}" — allowing without a cap. Check constants/planQuotas.js.`,
    );
    return { allowed: true, unlimited: true };
  }

  if (limit === null) {
    return { allowed: true, unlimited: true };
  }

  const cycle = getCurrentCycleBounds(user);
  if (!cycle) {
    return { allowed: false, reason: "no-active-cycle" };
  }

  // Step 1: ensure the bucket exists. Ignore duplicate-key races — it
  // just means another concurrent request created it first.
  try {
    await QuotaUsage.findOneAndUpdate(
      { user: user._id, serviceType, cycleStart: cycle.start },
      {
        $setOnInsert: {
          category,
          cycleEnd: cycle.end,
          usedCount: 0,
        },
      },
      { upsert: true },
    );
  } catch (err) {
    if (err.code !== 11000) throw err;
  }

  // Step 2: the actual atomic check-and-increment.
  const updated = await QuotaUsage.findOneAndUpdate(
    {
      user: user._id,
      serviceType,
      cycleStart: cycle.start,
      usedCount: { $lt: limit },
    },
    { $inc: { usedCount: 1 } },
    { new: true },
  );

  if (!updated) {
    const current = await QuotaUsage.findOne({
      user: user._id,
      serviceType,
      cycleStart: cycle.start,
    });
    return {
      allowed: false,
      reason: "quota-exhausted",
      limit,
      used: current?.usedCount ?? limit,
      cycleEnd: cycle.end,
    };
  }

  return {
    allowed: true,
    cycleStart: cycle.start,
    limit,
    remaining: limit - updated.usedCount,
  };
}

/**
 * Releases one consumed unit back to the user's quota — used when a
 * request that had consumed quota gets cancelled before any work started.
 * No-ops safely if there's nothing to release (usedCount already at 0,
 * or no bucket for that cycle).
 */
export async function releaseQuota({ user, serviceType, cycleStart }) {
  if (!cycleStart) return;

  await QuotaUsage.findOneAndUpdate(
    {
      user: user._id,
      serviceType,
      cycleStart,
      usedCount: { $gt: 0 },
    },
    { $inc: { usedCount: -1 } },
  );
}

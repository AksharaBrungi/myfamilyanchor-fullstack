import nodemailer from "nodemailer";
import twilio from "twilio";
import crypto from "crypto";

// OTP Store (in-memory; swap for Redis in production)
// Key: `${role}:${identifier}` → { otp, hashedOtp, expiresAt, attempts }
const otpStore = new Map();

const OTP_EXPIRY_MS = 10 * 60 * 1000; // 10 minutes
const MAX_VERIFY_ATTEMPTS = 5;

// Helpers
export function generateOTP() {
  return crypto.randomInt(100000, 999999).toString();
}

function hashOTP(otp) {
  return crypto.createHash("sha256").update(otp).digest("hex");
}

export function storeOTP(role, identifier) {
  const otp = generateOTP();
  const key = `${role}:${identifier.toLowerCase()}`;

  otpStore.set(key, {
    hashedOtp: hashOTP(otp),
    expiresAt: Date.now() + OTP_EXPIRY_MS,
    attempts: 0,
  });

  return otp; // raw OTP — only sent to user, never stored plain
}

export function verifyOTP(role, identifier, inputOtp) {
  const key = `${role}:${identifier.toLowerCase()}`;
  const record = otpStore.get(key);

  if (!record) {
    return { valid: false, reason: "No OTP found. Please request a new one." };
  }

  if (Date.now() > record.expiresAt) {
    otpStore.delete(key);
    return {
      valid: false,
      reason: "OTP has expired. Please request a new one.",
    };
  }

  record.attempts += 1;

  if (record.attempts > MAX_VERIFY_ATTEMPTS) {
    otpStore.delete(key);
    return {
      valid: false,
      reason: "Too many attempts. Please request a new OTP.",
    };
  }

  if (hashOTP(inputOtp) !== record.hashedOtp) {
    return { valid: false, reason: "Incorrect OTP. Please try again." };
  }

  // Valid — remove from store (single-use)
  otpStore.delete(key);
  return { valid: true };
}

// Gmail
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

export async function sendOTPEmail(toEmail, otp, role) {
  const roleLabel =
    role === "admin"
      ? "Admin"
      : role === "staff"
        ? "Staff"
        : role === "vendor"
          ? "Vendor"
          : "Customer";

  await transporter.sendMail({
    from: `"MyFamilyAnchor" <${process.env.GMAIL_USER}>`,
    to: toEmail,
    subject: "Your Password Reset OTP – MyFamilyAnchor",
    html: `
      <div style="font-family:Arial,sans-serif;max-width:480px;margin:0 auto;padding:32px;background:#f8f3ff;border-radius:16px;">
        <h2 style="color:#7b3ff2;margin-bottom:4px;">MyFamilyAnchor</h2>
        <p style="color:#888;font-size:13px;margin-top:0;">${roleLabel} Portal</p>
        <hr style="border:none;border-top:1px solid #e5d9ff;margin:20px 0;" />
        <p style="font-size:15px;color:#333;">Hi there,</p>
        <p style="font-size:15px;color:#333;">
          Use the OTP below to reset your password. It expires in <strong>10 minutes</strong>.
        </p>
        <div style="text-align:center;margin:32px 0;">
          <span style="
            display:inline-block;
            font-size:36px;
            font-weight:800;
            letter-spacing:10px;
            color:#7b3ff2;
            background:white;
            padding:16px 32px;
            border-radius:12px;
            border:2px solid #e5d9ff;
          ">${otp}</span>
        </div>
        <p style="font-size:13px;color:#999;">
          If you didn't request this, you can safely ignore this email.
        </p>
      </div>
    `,
  });
}

// WhatsApp (Twilio)
const twilioClient = twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN,
);

export async function sendOTPWhatsApp(toPhone, otp, role) {
  const roleLabel =
    role === "admin"
      ? "Admin"
      : role === "staff"
        ? "Staff"
        : role === "vendor"
          ? "Vendor"
          : "Customer";

  // Normalize: ensure E.164 format
  let normalized = toPhone.trim();
  if (/^\d{10}$/.test(normalized)) {
    normalized = `+91${normalized}`;
  }

  await twilioClient.messages.create({
    from: `whatsapp:${process.env.TWILIO_WHATSAPP_FROM}`,
    to: `whatsapp:${normalized}`,
    body: `🔐 *MyFamilyAnchor – ${roleLabel} Portal*\n\nYour password reset OTP is:\n\n*${otp}*\n\nValid for 10 minutes. Do not share this with anyone.`,
  });
}

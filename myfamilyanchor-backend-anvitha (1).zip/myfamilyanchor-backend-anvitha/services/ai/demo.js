﻿
import { SERVICE_CATALOG } from "../../constants/serviceCatalog.js";
import { getQuotaLimit } from "../../constants/planQuotas.js";

export function getDemoReply(message) {
  if (typeof message !== "string" || !message.trim()) {
    throw new Error("Please enter a message.");
  }

  const text = message.trim().toLowerCase();
  const plans = Object.keys(SERVICE_CATALOG);

  const result = (reply) => ({
    mode: "demo",
    label: "Demo mode - scripted replies",
    reply,
  });

  // Account-specific actions are deliberately not connected.
  if (
    /\b(my account|my subscription|my bookings?|my requests?|my remaining|remaining visits|visits left|how many .*visits? (?:do i have left|do i have remaining|are left in my account)|how many .*left in my account|how many .*remaining in my account|booking status|request status|book (?:a|an|the)|make (?:a|an) booking|create (?:a|an) request)\b/.test(text)
  ) {
    return result(
      "Account lookups and booking are not connected in this demo yet. " +
        "No account data was accessed and no service request was created. " +
        "I can still explain public plans and services."
    );
  }

  // Greetings.
  if (
    /\b(hi|hello|hey|good morning|good afternoon|good evening)\b/.test(text)
  ) {
    return result(
      "Hello! Welcome to MyFamilyAnchor. I can explain our care plans, " +
        "find services in the public catalog, or compare available plans. " +
        "I'm using scripted demo replies, so account access and bookings aren't connected."
    );
  }

  // Pricing: never invent prices.
  if (
    /\b(price|prices|pricing|cost|costs|how much|fee|fees|monthly charge)\b/.test(text)
  ) {
    return result(
      "I can explain the services and included allowances, but verified plan prices " +
        "aren't available in my current demo data. Services marked as on-demand require " +
        "a vendor quote and separate payment. Unlimited coordination does not mean " +
        "any resulting vendor work is free. Please contact MyFamilyAnchor support for current pricing."
    );
  }

  // Compare catalog entries across plans.
  if (
    /\b(compare|comparison|difference|differences)\b/.test(text) &&
    /\b(plan|plans|guardian|premium)\b/.test(text)
  ) {
    const summaries = plans.map((plan) => {
      const categories = SERVICE_CATALOG[plan];
      const allServices = Object.values(categories).flat();

      const included = allServices.filter(
        (service) => service.type === "included"
      );

      const onDemand = allServices.filter(
        (service) => service.type === "on_demand"
      );

      return [
        plan,
        "Categories: " + Object.keys(categories).join(", "),
        "Catalogued services: " + allServices.length,
        "Included-service entries: " + included.length,
        "On-demand services requiring a vendor quote and separate payment: " +
          onDemand.length,
      ].join("\n");
    });

    return result(
      "Plan overview based on the current service catalog:\n\n" +
        summaries.join("\n\n") +
        "\n\nThese counts describe catalog entries, not a ranking or a claim that plans inherit each other's services. Ask for a full plan name to see its service list and configured allowances."
    );
  }

  // Family care services.
  if (
    /\b(family care|family services|family support|family care services)\b/.test(text)
  ) {
    const entries = Object.entries(SERVICE_CATALOG)
      .filter(([, categories]) => categories.family)
      .map(([plan, categories]) => {
        const services = categories.family
          .map((service) => service.name)
          .join(", ");

        return `${plan}:\n${services}`;
      });

    return result(
      "Family care services listed in the catalog:\n\n" +
        entries.join("\n\n") +
        "\n\nAvailability depends on the selected plan. Included services may have allowances; on-demand services require a vendor quote and separate payment."
    );
  }

  // Property care services.
  if (
    /\b(property care|property services|property care services|home maintenance)\b/.test(text)
  ) {
    const entries = Object.entries(SERVICE_CATALOG)
      .filter(([, categories]) => categories.property)
      .map(([plan, categories]) => {
        const services = categories.property
          .map((service) => service.name)
          .join(", ");

        return `${plan}:\n${services}`;
      });

    return result(
      "Property care services listed in the catalog:\n\n" +
        entries.join("\n\n") +
        "\n\nAvailability depends on the selected plan. Included services may have allowances; on-demand services require a vendor quote and separate payment."
    );
  }

  // Identify a specifically named plan.
  const selectedPlan = plans.find((plan) =>
    text.includes(plan.toLowerCase())
  );

  if (selectedPlan) {
    const categories = SERVICE_CATALOG[selectedPlan];

    // Answer visit/quota questions concisely.
    const asksAboutVisits =
      /\b(visits?|allowances?|quota|included services)\b/.test(text);

    if (asksAboutVisits) {
      const visitLines = [];

      for (const services of Object.values(categories)) {
        for (const service of services) {
          if (!/visit|wellness check|companionship/i.test(service.name)) {
            continue;
          }

          const limit = getQuotaLimit(selectedPlan, service.name);

          if (typeof limit === "number") {
            visitLines.push(
              `${service.name}: ${limit} included per 30-day cycle`
            );
          } else if (limit === null) {
            visitLines.push(
              `${service.name}: Unlimited coordination; resulting paid work costs extra`
            );
          }
        }
      }

      if (visitLines.length > 0) {
        return result(
          `${selectedPlan}\n\n${visitLines.join("\n")}`
        );
      }
    }

    // Other plan questions show the full catalog response.
    const lines = [selectedPlan];

    for (const [category, services] of Object.entries(categories)) {
      lines.push(`\n${category.toUpperCase()}`);

      for (const service of services) {
        let details;

        if (service.type === "on_demand") {
          details = "Vendor quote and separate payment required";
        } else {
          const limit = getQuotaLimit(selectedPlan, service.name);

          if (limit === null) {
            details =
              "Unlimited coordination; resulting paid work costs extra";
          } else if (typeof limit === "number") {
            details = `${limit} included per 30-day cycle`;
          } else {
            details =
              "Included; allowance needs confirmation from support";
          }
        }

        lines.push(`- ${service.name}: ${details}`);
      }
    }

    return result(lines.join("\n"));
  }

  // Match specifically named services against the catalog.
  const catalogMatches = [];

  for (const [plan, categories] of Object.entries(SERVICE_CATALOG)) {
    for (const [category, services] of Object.entries(categories)) {
      for (const service of services) {
        const name = service.name.toLowerCase();

        if (
          text.includes(name) ||
          text === name ||
          text.includes(`explain ${name}`) ||
          text.includes(`what is ${name}`)
        ) {
          const limit = getQuotaLimit(plan, service.name);
          let details;

          if (service.type === "on_demand") {
            details = "Vendor quote and separate payment required";
          } else if (limit === null) {
            details =
              "Unlimited coordination; resulting paid work costs extra";
          } else if (typeof limit === "number") {
            details = `${limit} included per 30-day cycle`;
          } else {
            details =
              "Included; allowance needs confirmation from support";
          }

          catalogMatches.push(
            `- ${service.name} (${plan}, ${category}): ${details}`
          );
        }
      }
    }
  }

  if (catalogMatches.length > 0) {
    return result(
      "Matching services in the public catalog:\n" +
        [...new Set(catalogMatches)].join("\n") +
        "\n\nAvailability and allowances depend on the specific plan. On-demand services require a vendor quote and separate payment."
    );
  }

  // General help.
  if (
    /\b(parent|parents|mother|father|family|elderly|senior|home|property|services|service|plans|plan|available|help)\b/.test(text)
  ) {
    return result(
      "Welcome to MyFamilyAnchor! Choose an area to explore:\n\n" +
        "- Family Care: companionship, wellness checks, medicine delivery and more.\n" +
        "- Property Care: property inspections, plumbing support, cleaning and more.\n" +
        "- Plans: Property Guardian, Family Guardian and Guardian Premium.\n" +
        "- Pricing: learn about included allowances and on-demand vendor quotes.\n\n" +
        "I can explain public catalog information, but I cannot access account data or create service requests in this demo."
    );
  }

  return result(
    "I'm the MyFamilyAnchor scripted demo assistant. I can explain plan services, " +
      "search the public service catalog, compare plan catalog entries, and clarify " +
      "how included allowances differ from on-demand services. I can't access account data, " +
      "create bookings, or confirm current prices in this demo.\n\n" +
      'Try "Compare plans", "What is medicine delivery?", ' +
      '"What family care services are available?", or "Explain Family Guardian".'
  );
}



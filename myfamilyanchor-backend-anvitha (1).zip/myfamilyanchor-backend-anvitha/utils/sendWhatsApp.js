import axios from "axios";

const formatPaymentMessage = (data) => {
  const {
    name,
    amount,
    transactionId,
    status = "SUCCESS",
    method,
    date = new Date().toLocaleString("en-IN"),
  } = data;

  return `💰 PAYMENT ${status}

👤 ${name}
💵 ₹${amount}
🧾 ${transactionId}
💳 ${method}
📅 ${date}

Thank you for choosing MyFamilyAnchor ❤️`;
};

const sendWhatsApp = async ({ to, messageData }) => {
  try {
    if (!to) throw new Error("Recipient number required");

    const phone = to.replace(/\+/g, "");

    const body =
      typeof messageData === "string"
        ? messageData
        : formatPaymentMessage(messageData);

    const response = await axios.post(
      `https://graph.facebook.com/${process.env.WHATSAPP_API_VERSION}/${process.env.WHATSAPP_PHONE_NUMBER_ID}/messages`,
      {
        messaging_product: "whatsapp",

        to: phone,

        type: "text",

        text: {
          body,
        },
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.WHATSAPP_ACCESS_TOKEN}`,
          "Content-Type": "application/json",
        },
      },
    );

    console.log("WhatsApp Sent", response.data);

    return {
      success: true,
      data: response.data,
    };
  } catch (err) {
    console.error(err.response?.data || err.message);

    return {
      success: false,
      error: err.response?.data || err.message,
    };
  }
};

export default sendWhatsApp;

import client from "../config/twilio.js";

/* Format payment message in a structured way */
const formatPaymentMessage = (data) => {
  const {
    name,
    amount,
    transactionId,
    status = "SUCCESS",
    date = new Date().toLocaleString(),
    method,
  } = data;

  return (
    `💰 PAYMENT ${status}\n\n` +
    `👤 Name: ${name}\n` +
    `💵 Amount: ₹${amount}\n` +
    `🔖 Transaction ID: ${transactionId}\n` +
    `💳 Method: ${method}\n` +
    `📅 Date: ${date}\n\n` +
    `Thank you for your payment.`
  );
};

/* Send WhatsApp message (text or payment notification) */
const sendWhatsApp = async ({ to, messageData, mediaUrl = null }) => {
  try {
    if (!to) throw new Error("Recipient number is required");

    if (!/^\+\d{10,15}$/.test(to)) {
      throw new Error("Invalid phone number format");
    }

    if (!process.env.TWILIO_WHATSAPP_NUMBER) {
      throw new Error("Twilio WhatsApp number not configured");
    }

    // normalize number (basic safety check)
    const formattedTo = to.startsWith("whatsapp:") ? to : `whatsapp:${to}`;

    // build message
    const body =
      typeof messageData === "string"
        ? messageData
        : formatPaymentMessage(messageData);

    const payload = {
      body,
      from: process.env.TWILIO_WHATSAPP_NUMBER,
      to: formattedTo,
    };

    // optional image/pdf/receipt support
    if (mediaUrl) {
      payload.mediaUrl = [mediaUrl];
    }

    const response = await client.messages.create(payload);

    console.log("WhatsApp sent ✔ SID:", response.sid);

    return {
      success: true,
      sid: response.sid,
    };
  } catch (error) {
    console.error("WhatsApp Error:", error.message);

    return {
      success: false,
      error: error.message,
    };
  }
};

export default sendWhatsApp;

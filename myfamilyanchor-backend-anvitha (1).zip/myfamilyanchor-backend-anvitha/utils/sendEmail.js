import resend from "../config/mail.js";

const sendEmail = async ({ to, subject, html }) => {
  try {
    const response = await resend.emails.send({
      from: process.env.EMAIL_FROM,
      to,
      subject,
      html,
    });

    console.log("EMAIL SUCCESS:", response);

    return response;
  } catch (error) {
    console.error("EMAIL ERROR:", error);

    throw error;
  }
};
//   const response = await resend.emails.send({
//     from: process.env.EMAIL_FROM,
//     to,
//     subject,
//     html,
//   });

//   return response;
// };

export default sendEmail;

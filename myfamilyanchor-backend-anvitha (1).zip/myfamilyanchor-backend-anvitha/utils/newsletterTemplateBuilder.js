export const buildNewsletterHTML = ({ title, content }) => {
  return `
  <div style="
    background:#f8fafc;
    padding:40px 20px;
    font-family:Arial,sans-serif;
  ">

    <div style="
      max-width:700px;
      margin:auto;
      background:#ffffff;
      border-radius:20px;
      overflow:hidden;
      box-shadow:0 10px 30px rgba(0,0,0,0.08);
    ">

      <div style="
        background:linear-gradient(
          135deg,
          #7b3ff2,
          #ff7b72
        );
        padding:50px 30px;
        text-align:center;
        color:white;
      ">
        <h1 style="
          margin:0;
          font-size:42px;
        ">
          MyFamilyAnchor
        </h1>

        <p style="
          margin-top:10px;
          opacity:0.9;
          font-size:16px;
        ">
          Care That Connects Hearts
        </p>
      </div>

      <div style="
        padding:40px;
      ">
        <h2 style="
          color:#0f172a;
          margin-bottom:24px;
          text-align:center;
        ">
          ${title}
        </h2>

        <div style="
          color:#475569;
          line-height:1.8;
          font-size:16px;
        ">
          ${content}
        </div>

        <div style="
  text-align:center;
  margin-top:40px;
  margin-bottom:20px;
">
  <a
    href="https://myfamilyanchor.com"
    target="_blank"
    style="
      display:inline-block;
      padding:18px 40px;
      background:linear-gradient(
        135deg,
        #7b3ff2,
        #ff7b72
      );
      color:white;
      text-decoration:none;
      border-radius:50px;
      font-size:16px;
      font-weight:700;
    "
  >
    Visit MyFamilyAnchor
  </a>
</div>

      <div style="
        background:#f8fafc;
        text-align:center;
        padding:25px;
        color:#64748b;
      ">
        Team MyFamilyAnchor ❤️
      </div>

    </div>

  </div>
  `;
};

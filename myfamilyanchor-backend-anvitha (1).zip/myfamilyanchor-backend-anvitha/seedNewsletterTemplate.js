import mongoose from "mongoose";
import dotenv from "dotenv";

import NewsletterTemplate from "./models/NewsletterTemplate.js";

dotenv.config();

await mongoose.connect(process.env.MONGO_URI);

await NewsletterTemplate.deleteMany();

await NewsletterTemplate.insertMany([
  {
    name: "Health Tips",

    subject: "Weekly Health & Wellness Tips",

    htmlTemplate: `
      <h1>🩺 MyFamilyAnchor Health Tips</h1>

      <p>Stay healthy and active with our weekly wellness tips.</p>

      <ul>
        <li>Drink enough water.</li>
        <li>Take a daily walk.</li>
        <li>Schedule regular health checkups.</li>
      </ul>

      <p>Team MyFamilyAnchor</p>
    `,
  },

  {
    name: "Festival Greetings",

    subject: "Warm Wishes From MyFamilyAnchor",

    htmlTemplate: `
      <h1>🎉 Festival Greetings</h1>

      <p>
        Wishing you and your family happiness,
        prosperity and good health.
      </p>

      <p>
        Thank you for being a valued member
        of MyFamilyAnchor.
      </p>
    `,
  },

  {
    name: "Special Offer",

    subject: "Exclusive Offer For Our Subscribers",

    htmlTemplate: `
      <h1>🎁 Special Offer</h1>

      <p>
        Enjoy exclusive discounts on our care plans.
      </p>

      <p>
        Book your consultation today.
      </p>
    `,
  },

  {
    name: "New Service Launch",

    subject: "Introducing Our New Service",

    htmlTemplate: `
      <h1>🚀 New Service Launch</h1>

      <p>
        We are excited to introduce a new service
        designed specifically for NRI families.
      </p>
    `,
  },
]);

console.log("Templates seeded");
process.exit();

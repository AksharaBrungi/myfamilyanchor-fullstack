﻿import { getDemoReply } from "./services/ai/demo.js";

for (const question of [
  "How many visits do I have left?",
  "Explain Family Guardian",
  "What is medicine delivery?",
  "Compare plans",
  "How much does it cost?"
]) {
  const result = getDemoReply(question);
  console.log("\nQUESTION:", question);
  console.log(result.reply);
}

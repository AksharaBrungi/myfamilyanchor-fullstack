
import test from "node:test";
import assert from "node:assert/strict";
import { getDemoReply } from "./services/ai/demo.js";

test("AI response has the expected demo structure", () => {
  const result = getDemoReply("Hello");

  assert.equal(result.mode, "demo");
  assert.equal(typeof result.reply, "string");
  assert.ok(result.reply.trim().length > 0);
});

test("AI response identifies itself as demo mode", () => {
  const result = getDemoReply("Show plans");

  assert.equal(result.mode, "demo");
  assert.ok(result.label.toLowerCase().includes("demo"));
});

test("Account-specific questions do not invent account data", () => {
  const result = getDemoReply("How many visits do I have left?");

  assert.equal(result.mode, "demo");
  assert.match(result.reply, /account data was accessed/i);
  assert.match(result.reply, /no service request was created/i);
});
test("Plan comparison does not invent prices or rank plans", () => {
  const result = getDemoReply("Compare plans");

  assert.equal(result.mode, "demo");
  assert.match(result.reply, /catalog entries/i);
  assert.match(result.reply, /not a ranking/i);
});
test("Family Guardian visit question returns relevant quota details", () => {
  const result = getDemoReply(
    "How many visits are included in Family Guardian?"
  );

  assert.match(result.reply, /Companionship Visit: 4 included/);
  assert.match(result.reply, /Wellness Check: 4 included/);
  assert.match(result.reply, /30-day cycle/);
});
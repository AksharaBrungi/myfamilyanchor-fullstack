import dotenv from "dotenv";
dotenv.config();
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import Admin from "./models/Admin.js";
import connectDB from "./config/db.js";

await connectDB();

const hashedPassword = await bcrypt.hash("Admin@123", 10);

const existingAdmin = await Admin.findOne({
  email: "admin@myfamilyanchor.com",
});

if (existingAdmin) {
  console.log("Admin already exists");
  process.exit(0);
}

await Admin.create({
  name: "Super Admin",
  email: "admin@myfamilyanchor.com",
  password: hashedPassword,
  role: "admin",
});

console.log("Admin created successfully");
process.exit(0);

import { createContext, useContext, useEffect, useState, useMemo } from "react";
import API from "@api/axios";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const token = localStorage.getItem("token");
        if (!token) {
          setLoading(false);
          return;
        }

        const { data } = await API.get("/auth/me");
        setUser(data);
      } catch (error) {
        // Only remove token on 401 (auth failure), not on network errors.
        if (error.response?.status === 401) {
          localStorage.removeItem("token");
          setUser(null);
        }
        // For other errors (500, network down), keep the token — user stays logged in
        console.error(
          "fetchUser error:",
          error.response?.status,
          error.message,
        );
      } finally {
        setLoading(false);
      }
    };

    fetchUser();
  }, []);

  const login = async (token) => {
    localStorage.setItem("token", token);

    const { data } = await API.get("/auth/me");
    
    setUser(data);
  };

  const refreshUser = async () => {
    const { data } = await API.get("/auth/me");
    setUser(data);
  };

  const logout = () => {
    localStorage.removeItem("token");
    setUser(null);
  };

  const value = useMemo(
    () => ({
      user,
      login,
      logout,
      loading,
      refreshUser,
    }),
    [user, loading],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => useContext(AuthContext);

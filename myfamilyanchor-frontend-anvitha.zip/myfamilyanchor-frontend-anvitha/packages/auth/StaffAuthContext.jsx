import { createContext, useContext, useEffect, useMemo, useState } from "react";
import API from "@api/axios";

const StaffAuthContext = createContext();

export const StaffAuthProvider = ({ children }) => {
  const [staff, setStaff] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStaff = async () => {
      try {
        const token = localStorage.getItem("staffToken");

        if (!token) {
          setLoading(false);
          return;
        }

        const { data } = await API.get("/staff-auth/me", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        setStaff(data);
      } catch {
        localStorage.removeItem("staffToken");
        setStaff(null);
      } finally {
        setLoading(false);
      }
    };

    fetchStaff();
  }, []);

  const login = async (token) => {
    localStorage.setItem("staffToken", token);

    const { data } = await API.get("/staff-auth/me", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    setStaff(data);
  };

  const logout = () => {
    localStorage.removeItem("staffToken");
    setStaff(null);
  };

  const value = useMemo(
    () => ({
      staff,
      loading,
      login,
      logout,
    }),
    [staff, loading],
  );

  return (
    <StaffAuthContext.Provider value={value}>
      {children}
    </StaffAuthContext.Provider>
  );
};

export const useStaffAuth = () => useContext(StaffAuthContext);

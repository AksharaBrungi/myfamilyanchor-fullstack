import { createContext, useContext, useEffect, useMemo, useState } from "react";
import API from "@api/axios";

const VendorAuthContext = createContext();

export const VendorAuthProvider = ({ children }) => {
  const [vendor, setVendor] = useState(null);

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchVendor = async () => {
      try {
        const token = localStorage.getItem("vendorToken");

        if (!token) {
          setLoading(false);
          return;
        }

        const { data } = await API.get("/vendors/auth/me", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        setVendor(data);
      } catch {
        localStorage.removeItem("vendorToken");

        setVendor(null);
      } finally {
        setLoading(false);
      }
    };

    fetchVendor();
  }, []);

  const login = async (token) => {
    localStorage.setItem("vendorToken", token);

    const { data } = await API.get("/vendors/auth/me", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    setVendor(data);
  };

  const logout = () => {
    localStorage.removeItem("vendorToken");

    setVendor(null);
  };

  const value = useMemo(
    () => ({
      vendor,
      loading,
      login,
      logout,
    }),
    [vendor, loading],
  );

  return (
    <VendorAuthContext.Provider value={value}>
      {children}
    </VendorAuthContext.Provider>
  );
};

export const useVendorAuth = () => useContext(VendorAuthContext);

export const buildTemplateHTML = (title, content) => {
  return `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="UTF-8" />
        <title>${title}</title>
      </head>

      <body style="
        margin:0;
        padding:40px;
        background:#f8fafc;
        font-family:Arial,sans-serif;
      ">

        <div style="
          max-width:700px;
          margin:auto;
          background:white;
          border-radius:20px;
          overflow:hidden;
          box-shadow:0 10px 30px rgba(0,0,0,0.08);
        ">

          <div style="
            background:linear-gradient(
              135deg,
              #7b3ff2,
              #ff7b72
            );
            padding:50px;
            text-align:center;
            color:white;
          ">
            <h1>MyFamilyAnchor</h1>

            <p>
              Care That Connects Hearts
            </p>
          </div>

          <div style="padding:40px;">
            <h2>${title}</h2>

            <div>
              ${content}
            </div>

            <div style="
              text-align:center;
              margin-top:40px;
            ">
              <a
                href="#"
                style="
                  display:inline-block;
                  padding:16px 36px;
                  background:linear-gradient(
                    135deg,
                    #7b3ff2,
                    #ff7b72
                  );
                  color:white;
                  text-decoration:none;
                  border-radius:50px;
                  font-weight:700;
                "
              >
                Visit Website
              </a>
            </div>
          </div>

        </div>

      </body>
    </html>
  `;
};

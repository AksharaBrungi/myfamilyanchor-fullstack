import { useEffect, useRef } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import axios from "axios";
import toast from "react-hot-toast";

export default function LoadingPage({
  title: propTitle,
  subtitle: propSubtitle,
}) {
  const navigate = useNavigate();
  const location = useLocation();
  const didRun = useRef(false);

  const config =
    location.state ||
    JSON.parse(sessionStorage.getItem("loadingConfig") || "null");

  const {
    title = propTitle || "Loading...",
    subtitle = propSubtitle || "Please wait",
    redirectTo = "/",
    duration = 3000,
    verifyPayload = null,
    pendingToken = null,
  } = config || {};

  useEffect(() => {
    if (didRun.current) return;
    didRun.current = true;

    sessionStorage.removeItem("loadingConfig");

    // If there's a payment to verify, do it here — single source of truth
    if (verifyPayload && pendingToken) {
      const verify = async () => {
        try {
          const verifyResponse = await axios.post(
            `${import.meta.env.VITE_API_URL}/payment/verify`,
            verifyPayload,
            {
              headers: { Authorization: `Bearer ${pendingToken}` },
            },
          );

          if (verifyResponse.data.success) {
            localStorage.setItem("token", pendingToken);
            localStorage.removeItem("pendingToken");
            localStorage.removeItem("selectedPlan");
            localStorage.removeItem("pendingUserEmail");

            toast.success(
              "Payment successful! Activating your subscription...",
            );

            navigate("/success", { replace: true });
          } else {
            throw new Error("Verification returned non-success");
          }
        } catch (error) {
          toast.error(
            error.response?.data?.message ||
              "Payment verification failed. Please contact support.",
          );
          navigate("/checkout", { replace: true });
        }
      };

      verify();
      return;
    }

    const timer = setTimeout(() => {
      navigate(redirectTo, { replace: true });
    }, duration);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="[font-family:Segoe_UI_sans-serif] [background:linear-gradient(135deg,_#f5f0ff_0%,_#fff0fb_100%)] [display:flex] [align-items:center] [justify-content:center] [height:100vh] [margin:0]">
      <div className="[text-align:center] [padding:40px]">
        <div className="[font-size:1rem] [color:#9b59b6] [font-weight:600] [margin-bottom:40px] [letter-spacing:1px]">
          ❤️ MyFamilyAnchor
        </div>
        <h2 className="[font-size:1.6rem] [color:#2d1b4e] [margin-bottom:10px]">
          {title}
        </h2>
        <p className="[color:#888] [font-size:0.95rem] [margin-bottom:40px]">
          {subtitle}
        </p>
        <div className="[width:280px] [height:6px] [background:#e8d5f5] [border-radius:10px] [margin:0_auto_30px] [overflow:hidden]">
          <div className="[height:100%] [width:0%] [background:linear-gradient(90deg,_#a855f7,_#ec4899)] [border-radius:10px] [animation:loading-fill_3s_ease-in-out_forwards]" />
        </div>
        <div className="[display:flex] [justify-content:center] [gap:10px]">
          <span className="[width:10px] [height:10px] [border-radius:50%] [background:linear-gradient(135deg,_#a855f7,_#ec4899)] [animation:bounce_1.2s_ease-in-out_infinite] [&:nth-child(2)]:[animation-delay:0.2s] [&:nth-child(3)]:[animation-delay:0.4s]" />
          <span className="[width:10px] [height:10px] [border-radius:50%] [background:linear-gradient(135deg,_#a855f7,_#ec4899)] [animation:bounce_1.2s_ease-in-out_infinite] [&:nth-child(2)]:[animation-delay:0.2s] [&:nth-child(3)]:[animation-delay:0.4s]" />
          <span className="[width:10px] [height:10px] [border-radius:50%] [background:linear-gradient(135deg,_#a855f7,_#ec4899)] [animation:bounce_1.2s_ease-in-out_infinite] [&:nth-child(2)]:[animation-delay:0.2s] [&:nth-child(3)]:[animation-delay:0.4s]" />
        </div>
        <div className="[margin-top:30px] [font-size:0.8rem] [color:#bbb]">
          You'll be redirected automatically in a few seconds
        </div>
      </div>
    </div>
  );
}

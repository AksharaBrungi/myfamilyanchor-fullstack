import { useState } from "react";
import { FiEye, FiEyeOff } from "react-icons/fi";

function PasswordInput({ className = "", value = "", disabled, ...props }) {
  const [visible, setVisible] = useState(false);

  return (
    <div className="relative w-full">
      <input
        {...props}
        value={value}
        disabled={disabled}
        type={visible ? "text" : "password"}
        className={`${className} pr-[72px]`}
      />

      {value && (
        <button
          type="button"
          disabled={disabled}
          onClick={() => setVisible((v) => !v)}
          className="
            absolute
            right-3
            top-1/2
            -translate-y-1/2
            w-10
            h-10
            rounded-xl
            flex
            items-center
            justify-center
            text-[#7b3ff2]
            bg-[rgba(123,63,242,0.08)]
            transition-all
            hover:bg-[rgba(123,63,242,0.15)]
            disabled:opacity-40
          "
        >
          {visible ? <FiEyeOff /> : <FiEye />}
        </button>
      )}
    </div>
  );
}

export default PasswordInput;

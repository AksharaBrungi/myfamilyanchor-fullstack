
// ─── base token (applied to every hero heading) ───────────────────────────
export const heroBase =
  "[font-family:Cormorant_Garamond_serif] " +
  "[font-weight:500] " +
  "[letter-spacing:-0.02em] " +
  "[color:#0b1026] " +
  "[margin:0_0_28px]";

// ─── gradient accent (applied to a <span> inside the heading) ─────────────
export const gradientText = {
  background: "linear-gradient(135deg, #7b3ff2, #ff5ca8, #ff9b54)",
  WebkitBackgroundClip: "text",
  backgroundClip: "text",
  color: "transparent",
};

// ─── XL  – Pricing page (full-width centred hero, widest container ~1360px)
//     2-line heading, never wraps beyond 3
export const heroXL =
  heroBase +
  " [font-size:clamp(3rem,_5.8vw,_6.8rem)]" +
  " [line-height:1.0]";

// ─── LG  – Cities page (left column of a 0.9/1.1 grid, ~600px wide)
//     3 short lines, comfortable scan
export const heroLG =
  heroBase +
  " [font-size:clamp(2.8rem,_5.2vw,_5.8rem)]" +
  " [line-height:1.02]";

// ─── MD  – Services page (full-width centred hero, similar to Pricing)
//     2 lines, centred
export const heroMD =
  heroBase +
  " [font-size:clamp(2.8rem,_5vw,_6rem)]" +
  " [line-height:1.0]";

// ─── SM  – About & Contact pages (left column of 1.05/0.95 and 0.9/1.1 grids)
export const heroSM =
  heroBase +
  " [font-size:clamp(2.4rem,_4.2vw,_4.8rem)]" +
  " [line-height:1.08]";

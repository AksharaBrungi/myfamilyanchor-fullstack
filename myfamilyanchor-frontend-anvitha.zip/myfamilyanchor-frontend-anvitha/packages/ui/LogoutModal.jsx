import { FiLogOut } from "react-icons/fi";
import { createPortal } from "react-dom";

function LogoutModal({ open, onClose, onConfirm }) {
  if (!open) return null;

  return createPortal(
    <div
      className="
        fixed
        inset-0
        z-[999999]
        bg-black/50
        flex
        items-center
        justify-center
        p-4
        animate-[fadeIn_0.2s_ease]
      "
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="
          bg-white
          rounded-3xl
          px-8
          py-8
          w-full
          max-w-[420px]
          text-center
          shadow-[0_25px_80px_rgba(0,0,0,0.18)]
          animate-[slideUp_0.25s_ease]
        "
      >
        {/* Icon */}
        <div
          className="
            w-16 h-16
            rounded-full
            bg-[#fbeaf0]
            flex
            items-center
            justify-center
            mx-auto
            mb-5
          "
        >
          <FiLogOut size={32} className="text-[#993556]" />
        </div>

        {/* Title */}
        <h3 className="text-[1.75rem] font-bold text-[#111827] mb-2">Logout</h3>

        {/* Description */}
        <p className="text-[#6b7280] mb-8">Are you sure you want to logout?</p>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-3">
          <button
            type="button"
            onClick={onClose}
            className="
              flex-1
              min-h-[52px]
              rounded-full
              border-2
              border-[#e5e7eb]
              bg-white
              text-[#dc2626]
              font-bold
              transition-all
              duration-200
              hover:bg-gray-50
            "
          >
            Cancel
          </button>

          <button
            type="button"
            onClick={onConfirm}
            className="
              flex-1
              min-h-[52px]
              rounded-full
              border-none
              text-white
              font-bold
              bg-gradient-to-r
              from-[#16a34a]
              to-[#15803d]
              transition-all
              duration-200
              hover:opacity-90
            "
          >
            Yes, Logout
          </button>
        </div>
      </div>

      <style>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }

        @keyframes slideUp {
          from {
            transform: translateY(24px);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }
      `}</style>
    </div>,
    document.body,
  );
}

export default LogoutModal;

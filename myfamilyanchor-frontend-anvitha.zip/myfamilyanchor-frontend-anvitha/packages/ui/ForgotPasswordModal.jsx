import { useState, useRef, useEffect } from "react";
import API from "@api/axios";
import PasswordInput from "./PasswordInput";

/**
 * ForgotPasswordModal
 * Props:
 *   role      — "user" | "admin" | "staff" | "vendor"
 *   onClose   — callback to close the modal
 */
function ForgotPasswordModal({ role, onClose }) {
  // Step: "request" → "verify" → "reset" → "done"
  const [step, setStep] = useState("request");
  const [identifier, setIdentifier] = useState("");
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [deliveryInfo, setDeliveryInfo] = useState([]); // ["email","whatsapp"]
  const [resendTimer, setResendTimer] = useState(0);

  const otpRefs = useRef([]);
  const timerRef = useRef(null);

  useEffect(() => {
    return () => clearInterval(timerRef.current);
  }, []);

  const startResendTimer = () => {
    setResendTimer(60);
    timerRef.current = setInterval(() => {
      setResendTimer((t) => {
        if (t <= 1) {
          clearInterval(timerRef.current);
          return 0;
        }
        return t - 1;
      });
    }, 1000);
  };

  // Request OTP
  const handleRequestOTP = async (e) => {
    e.preventDefault();
    setError("");
    if (!identifier.trim())
      return setError("Please enter your email or phone number.");

    try {
      setLoading(true);
      const { data } = await API.post("/forgot-password/request-otp", {
        identifier: identifier.trim(),
        role,
      });

      if (data.sent) {
        setDeliveryInfo(data.via || []);
        setStep("verify");
        startResendTimer();
      } else {
        // Account not found — still move to verify step (anti-enumeration)
        setDeliveryInfo([]);
        setStep("verify");
        startResendTimer();
      }
    } catch (err) {
      setError(
        err.response?.data?.message || "Failed to send OTP. Please try again.",
      );
    } finally {
      setLoading(false);
    }
  };

  // OTP Input Handlers
  const handleOtpChange = (index, value) => {
    if (!/^\d*$/.test(value)) return;
    const updated = [...otp];
    updated[index] = value.slice(-1);
    setOtp(updated);
    if (value && index < 5) otpRefs.current[index + 1]?.focus();
  };

  const handleOtpKeyDown = (index, e) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      otpRefs.current[index - 1]?.focus();
    }
  };

  const handleOtpPaste = (e) => {
    const pasted = e.clipboardData
      .getData("text")
      .replace(/\D/g, "")
      .slice(0, 6);
    if (pasted.length === 6) {
      setOtp(pasted.split(""));
      otpRefs.current[5]?.focus();
      e.preventDefault();
    }
  };

  // Verify OTP
  const handleVerifyOTP = async (e) => {
    e.preventDefault();
    setError("");
    const otpValue = otp.join("");
    if (otpValue.length < 6) return setError("Enter the 6-digit OTP.");

    try {
      setLoading(true);
      await API.post("/forgot-password/verify-otp", {
        identifier: identifier.trim(),
        otp: otpValue,
        role,
      });
      setStep("reset");
    } catch (err) {
      setError(err.response?.data?.message || "Invalid OTP. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  // Reset Password
  const handleResetPassword = async (e) => {
    e.preventDefault();
    setError("");

    if (newPassword !== confirmPassword) {
      return setError("Passwords do not match.");
    }

    try {
      setLoading(true);
      await API.post("/forgot-password/reset", {
        identifier: identifier.trim(),
        newPassword,
        role,
      });
      setStep("done");
    } catch (err) {
      setError(err.response?.data?.message || "Failed to reset password.");
    } finally {
      setLoading(false);
    }
  };

  const handleResend = () => {
    if (resendTimer > 0) return;
    setOtp(["", "", "", "", "", ""]);
    setError("");
    // Re-trigger the request step silently
    API.post("/forgot-password/request-otp", {
      identifier: identifier.trim(),
      role,
    })
      .then(({ data }) => {
        if (data.via) setDeliveryInfo(data.via);
        startResendTimer();
      })
      .catch(() => setError("Failed to resend OTP."));
  };

  // Delivery label
  const deliveryLabel = () => {
    if (deliveryInfo.includes("email") && deliveryInfo.includes("whatsapp"))
      return "your email and WhatsApp";
    if (deliveryInfo.includes("whatsapp")) return "your WhatsApp";
    if (deliveryInfo.includes("email")) return "your email";
    return "your registered contact";
  };

  const roleLabel =
    {
      user: "Customer",
      admin: "Admin",
      staff: "Staff",
      vendor: "Vendor",
    }[role] || "User";


  return (
    <div
      className="[position:fixed] [inset:0] [z-index:1000] [background:rgba(30,_10,_60,_0.45)] [-webkit-backdrop-filter:blur(6px)] [backdrop-filter:blur(6px)] [display:flex] [align-items:center] [justify-content:center] [padding:20px] [animation:fp-fade-in_0.2s_ease]"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="[position:relative] [width:100%] [max-width:440px] [border-radius:28px] [padding:40px_36px_36px] [background:white] [box-shadow:0_24px_80px_rgba(123,_63,_242,_0.18),_0_4px_16px_rgba(0,_0,_0,_0.08)] [animation:fp-slide-up_0.28s_cubic-bezier(0.22,_1,_0.36,_1)] max-[480px]:[padding:32px_20px_28px] max-[480px]:[border-radius:22px] [background:rgba(255,_255,_255,_0.72)] [border:1px_solid_rgba(255,_255,_255,_0.78)] [box-shadow:0_24px_70px_rgba(123,_63,_242,_0.13)] [-webkit-backdrop-filter:blur(22px)] [backdrop-filter:blur(22px)]">
        {/* Close */}
        <button className="[position:absolute] [top:16px] [right:18px] [background:rgba(123,_63,_242,_0.08)] [border:none] [border-radius:50%] [width:34px] [height:34px] [font-size:14px] [cursor:pointer] [color:#7b3ff2] [transition:background_0.2s] hover:[background:rgba(123,_63,_242,_0.16)]" onClick={onClose} aria-label="Close">
          ✕
        </button>

        {/* Header */}
        <div className="[text-align:center] [margin-bottom:28px] [&_h2]:[font-size:1.5rem] [&_h2]:[font-weight:800] [&_h2]:[color:#1a0a3c] [&_h2]:[margin:6px_0_8px] [&_p]:[font-size:0.88rem] [&_p]:[color:#888] [&_p]:[line-height:1.5]">
          <div className="[font-size:2.4rem] [margin-bottom:10px]">
            {step === "done"
              ? "✅"
              : step === "reset"
                ? "🔑"
                : step === "verify"
                  ? "📲"
                  : "🔐"}
          </div>
          <span className="[font-size:11px] [font-weight:700] [letter-spacing:2px] [text-transform:uppercase] [color:#ff5ca8]">{roleLabel} Portal</span>
          <h2>
            {step === "request" && "Forgot Password"}
            {step === "verify" && "Enter OTP"}
            {step === "reset" && "New Password"}
            {step === "done" && "Password Reset!"}
          </h2>
          <p>
            {step === "request" &&
              "Enter your registered email or phone number."}
            {step === "verify" &&
              `We sent a 6-digit OTP to ${deliveryLabel()}.`}
            {step === "reset" && "Choose a strong new password."}
            {step === "done" &&
              "Your password has been updated. You can now log in."}
          </p>
        </div>

        {/* Steps indicator */}
        {step !== "done" && (
          <div className="[display:flex] [justify-content:center] [gap:0] [margin-bottom:28px]">
            {["request", "verify", "reset"].map((s, i) => (
              <div
                key={s}
                className={`fp-step${step === s ? " fp-step--active" : ""}${["verify", "reset", "done"].indexOf(step) > ["verify", "reset", "done"].indexOf(s) || (s === "request" && step !== "request") ? " fp-step--done" : ""}`}
              >
                <div className="[width:28px] [height:28px] [border-radius:50%] [background:#f0e8ff] [color:#aaa] [font-size:12px] [font-weight:700] [display:flex] [align-items:center] [justify-content:center] [position:relative] [z-index:1] [transition:all_0.3s_ease]">{i + 1}</div>
                <span>{["Send OTP", "Verify", "Reset"][i]}</span>
              </div>
            ))}
          </div>
        )}

        {/* Error */}
        {error && (
          <p className="[background:rgba(255,_92,_92,_0.08)] [border:1px_solid_rgba(255,_92,_92,_0.2)] [border-radius:10px] [color:#d44] [font-size:13px] [padding:10px_14px] [margin-bottom:16px] [text-align:center]" role="alert">
            {error}
          </p>
        )}

        {/* ── Step 1 ── */}
        {step === "request" && (
          <form onSubmit={handleRequestOTP} className="[display:flex] [flex-direction:column] [gap:14px]">
            <input
            className="[width:100%] [padding:16px_18px] [font-size:15px] [font-weight:500] [color:#1a1a2e] [background:#f5f3ff] [border:1.5px_solid_transparent] [border-radius:14px] [outline:none] [transition:all_0.25s_ease] placeholder:[color:#b0a8c8] hover:[background:#ede9fe] hover:[border-color:#d8b4fe] focus:[background:#ffffff] focus:[border-color:#a855f7] focus:[box-shadow:0_0_0_4px_rgba(168,_85,_247,_0.15),_0_4px_20px_rgba(168,_85,_247,_0.15)]"
            type="text"
            placeholder="Email or Phone Number"
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value)}
            autoFocus
            required
           />
            <button type="submit" className="[min-height:56px] [padding:0_28px] [border-radius:18px] [display:inline-flex] [align-items:center] [justify-content:center] [gap:12px] [border:1px_solid_transparent] [font-size:0.96rem] [font-weight:900] [line-height:1] [text-align:center] [text-decoration:none] [white-space:nowrap] [cursor:pointer] [transition:transform_0.25s_ease,_box-shadow_0.25s_ease,_border-color_0.25s_ease,_background_0.25s_ease] [color:#fff] [background:linear-gradient(135deg,_#7b3ff2,_#ff5ca8,_#ff9b54)] [box-shadow:0_20px_42px_rgba(255,_92,_168,_0.28)] hover:[transform:translateY(-3px)] hover:[box-shadow:0_26px_54px_rgba(123,_63,_242,_0.3)] focus-visible:[outline:3px_solid_rgba(123,_63,_242,_0.22)] focus-visible:[outline-offset:4px]" disabled={loading}>
              {loading ? "Sending OTP…" : "Send OTP"}
            </button>
          </form>
        )}

        {/* ── Step 2 ── */}
        {step === "verify" && (
          <form onSubmit={handleVerifyOTP} className="[display:flex] [flex-direction:column] [gap:14px]">
            <div className="[display:flex] [gap:10px] [justify-content:center] [margin:4px_0] max-[480px]:[gap:7px]" onPaste={handleOtpPaste}>
              {otp.map((digit, i) => (
                <input
                  key={i}
                  ref={(el) => (otpRefs.current[i] = el)}
                  className="[width:48px] [height:56px] [border:2px_solid_#e5d9ff] [border-radius:14px] [font-size:1.4rem] [font-weight:800] [text-align:center] [color:#7b3ff2] [background:#faf7ff] [transition:border-color_0.2s,_box-shadow_0.2s] [outline:none] focus:[border-color:#7b3ff2] focus:[box-shadow:0_0_0_3px_rgba(123,_63,_242,_0.12)] focus:[background:white] max-[480px]:[width:42px] max-[480px]:[height:50px] max-[480px]:[font-size:1.2rem]"
                  type="text"
                  inputMode="numeric"
                  maxLength={1}
                  value={digit}
                  onChange={(e) => handleOtpChange(i, e.target.value)}
                  onKeyDown={(e) => handleOtpKeyDown(i, e)}
                  autoFocus={i === 0}
                />
              ))}
            </div>

            <button type="submit" className="[min-height:56px] [padding:0_28px] [border-radius:18px] [display:inline-flex] [align-items:center] [justify-content:center] [gap:12px] [border:1px_solid_transparent] [font-size:0.96rem] [font-weight:900] [line-height:1] [text-align:center] [text-decoration:none] [white-space:nowrap] [cursor:pointer] [transition:transform_0.25s_ease,_box-shadow_0.25s_ease,_border-color_0.25s_ease,_background_0.25s_ease] [color:#fff] [background:linear-gradient(135deg,_#7b3ff2,_#ff5ca8,_#ff9b54)] [box-shadow:0_20px_42px_rgba(255,_92,_168,_0.28)] hover:[transform:translateY(-3px)] hover:[box-shadow:0_26px_54px_rgba(123,_63,_242,_0.3)] focus-visible:[outline:3px_solid_rgba(123,_63,_242,_0.22)] focus-visible:[outline-offset:4px]" disabled={loading}>
              {loading ? "Verifying…" : "Verify OTP"}
            </button>

            <button
              type="button"
              className="[background:none] [border:none] [color:#7b3ff2] [font-size:13px] [font-weight:600] [cursor:pointer] [text-align:center] [padding:2px_0] [transition:opacity_0.2s] disabled:[color:#bbb] disabled:[cursor:default]"
              onClick={handleResend}
              disabled={resendTimer > 0}
            >
              {resendTimer > 0 ? `Resend OTP in ${resendTimer}s` : "Resend OTP"}
            </button>
          </form>
        )}

        {/* ── Step 3 ── */}
        {step === "reset" && (
          <form onSubmit={handleResetPassword} className="[display:flex] [flex-direction:column] [gap:14px]">
            <PasswordInput
              placeholder="New Password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              required
            />
            <PasswordInput
              placeholder="Confirm New Password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
            />
            <p className="[font-size:11.5px] [color:#999] [margin:-4px_0] [line-height:1.5]">
              Must be 8+ characters with uppercase, lowercase, number &amp;
              special character.
            </p>
            <button type="submit" className="[min-height:56px] [padding:0_28px] [border-radius:18px] [display:inline-flex] [align-items:center] [justify-content:center] [gap:12px] [border:1px_solid_transparent] [font-size:0.96rem] [font-weight:900] [line-height:1] [text-align:center] [text-decoration:none] [white-space:nowrap] [cursor:pointer] [transition:transform_0.25s_ease,_box-shadow_0.25s_ease,_border-color_0.25s_ease,_background_0.25s_ease] [color:#fff] [background:linear-gradient(135deg,_#7b3ff2,_#ff5ca8,_#ff9b54)] [box-shadow:0_20px_42px_rgba(255,_92,_168,_0.28)] hover:[transform:translateY(-3px)] hover:[box-shadow:0_26px_54px_rgba(123,_63,_242,_0.3)] focus-visible:[outline:3px_solid_rgba(123,_63,_242,_0.22)] focus-visible:[outline-offset:4px]" disabled={loading}>
              {loading ? "Resetting…" : "Reset Password"}
            </button>
          </form>
        )}

        {/* ── Done ── */}
        {step === "done" && (
          <div className="[text-align:center] [padding-top:8px]">
            <button className="[min-height:56px] [padding:0_28px] [border-radius:18px] [display:inline-flex] [align-items:center] [justify-content:center] [gap:12px] [border:1px_solid_transparent] [font-size:0.96rem] [font-weight:900] [line-height:1] [text-align:center] [text-decoration:none] [white-space:nowrap] [cursor:pointer] [transition:transform_0.25s_ease,_box-shadow_0.25s_ease,_border-color_0.25s_ease,_background_0.25s_ease] [color:#fff] [background:linear-gradient(135deg,_#7b3ff2,_#ff5ca8,_#ff9b54)] [box-shadow:0_20px_42px_rgba(255,_92,_168,_0.28)] hover:[transform:translateY(-3px)] hover:[box-shadow:0_26px_54px_rgba(123,_63,_242,_0.3)] focus-visible:[outline:3px_solid_rgba(123,_63,_242,_0.22)] focus-visible:[outline-offset:4px]" onClick={onClose}>
              Back to Login
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default ForgotPasswordModal;

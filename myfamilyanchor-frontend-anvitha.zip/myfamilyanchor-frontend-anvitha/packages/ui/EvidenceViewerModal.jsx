
function EvidenceViewerModal({ open, photos, onClose }) {
  if (!open) return null;

  return (
    <div className="[position:fixed] [top:0] [left:0] [right:0] [bottom:0] [background:rgba(15,_23,_42,_0.6)] [backdrop-filter:blur(8px)] [-webkit-backdrop-filter:blur(8px)] [z-index:9999] [display:grid] [place-items:center] [padding:24px] [animation:fadeIn_0.3s_ease]" onClick={onClose}>
      <div className="[background:rgba(255,_255,_255,_0.9)] [backdrop-filter:blur(16px)] [border:1px_solid_rgba(255,_255,_255,_0.8)] [border-radius:24px] [width:min(600px,_100%)] [max-height:85vh] [padding:30px] [box-shadow:0_25px_50px_-12px_rgba(0,_0,_0,_0.25)] [display:flex] [flex-direction:column] [gap:20px] [animation:scaleIn_0.3s_cubic-bezier(0.34,_1.56,_0.64,_1)] [overflow-y:auto] [&_h3]:[font-size:1.4rem] [&_h3]:[font-weight:800] [&_h3]:[color:#0f172a] [&_h3]:[margin:0] [&_button]:[align-self:flex-end] [&_button]:[min-height:44px] [&_button]:[padding:0_24px] [&_button]:[border-radius:12px] [&_button]:[border:none] [&_button]:[background:#0f172a] [&_button]:[color:white] [&_button]:[font-weight:700] [&_button]:[cursor:pointer] [&_button]:[transition:all_0.2s] [&_button]:[box-shadow:0_4px_12px_rgba(15,_23,_42,_0.1)] [&_button:hover]:[background:#1e293b] [&_button:hover]:[transform:translateY(-1px)] [&_button:hover]:[box-shadow:0_6px_16px_rgba(15,_23,_42,_0.15)]" onClick={(e) => e.stopPropagation()}>
        <h3>Job Evidence</h3>

        <div className="[display:grid] [grid-template-columns:repeat(auto-fill,_minmax(200px,_1fr))] [gap:16px] [margin-top:10px] [&_>_div]:[border-radius:16px] [&_>_div]:[overflow:hidden] [&_>_div]:[border:1px_solid_rgba(148,_163,_184,_0.16)] [&_>_div]:[background:white] [&_>_div]:[box-shadow:0_4px_6px_-1px_rgba(0,_0,_0,_0.05)] [&_>_div]:[display:flex] [&_>_div]:[flex-direction:column] [&_img]:[width:100%] [&_img]:[aspect-ratio:4/3] [&_img]:[object-fit:cover] [&_span]:[display:block] [&_span]:[padding:8px_12px] [&_span]:[font-size:0.8rem] [&_span]:[font-weight:700] [&_span]:[color:#475569] [&_span]:[text-transform:uppercase] [&_span]:[background:#f8fafc] [&_span]:[border-top:1px_solid_rgba(148,_163,_184,_0.1)] [&_span]:[text-align:center]">
          {photos?.map((photo, index) => (
            <div key={index}>
              <img src={photo.url} alt="" />

              <span>{photo.photoType}</span>
            </div>
          ))}
        </div>

        <button onClick={onClose}>Close</button>
      </div>
    </div>
  );
}

export default EvidenceViewerModal;

import axios from "axios";

const API = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "http://localhost:5000/api",
});

// Attach user token to every request automatically
API.interceptors.request.use((req) => {
  const isAdminRoute = window.location.pathname.startsWith("/admin");

  const token = isAdminRoute
    ? localStorage.getItem("adminToken")
    : localStorage.getItem("token");
  if (token) {
    req.headers.Authorization = `Bearer ${token}`;
  }
  return req;
});

API.interceptors.response.use(
  (response) => response,
  (error) => {
    const status = error.response?.status;
    const requestUrl = error.config?.url || "";

    // Auth routes handle their own errors — don't intercept them
    const isAuthRoute =
      requestUrl.includes("/auth/login") ||
      requestUrl.includes("/auth/register") ||
      requestUrl.includes("/admin/login");

    if (status === 401 && !isAuthRoute) {
      // Token is stale/expired — clean up and redirect
      localStorage.removeItem("token");
      if (window.location.pathname !== "/login") {
        window.location.href = "/login";
      }
    }

    return Promise.reject(error);
  },
);

export default API;

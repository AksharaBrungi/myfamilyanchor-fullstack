import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "@auth/AuthContext";
import LoadingPage from "@ui/Loadingpage";

function ProtectedRoute() {
  const { user, loading } = useAuth();

  if (loading) {
    // Use the proper LoadingPage so the transition is seamless
    return (
      <LoadingPage title="Just a moment..." subtitle="Verifying your session" />
    );
  }

  if (!user) {
    localStorage.removeItem("token");
    return <Navigate to="/login" replace />;
  }

  return <Outlet />;
}

export default ProtectedRoute;

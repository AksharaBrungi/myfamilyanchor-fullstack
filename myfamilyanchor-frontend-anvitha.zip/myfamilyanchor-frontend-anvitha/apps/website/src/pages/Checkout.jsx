import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import axios from "axios";

function Checkout() {
  const location = useLocation();
  const navigate = useNavigate();
  const [paying, setPaying] = useState(false);

  const state =
    location.state || JSON.parse(localStorage.getItem("selectedPlan"));

  if (!state) {
    return (
      <section className="[width:min(1360px,_calc(100%_-_36px))] [margin:48px_auto_0] [padding:48px_0_96px] max-[640px]:[width:min(100%_-_20px,_520px)] max-[640px]:[padding-left:4px] max-[640px]:[padding-right:4px]">
        <div className="[background:rgba(255,_255,_255,_0.72)] [border:1px_solid_rgba(255,_255,_255,_0.78)] [box-shadow:0_24px_70px_rgba(123,_63,_242,_0.13)] [-webkit-backdrop-filter:blur(22px)] [backdrop-filter:blur(22px)] [width:min(520px,_100%)] [margin:0_auto] [padding:42px] [border-radius:32px] [text-align:center] [&_h1]:[font-size:2.8rem] [&_button]:[width:100%] [&_button]:[min-height:58px] [&_button]:[border:0] [&_button]:[border-radius:18px] [&_button]:[color:white] [&_button]:[background:linear-gradient(_135deg,_#7b3ff2,_#ff5ca8,_#ff9b54_)]">
          <h2>No plan selected</h2>
        </div>
      </section>
    );
  }

  const handlePayment = async () => {
    if (paying) return;
    setPaying(true);

    try {
      const cleanAmount = Number(state.price.replace(/[₹,]/g, ""));

      const { data } = await axios.post(
        `${import.meta.env.VITE_API_URL}/payment/create-order`,
        {
          amount: cleanAmount,
        },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("pendingToken")}`,
          },
        },
      );

      if (!window.Razorpay) {
        await new Promise((resolve, reject) => {
          const script = document.createElement("script");

          script.src = "https://checkout.razorpay.com/v1/checkout.js";

          script.async = true;

          script.onload = resolve;

          script.onerror = () => reject(new Error("Razorpay failed to load"));

          document.body.appendChild(script);
        });
      }

      const options = {
        key: import.meta.env.VITE_RAZORPAY_KEY || "rzp_test_Rp8ogu0zSbNiiW",
        // key: "rzp_test_Rp8ogu0zSbNiiW",
        amount: data.amount,
        currency: data.currency,
        name: "MyFamilyAnchor",
        description: state.name,
        order_id: data.id,

        handler: async function (response) {
          // try {
          //   const verifyResponse = await axios.post(
          //     "http://localhost:5000/api/payment/verify",
          //     {
          //       ...response,

          //       planName: state.name,

          //       billingCycle: state.note,

          //       amount: cleanAmount,
          //     },
          //     {
          //       headers: {
          //         Authorization: `Bearer ${localStorage.getItem("pendingToken")}`,
          //       },
          //     },
          //   );

          // if (verifyResponse.data.success) {
          //   localStorage.setItem("token", localStorage.getItem("pendingToken"));

          //   localStorage.removeItem("pendingToken");

          //   localStorage.removeItem("selectedPlan");

          //   localStorage.removeItem("pendingUserEmail");

          //   sessionStorage.setItem(
          //     "loadingConfig",
          //     JSON.stringify({
          //       title: "Finalizing your payment...",
          //       subtitle: "Please wait while we activate your subscription",
          //       redirectTo: "/success",
          //       duration: 3000,
          //     }),
          //   );

          //   toast.success(
          //     "Payment successful! Activating your subscription...",
          //   );

          navigate("/loading", {
            replace: true,

            state: {
              title: "Verifying your payment...",
              subtitle:
                "Please wait while we confirm and activate your subscription",
              redirectTo: "/success",
              duration: 10000,
              verifyPayload: {
                ...response,
                planName: state.name,
                billingCycle: state.note,
                amount: cleanAmount,
              },
              pendingToken: localStorage.getItem("pendingToken"),
            },
          });
        },

        modal: {
          ondismiss: () => {
            // User closed Razorpay without paying — re-enable the button
            setPaying(false);
          },
        },

        theme: {
          color: "#7b3ff2",
        },
      };

      const razor = new window.Razorpay(options);
      razor.open();
    } catch (error) {
      toast.error("Could not initiate payment. Please try again.");
      console.log(error)
      setPaying(false);
    }
  };

  return (
    <section className="[width:min(1360px,_calc(100%_-_36px))] [margin:48px_auto_0] [padding:48px_0_96px] max-[640px]:[width:min(100%_-_20px,_520px)] max-[640px]:[padding-left:4px] max-[640px]:[padding-right:4px]">
      <div className="[width:min(520px,_100%)] [margin:0_auto] [padding:42px] [border-radius:32px] [text-align:center] [&_h1]:[font-size:2.8rem] [&_button]:[width:100%] [&_button]:[min-height:58px] [&_button]:[border:0] [&_button]:[border-radius:18px] [&_button]:[color:white] [&_button]:[background:linear-gradient(_135deg,_#7b3ff2,_#ff5ca8,_#ff9b54_)] [background:rgba(255,_255,_255,_0.72)] [border:1px_solid_rgba(255,_255,_255,_0.78)] [box-shadow:0_24px_70px_rgba(123,_63,_242,_0.13)] [-webkit-backdrop-filter:blur(22px)] [backdrop-filter:blur(22px)]">
        <h1>{state.name}</h1>

        <p>{state.tagline}</p>

        <div className="[margin:24px_0] [font-size:3rem] [font-weight:900]">
          {state.price}
        </div>

        <button onClick={handlePayment} disabled={paying}>
          {paying ? "Opening Payment..." : "Proceed To Payment"}
        </button>
      </div>
    </section>
  );
}

export default Checkout;

import { useEffect, useState } from "react";
import { FiEdit, FiUser, FiLock } from "react-icons/fi";
import toast from "react-hot-toast";
import { useAuth } from "@auth/AuthContext";
import API from "@api/axios";
import PasswordInput from "@ui/PasswordInput";

function Settings() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const { refreshUser } = useAuth();
  const [editingName, setEditingName] = useState(false);
  const [editingEmail, setEditingEmail] = useState(false);
  const [editingPhone, setEditingPhone] = useState(false);

  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [passwordVerified, setPasswordVerified] = useState(false);
  const [verifyingPassword, setVerifyingPassword] = useState(false);

  useEffect(() => {
    fetchProfile();
  }, []);

  useEffect(() => {
    if (!passwordData.currentPassword) {
      setPasswordVerified(false);
      setVerifyingPassword(false);
      return;
    }

    let active = true;

    const verifyTimer = setTimeout(async () => {
      try {
        setVerifyingPassword(true);
        await API.post("/auth/verify-password", {
          currentPassword: passwordData.currentPassword,
        });

        if (active) {
          setPasswordVerified(true);
        }
      } catch {
        if (active) {
          setPasswordVerified(false);
        }
      } finally {
        if (active) {
          setVerifyingPassword(false);
        }
      }
    }, 600);

    return () => {
      active = false;
      clearTimeout(verifyTimer);
    };
  }, [passwordData.currentPassword]);

  const fetchProfile = async () => {
    try {
      const { data } = await API.get("/auth/me");

      setName(data.name || "");
      setEmail(data.email || "");
      setPhone(data.phone || "");
    } catch {
      toast.error("Failed to load profile");
    }
  };

  const updateName = async () => {
    try {
      await API.put("/auth/profile", {
        name,
      });

      await refreshUser();
      await fetchProfile();

      setEditingName(false);

      toast.success("Name updated");
    } catch (error) {
      toast.error(error.response?.data?.message || "Failed to update name");
    }
  };

  const updateEmail = async () => {
    try {
      await API.put("/auth/profile", {
        email,
      });

      await refreshUser();
      await fetchProfile();

      setEditingEmail(false);

      toast.success("Email updated");
    } catch (error) {
      toast.error(error.response?.data?.message || "Failed to update email");
    }
  };

  const updatePhone = async () => {
    try {
      await API.put("/auth/profile", {
        phone,
      });

      await refreshUser();
      await fetchProfile();

      setEditingPhone(false);

      toast.success("Phone updated");
    } catch (error) {
      toast.error(
        error.response?.data?.message || "Failed to update phone number",
      );
    }
  };

  const updatePassword = async () => {
    if (!passwordVerified) {
      return toast.error("Verify your current password first");
    }

    if (passwordData.newPassword !== passwordData.confirmPassword) {
      return toast.error("Passwords do not match");
    }

    try {
      await API.put("/auth/change-password", passwordData);

      toast.success("Password updated");

      setPasswordData({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      });
      setPasswordVerified(false);
    } catch (error) {
      toast.error(error.response?.data?.message || "Failed to update password");
    }
  };

  /* ── Shared class strings ── */
  const glassCard = `
    px-[42px] py-[38px] rounded-[32px]
    bg-[rgba(255,255,255,0.72)]
    border border-[rgba(255,255,255,0.84)]
    shadow-[0_28px_80px_rgba(123,63,242,0.08)]
    backdrop-blur-[18px]
    transition-all duration-300 ease-in-out
    hover:-translate-y-0.5 hover:shadow-[0_34px_90px_rgba(123,63,242,0.12)]
    max-[768px]:px-6 max-[768px]:py-6
  `;

  const inputCls = `
    w-full min-h-[58px] px-[18px]
    rounded-[18px]
    border border-[rgba(148,163,184,0.18)]
    bg-[rgba(255,255,255,0.9)]
    text-base
    transition-all duration-[250ms] ease-in-out
    focus:outline-none
    focus:border-[rgba(123,63,242,0.45)]
    focus:shadow-[0_0_0_4px_rgba(123,63,242,0.08),0_12px_30px_rgba(123,63,242,0.08)]
    disabled:bg-[#f8fafc] disabled:text-[#64748b] disabled:cursor-not-allowed disabled:opacity-90
  `;

  const editBtnCls = `
    w-[58px] h-[58px] shrink-0
    border-none rounded-[18px]
    flex items-center justify-center
    cursor-pointer text-[#7b3ff2] text-[1.25rem]
    bg-[rgba(123,63,242,0.08)]
    transition-all duration-[250ms] ease-in-out
    hover:bg-[rgba(123,63,242,0.15)] hover:-translate-y-0.5
    [&_svg]:w-[22px] [&_svg]:h-[22px]
  `;

  const updateBtnCls = `
    h-[58px] min-w-[140px] px-6
    border-none rounded-[18px]
    text-white font-extrabold
    bg-gradient-to-br from-[#7b3ff2] to-[#ff5ca8]
    shadow-[0_12px_24px_rgba(123,63,242,0.15)]
    transition-all duration-[250ms] ease-in-out
    hover:-translate-y-0.5 hover:shadow-[0_18px_32px_rgba(123,63,242,0.22)]
    disabled:opacity-50 disabled:cursor-not-allowed disabled:translate-y-0 disabled:shadow-none
    max-[768px]:w-full
  `;

  const settingRowCls =
    "flex items-end gap-4 mb-6 max-[768px]:flex-col max-[768px]:items-stretch";
  const labelCls = "block mb-2.5 font-bold text-[#475569]";
  const sectionIconCls = `
    w-14 h-14 rounded-[18px] shrink-0
    flex items-center justify-center
    bg-gradient-to-br from-[rgba(123,63,242,0.12)] to-[rgba(255,92,168,0.12)]
    text-[#7b3ff2] text-2xl
    [&_svg]:w-[26px] [&_svg]:h-[26px]
  `;

  return (
    <section className="w-full max-w-[1240px] mx-auto flex flex-col gap-6">
      {/* ── Page header hero ── */}
      <div
        className="
            px-10 py-9 rounded-[28px]
            bg-[rgba(255,255,255,0.72)]
            border border-[rgba(255,255,255,0.78)]
            shadow-[0_24px_70px_rgba(123,63,242,0.13)]
            backdrop-blur-[22px]
            max-[768px]:px-6 max-[768px]:py-6
          "
      >
        <span className="text-[#7b3ff2] text-[0.78rem] font-extrabold tracking-[0.14em] uppercase">
          Account Settings
        </span>
        <h1 className="text-[clamp(2.6rem,4vw,4rem)] font-black text-[#111827] mt-2 leading-[1.05]">
          Profile &amp; Security
        </h1>
        <p className="mt-3 text-slate-600 leading-[1.7] max-w-[700px]">
          Manage your personal information, account preferences and security
          settings.
        </p>
      </div>

      {/* ── Personal Information card ── */}
      <div className={glassCard}>
        <div className="flex items-center gap-[14px] mb-6">
          <div className={sectionIconCls}>
            <FiUser />
          </div>
          <h2 className="m-0 text-[2rem] text-[#111827] font-bold">
            Personal Information
          </h2>
        </div>

        {/* Name row */}
        <div className={settingRowCls}>
          <div className="flex-1">
            <label className={labelCls}>Full Name</label>
            <input
              className={inputCls}
              type="text"
              disabled={!editingName}
              placeholder="Enter your full name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <button
            type="button"
            className={editBtnCls}
            onClick={() => setEditingName(!editingName)}
          >
            <FiEdit />
          </button>
          <button
            className={updateBtnCls}
            disabled={!editingName}
            onClick={updateName}
          >
            Update
          </button>
        </div>

        {/* Email row */}
        <div className={settingRowCls}>
          <div className="flex-1">
            <label className={labelCls}>Email Address</label>
            <input
              className={inputCls}
              type="email"
              disabled={!editingEmail}
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <button
            type="button"
            className={editBtnCls}
            onClick={() => setEditingEmail(!editingEmail)}
          >
            <FiEdit />
          </button>
          <button
            className={updateBtnCls}
            disabled={!editingEmail}
            onClick={updateEmail}
          >
            Update
          </button>
        </div>

        {/* Phone row */}
        <div className={`${settingRowCls} !mb-0`}>
          <div className="flex-1">
            <label className={labelCls}>Phone Number</label>
            <input
              className={inputCls}
              type="text"
              disabled={!editingPhone}
              placeholder="Enter your number"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
            />
          </div>
          <button
            type="button"
            className={editBtnCls}
            onClick={() => setEditingPhone(!editingPhone)}
          >
            <FiEdit />
          </button>
          <button
            className={updateBtnCls}
            disabled={!editingPhone}
            onClick={updatePhone}
          >
            Update
          </button>
        </div>
      </div>

      {/* ── Change Password card ── */}
      <div className={glassCard}>
        <div className="flex items-center gap-[14px] mb-6">
          <div className={sectionIconCls}>
            <FiLock />
          </div>
          <h2 className="m-0 text-[2rem] text-[#111827] font-bold">
            Change Password
          </h2>
        </div>

        <div className="flex flex-col gap-[18px]">
          <PasswordInput
            className={inputCls}
            placeholder="Current Password"
            value={passwordData.currentPassword}
            onChange={(e) => {
              setPasswordVerified(false);
              setPasswordData({
                ...passwordData,
                currentPassword: e.target.value,
                newPassword: "",
                confirmPassword: "",
              });
            }}
          />
          <PasswordInput
            className={inputCls}
            disabled={!passwordVerified || verifyingPassword}
            placeholder="New Password"
            value={passwordData.newPassword}
            onChange={(e) =>
              setPasswordData({ ...passwordData, newPassword: e.target.value })
            }
          />
          <PasswordInput
            className={inputCls}
            disabled={!passwordVerified || verifyingPassword}
            placeholder="Confirm Password"
            value={passwordData.confirmPassword}
            onChange={(e) =>
              setPasswordData({
                ...passwordData,
                confirmPassword: e.target.value,
              })
            }
          />
          <button
            className="
                  w-full min-h-[60px] mt-3
                  border-none rounded-[18px]
                  text-base font-extrabold text-white cursor-pointer
                  bg-gradient-to-r from-[#7b3ff2] via-[#ff5ca8] to-[#ff9b54]
                  shadow-[0_20px_36px_rgba(255,92,168,0.2)]
                  transition-all duration-300 ease-in-out
                  hover:-translate-y-0.5 hover:shadow-[0_24px_42px_rgba(255,92,168,0.28)]
                  active:translate-y-0
                  disabled:opacity-[0.58] disabled:cursor-not-allowed disabled:translate-y-0 disabled:shadow-none
                "
            disabled={!passwordVerified || verifyingPassword}
            onClick={updatePassword}
          >
            Update Password
          </button>
        </div>
      </div>
    </section>
  );
}

export default Settings;

import { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import API from "@api/axios";

const PASSWORD_REGEX =
  /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#^()_+\-=[\]{};':"\\|,.<>/?]).{8,}$/;

const TRUST_ITEMS = [
  "Trusted NRI Support",
  "Real-Time Updates",
  "Dedicated Assistance",
  "Secure & Encrypted",
];

/* ── Inline SVG icons — zero dependency, always crisp ── */
const IconUser = () => (
  <svg
    width="16"
    height="16"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <circle cx="12" cy="8" r="4" />
    <path d="M4 20c0-4 3.6-7 8-7s8 3 8 7" />
  </svg>
);
const IconMail = () => (
  <svg
    width="16"
    height="16"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <rect x="2" y="4" width="20" height="16" rx="2" />
    <path d="M2 7l10 7 10-7" />
  </svg>
);
const IconPhone = () => (
  <svg
    width="16"
    height="16"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M22 16.9a15.9 15.9 0 01-4.7.7 15.2 15.2 0 01-6.4-1.4L4 17.5A1 1 0 013 16.6V7.4A1 1 0 014 6.5l6.9 1.2A15.2 15.2 0 0117.3 6a15.9 15.9 0 014.7.7" />
    <path d="M5 6.5V17.5" />
  </svg>
);
const IconLock = () => (
  <svg
    width="16"
    height="16"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <rect x="3" y="11" width="18" height="11" rx="2" />
    <path d="M7 11V7a5 5 0 0110 0v4" />
  </svg>
);
const IconEye = () => (
  <svg
    width="17"
    height="17"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
    <circle cx="12" cy="12" r="3" />
  </svg>
);
const IconEyeOff = () => (
  <svg
    width="17"
    height="17"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M17.94 17.94A10.9 10.9 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94" />
    <path d="M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19" />
    <line x1="1" y1="1" x2="23" y2="23" />
  </svg>
);
const IconSpinner = () => (
  <svg
    className="animate-spin"
    width="16"
    height="16"
    viewBox="0 0 24 24"
    fill="none"
  >
    <circle
      className="opacity-25"
      cx="12"
      cy="12"
      r="10"
      stroke="currentColor"
      strokeWidth="4"
    />
    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
  </svg>
);

/* ── Reusable input row ── */
function InputField({
  Icon,
  type = "text",
  placeholder,
  required,
  onChange,
  right,
}) {
  return (
    <div className="relative flex items-center">
      <span className="pointer-events-none absolute left-4 flex items-center text-slate-400">
        <Icon />
      </span>
      <input
        type={type}
        placeholder={placeholder}
        required={required}
        onChange={onChange}
        className="w-full rounded-2xl border border-slate-200 bg-white/80 py-[15px] pl-[44px] pr-12 text-[15px] text-gray-800 shadow-sm placeholder:text-slate-400 transition-all duration-200 focus:border-violet-400 focus:bg-white focus:outline-none focus:ring-4 focus:ring-violet-100"
      />
      {right && (
        <span className="absolute right-4 flex items-center">{right}</span>
      )}
    </div>
  );
}

function Auth() {
  const navigate = useNavigate();
  const { state } = useLocation();
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    phone: "",
  });

  useEffect(() => {
    if (!state) {
      const savedPlan = localStorage.getItem("selectedPlan");
      if (!savedPlan) navigate("/pricing");
    }
  }, [state, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!PASSWORD_REGEX.test(formData.password)) {
      toast.error(
        "Password must contain uppercase, lowercase, number and special character",
      );
      return;
    }
    try {
      setLoading(true);
      const { data } = await API.post("/auth/register", formData);
      localStorage.setItem("pendingUserEmail", formData.email);
      localStorage.setItem("pendingToken", data.token);
      localStorage.setItem(
        "selectedPlan",
        JSON.stringify({ ...state, email: formData.email }),
      );
      navigate("/checkout");
    } catch (error) {
      toast.error(error.response?.data?.message || "Registration failed");
    } finally {
      setLoading(false);
    }
  };

  const field = (key) => (e) =>
    setFormData({ ...formData, [key]: e.target.value });

  return (
    <section
      className="flex min-h-[calc(100vh-80px)] items-center justify-center px-5 py-14"
      style={{
        background:
          "radial-gradient(circle at 15% 30%, rgba(123,63,242,0.07), transparent 40%), radial-gradient(circle at 85% 10%, rgba(255,92,168,0.08), transparent 38%), #f8f7ff",
      }}
    >
      <div className="grid w-full max-w-[1100px] grid-cols-1 items-stretch gap-6 lg:grid-cols-2">
        {/* ── LEFT: Plan Summary ── */}
        <div
          className="relative order-2 flex flex-col justify-between overflow-hidden rounded-3xl border border-white/80 p-10 backdrop-blur-xl lg:order-1 lg:min-h-[620px]"
          style={{
            background:
              "radial-gradient(circle at 90% 0%, rgba(255,155,84,0.18), transparent 40%), radial-gradient(circle at 10% 100%, rgba(123,63,242,0.14), transparent 40%), rgba(255,255,255,0.72)",
            boxShadow:
              "0 24px 70px rgba(123,63,242,0.10), inset 0 1px 0 rgba(255,255,255,0.85)",
          }}
        >
          {/* Decorative orb */}
          <div
            className="pointer-events-none absolute -right-16 -bottom-16 h-56 w-56 rounded-full opacity-40"
            style={{
              background:
                "radial-gradient(circle, rgba(255,92,168,0.35), transparent 70%)",
              filter: "blur(24px)",
            }}
          />

          <div className="relative z-10">
            <span className="inline-block rounded-full bg-violet-100 px-3 py-1 text-[11px] font-extrabold uppercase tracking-[0.16em] text-violet-600">
              Selected Plan
            </span>

            <h2
              className="mt-5 text-[clamp(2rem,3.5vw,3rem)] font-bold leading-[1.05] text-gray-900"
              style={{ fontFamily: "Georgia, 'Times New Roman', serif" }}
            >
              {state?.name}
            </h2>

            <p className="mt-3 text-[15px] leading-relaxed text-gray-500">
              {state?.tagline}
            </p>

            <div className="mt-8 flex items-end gap-2">
              <span className="text-[clamp(2.2rem,4vw,3.2rem)] font-extrabold leading-none text-gray-900">
                {state?.price}
              </span>
              <span className="mb-1 text-sm font-semibold text-gray-400">
                {state?.note}
              </span>
            </div>

            <div className="my-8 h-px w-full bg-gradient-to-r from-violet-200/60 via-pink-200/60 to-transparent" />

            <ul className="flex flex-col gap-3">
              {TRUST_ITEMS.map((item) => (
                <li
                  key={item}
                  className="flex items-center gap-3 text-[15px] font-semibold text-gray-700"
                >
                  <span
                    className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full text-[11px] font-black text-white"
                    style={{
                      background: "linear-gradient(135deg,#7b3ff2,#ff5ca8)",
                    }}
                  >
                    ✓
                  </span>
                  {item}
                </li>
              ))}
            </ul>
          </div>

          <p className="relative z-10 mt-10 text-xs leading-relaxed text-gray-400">
            🔒 Your information is encrypted and secure. Cancel anytime.
          </p>
        </div>

        {/* ── RIGHT: Registration Form ── */}
        <form
          onSubmit={handleSubmit}
          className="relative order-1 flex flex-col justify-center overflow-hidden rounded-3xl border border-white/80 p-10 backdrop-blur-xl lg:order-2 lg:min-h-[620px]"
          style={{
            background: "rgba(255,255,255,0.82)",
            boxShadow:
              "0 24px 70px rgba(123,63,242,0.10), inset 0 1px 0 rgba(255,255,255,0.9)",
          }}
        >
          {/* Header */}
          <div className="mb-8">
            <span className="inline-block rounded-full bg-violet-100 px-3 py-1 text-[11px] font-extrabold uppercase tracking-[0.16em] text-violet-600">
              Create Account
            </span>
            <h1
              className="mt-4 text-[clamp(2rem,3.5vw,2.8rem)] font-bold leading-tight text-gray-900"
              style={{ fontFamily: "Georgia, 'Times New Roman', serif" }}
            >
              Get Started
            </h1>
            <p className="mt-2 text-[15px] leading-relaxed text-gray-500">
              Create your account to activate your care subscription and access
              your dashboard.
            </p>
          </div>

          {/* Fields */}
          <div className="flex flex-col gap-3.5">
            <InputField
              Icon={IconUser}
              type="text"
              placeholder="Full Name"
              required
              onChange={field("name")}
            />
            <InputField
              Icon={IconMail}
              type="email"
              placeholder="Email Address"
              required
              onChange={field("email")}
            />
            <InputField
              Icon={IconPhone}
              type="tel"
              placeholder="+91 98765 43210"
              required
              onChange={field("phone")}
            />

            {/* Password with eye toggle */}
            <div className="relative flex items-center">
              <span className="pointer-events-none absolute left-4 flex items-center text-slate-400">
                <IconLock />
              </span>
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Create Password"
                required
                onChange={field("password")}
                className="w-full rounded-2xl border border-slate-200 bg-white/80 py-[15px] pl-[44px] pr-12 text-[15px] text-gray-800 shadow-sm placeholder:text-slate-400 transition-all duration-200 focus:border-violet-400 focus:bg-white focus:outline-none focus:ring-4 focus:ring-violet-100"
              />
              <button
                type="button"
                tabIndex={-1}
                onClick={() => setShowPassword((v) => !v)}
                aria-label={showPassword ? "Hide password" : "Show password"}
                className="absolute right-4 flex items-center text-slate-400 transition-colors hover:text-violet-500 focus:outline-none"
              >
                {showPassword ? <IconEyeOff /> : <IconEye />}
              </button>
            </div>

            <p className="px-1 text-xs text-slate-400">
              Min. 8 characters with uppercase, lowercase, number &amp; symbol.
            </p>
          </div>

          {/* Submit */}
          <button
            type="submit"
            disabled={loading}
            className="mt-7 flex w-full items-center justify-center gap-2 rounded-2xl py-4 text-[15px] font-extrabold tracking-wide text-white transition-all duration-200 hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-60"
            style={{
              background: "linear-gradient(135deg, #7b3ff2, #ff5ca8, #ff9b54)",
              boxShadow: "0 16px 40px rgba(123,63,242,0.25)",
            }}
          >
            {loading ? (
              <>
                <IconSpinner /> Creating Account…
              </>
            ) : (
              "Continue To Payment →"
            )}
          </button>

          <p className="mt-5 text-center text-sm text-gray-500">
            Already have an account?{" "}
            <Link
              to="/login"
              className="font-bold text-violet-600 hover:text-violet-700"
            >
              Login
            </Link>
          </p>
        </form>
      </div>
    </section>
  );
}

export default Auth;

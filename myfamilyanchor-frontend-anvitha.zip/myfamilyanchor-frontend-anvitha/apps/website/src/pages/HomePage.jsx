import Hero from "../components/Hero";

const gradientText = {
  background: "linear-gradient(135deg, #7b3ff2, #ff5ca8, #ff9b54)",
  WebkitBackgroundClip: "text",
  backgroundClip: "text",
  color: "transparent",
};

const trustItems = [
  {
    bg: "linear-gradient(135deg,#ff5ca8,#ff9b54)",
    stat: "24/7",
    label: "Emergency Support",
    icon: (
      <svg
        width="22"
        height="22"
        viewBox="0 0 24 24"
        fill="none"
        stroke="white"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.8 19.79 19.79 0 01.01 1.18 2 2 0 012 0h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.09 7.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 14.92z" />
      </svg>
    ),
  },
  {
    bg: "linear-gradient(135deg,#5b8cff,#7b3ff2)",
    stat: "100+",
    label: "Verified Care Experts",
    icon: (
      <svg
        width="22"
        height="22"
        viewBox="0 0 24 24"
        fill="none"
        stroke="white"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
        <polyline points="9 12 11 14 15 10" />
      </svg>
    ),
  },
  {
    bg: "linear-gradient(135deg,#ff5ca8,#ff8fba)",
    stat: "30+",
    label: "Cities in India",
    icon: (
      <svg
        width="22"
        height="22"
        viewBox="0 0 24 24"
        fill="none"
        stroke="white"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 0118 0z" />
        <circle cx="12" cy="10" r="3" />
      </svg>
    ),
  },
  {
    bg: "linear-gradient(135deg,#b13cff,#7b3ff2)",
    stat: "10,000+",
    label: "Happy Families",
    icon: (
      <svg
        width="22"
        height="22"
        viewBox="0 0 24 24"
        fill="none"
        stroke="white"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <path d="M23 21v-2a4 4 0 00-3-3.87" />
        <path d="M16 3.13a4 4 0 010 7.75" />
      </svg>
    ),
  },
  {
    bg: "linear-gradient(135deg,#ffbf2f,#ff9b54)",
    stat: "4.8/5",
    label: "Google Rating",
    icon: (
      <svg
        width="22"
        height="22"
        viewBox="0 0 24 24"
        fill="white"
        stroke="white"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
      </svg>
    ),
  },
];

const servicesPreview = [
  {
    title: "Health & Wellness",
    desc: "Doctor visits, health checkups and wellness monitoring.",
    bg: "linear-gradient(135deg,#ff5ca8,#ff8fba)",
    icon: (
      <svg
        width="26"
        height="26"
        viewBox="0 0 24 24"
        fill="none"
        stroke="white"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z" />
      </svg>
    ),
  },
  {
    title: "Daily Living Support",
    desc: "Meals, errands, housekeeping and daily assistance.",
    bg: "linear-gradient(135deg,#5b8cff,#7b3ff2)",
    icon: (
      <svg
        width="26"
        height="26"
        viewBox="0 0 24 24"
        fill="none"
        stroke="white"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
        <polyline points="9 22 9 12 15 12 15 22" />
      </svg>
    ),
  },
  {
    title: "24/7 Emergency Care",
    desc: "Ambulance, hospital and critical support when needed.",
    bg: "linear-gradient(135deg,#ffbf2f,#ff9b54)",
    icon: (
      <svg
        width="26"
        height="26"
        viewBox="0 0 24 24"
        fill="none"
        stroke="white"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
      </svg>
    ),
  },
  {
    title: "Companionship",
    desc: "Regular conversations and emotional engagement.",
    bg: "linear-gradient(135deg,#b13cff,#7b3ff2)",
    icon: (
      <svg
        width="26"
        height="26"
        viewBox="0 0 24 24"
        fill="none"
        stroke="white"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <path d="M23 21v-2a4 4 0 00-3-3.87" />
        <path d="M16 3.13a4 4 0 010 7.75" />
      </svg>
    ),
  },
  {
    title: "NRI Property Care",
    desc: "Home monitoring, maintenance and property support.",
    bg: "linear-gradient(135deg,#48c774,#16a34a)",
    icon: (
      <svg
        width="26"
        height="26"
        viewBox="0 0 24 24"
        fill="none"
        stroke="white"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
        <path d="M7 11V7a5 5 0 0110 0v4" />
      </svg>
    ),
  },
];

function HomePage() {
  return (
    <>
      <Hero />

      {/* TRUST STRIP */}
      <section
        className="[display:flex] [flex-wrap:wrap] [justify-content:center] [gap:10px_0] [width:min(1240px,_calc(100%_-_28px))] [margin:32px_auto_0] [padding:28px_32px] [border-radius:28px] [background:rgba(255,_255,_255,_0.72)] [border:1px_solid_rgba(255,_255,_255,_0.78)] [box-shadow:0_24px_70px_rgba(123,_63,_242,_0.13)] [-webkit-backdrop-filter:blur(22px)] [backdrop-filter:blur(22px)]"
        aria-label="Trust metrics"
      >
        {trustItems.map(({ bg, stat, label, icon }, i) => (
          <div
            key={label}
            className="[display:flex] [align-items:center] [gap:14px] [padding:0_28px] [flex:1_1_180px] max-[640px]:[padding:0_14px]"
            style={
              i > 0 ? { borderLeft: "1px solid rgba(123,63,242,0.12)" } : {}
            }
          >
            <span
              style={{
                background: bg,
                width: "46px",
                height: "46px",
                borderRadius: "15px",
                display: "grid",
                placeItems: "center",
                flexShrink: 0,
                boxShadow: "0 14px 28px rgba(123,63,242,0.22)",
              }}
            >
              {icon}
            </span>
            <div>
              <strong className="[display:block] [font-size:1.35rem] [color:#111827] [line-height:1]">
                {stat}
              </strong>
              <p className="[margin:6px_0_0] [color:#4b5563] [font-size:0.86rem] [font-weight:600]">
                {label}
              </p>
            </div>
          </div>
        ))}
      </section>

      {/* SERVICES SECTION */}
      <section className="[width:min(1240px,_calc(100%_-_28px))] [margin:64px_auto_0] [padding-bottom:80px]">
        <div className="[text-align:center] [margin-bottom:48px]">
          <span className="[color:#7b3ff2] [font-size:0.78rem] [font-weight:800] [letter-spacing:0.14em] [text-transform:uppercase]">
            Our Care Services
          </span>
          <h2 className="[margin:12px_auto_0] [width:min(850px,_100%)] [font-family:Cormorant_Garamond_serif] [color:#0b1026] [font-size:clamp(2.7rem,_4vw,_4.4rem)] [line-height:1] [letter-spacing:0]">
            Complete Care for Your Parents,{" "}
            <span style={gradientText}>Under One Roof</span>
          </h2>
        </div>

        <div className="[display:grid] [grid-template-columns:repeat(5,_1fr)] [gap:18px] max-[1024px]:[grid-template-columns:repeat(3,_1fr)] max-[640px]:[grid-template-columns:repeat(2,_1fr)] max-[480px]:[grid-template-columns:1fr]">
          {servicesPreview.map(({ title, desc, bg, icon }) => (
            <article
              className="[padding:28px_22px] [border-radius:28px] [background:rgba(255,_255,_255,_0.72)] [border:1px_solid_rgba(255,_255,_255,_0.82)] [box-shadow:0_18px_48px_rgba(123,_63,_242,_0.08)] [transition:0.28s_ease] hover:[transform:translateY(-8px)] hover:[box-shadow:0_28px_60px_rgba(123,_63,_242,_0.14)] [&_h3]:[margin:0_0_10px] [&_h3]:[color:#111827] [&_h3]:[font-size:1.05rem] [&_h3]:[font-weight:700] [&_p]:[margin:0_0_18px] [&_p]:[color:#4b5563] [&_p]:[font-size:0.88rem] [&_p]:[line-height:1.65] [&_a]:[color:#7b3ff2] [&_a]:[font-weight:700] [&_a]:[font-size:0.88rem]"
              key={title}
            >
              <span
                className="[width:58px] [height:58px] [border-radius:20px] [display:grid] [place-items:center] [margin-bottom:20px] [box-shadow:0_12px_28px_rgba(123,_63,_242,_0.2)]"
                style={{ background: bg }}
              >
                {icon}
              </span>
              <h3>{title}</h3>
              <p>{desc}</p>
              <a href="/services">Learn More →</a>
            </article>
          ))}
        </div>
      </section>
    </>
  );
}

export default HomePage;

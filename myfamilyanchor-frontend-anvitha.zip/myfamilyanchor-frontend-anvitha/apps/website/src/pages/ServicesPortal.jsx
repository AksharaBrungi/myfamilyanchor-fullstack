import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import API from "@api/axios";
import socket from "@api/socket";
import EvidenceViewerModal from "@ui/EvidenceViewerModal";

const cardCls =
  "rounded-[28px] border border-white/80 bg-white/70 shadow-[0_24px_70px_rgba(123,63,242,0.13)] backdrop-blur-xl";

const STATUS_THEME = {
  pending: { label: "Pending", bg: "bg-amber-100", text: "text-amber-700" },
  "in-progress": {
    label: "In Progress",
    bg: "bg-violet-100",
    text: "text-violet-700",
  },
  completed: { label: "Completed", bg: "bg-green-100", text: "text-green-700" },
  cancelled: { label: "Cancelled", bg: "bg-slate-100", text: "text-slate-500" },
};

const PRIORITY_THEME = {
  low: { label: "Low", color: "#0ea5e9" },
  normal: { label: "Normal", color: "#7b3ff2" },
  high: { label: "High", color: "#f97316" },
  emergency: { label: "Emergency", color: "#ef4444" },
};

function formatLabel(value = "") {
  return value
    .toString()
    .replace(/[-_]+/g, " ")
    .trim()
    .replace(/\s+/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

function StatusBadge({ status }) {
  const theme = STATUS_THEME[status] || {
    label: formatLabel(status),
    bg: "bg-slate-100",
    text: "text-slate-500",
  };
  return (
    <span
      className={`rounded-full px-3 py-1 text-xs font-extrabold ${theme.bg} ${theme.text}`}
    >
      {theme.label}
    </span>
  );
}

function PriorityChip({ priority }) {
  const theme = PRIORITY_THEME[priority] || {
    label: formatLabel(priority),
    color: "#7b3ff2",
  };
  return (
    <span
      className="inline-block rounded-full px-2.5 py-1 text-xs font-bold text-white"
      style={{ background: theme.color }}
    >
      {theme.label}
    </span>
  );
}

function StatChip({ label, value, color }) {
  return (
    <div
      className={`${cardCls} flex flex-1 items-center gap-4 rounded-2xl px-5 py-4`}
    >
      <span
        className="h-2.5 w-2.5 shrink-0 rounded-full"
        style={{ background: color, boxShadow: `0 0 0 4px ${color}22` }}
      />
      <div>
        <p className="text-2xl font-black text-[#111827]">{value}</p>
        <p className="text-xs font-bold uppercase tracking-[0.05em] text-slate-400">
          {label}
        </p>
      </div>
    </div>
  );
}

function GhostButton({ children, ...props }) {
  return (
    <button
      type="button"
      className="inline-flex min-h-[42px] items-center justify-center rounded-2xl bg-[rgba(123,63,242,0.1)] px-4 font-extrabold text-[#6d3dea] transition hover:-translate-y-0.5 hover:bg-[rgba(123,63,242,0.16)] disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:translate-y-0"
      {...props}
    >
      {children}
    </button>
  );
}

function ServicesPortal() {
  const navigate = useNavigate();
  const [requests, setRequests] = useState([]);
  const [photos, setPhotos] = useState([]);
  const [openModal, setOpenModal] = useState(false);
  const [cancellingId, setCancellingId] = useState("");

  const fetchRequests = async () => {
    try {
      const { data } = await API.get("/services/my-requests");

      setRequests(data.filter((request) => request.status !== "cancelled"));
    } catch (error) {
      console.log(error);

      toast.error(
        error.response?.data?.message || "Failed to load service requests",
      );
    }
  };

  useEffect(() => {
    fetchRequests();

    const handleRealtimeUpdate = () => {
      fetchRequests();
    };

    socket.on("request-updated", handleRealtimeUpdate);

    return () => {
      socket.off("request-updated", handleRealtimeUpdate);
    };
  }, []);

  const formatDate = (date) =>
    date
      ? new Date(date).toLocaleDateString("en-IN", {
          day: "numeric",
          month: "short",
          year: "numeric",
        })
      : "Not set";

  const canModify = (request) => {
    if (!["pending", "in-progress"].includes(request.status)) return false;
    const hasBeforePhotos = (request.jobPhotos || []).some(
      (p) => p.photoType === "before",
    );
    return !hasBeforePhotos;
  };

  const handleEditRequest = (request) => {
    navigate("/request-service", {
      state: {
        editRequest: request,
      },
    });
  };

  const handleCancelRequest = async (requestId) => {
    const confirmed = window.confirm(
      "Cancel this service request? This action cannot be undone.",
    );

    if (!confirmed) return;

    try {
      setCancellingId(requestId);
      await API.put(`/services/cancel/${requestId}`);

      setRequests((currentRequests) =>
        currentRequests.filter((request) => request._id !== requestId),
      );
      toast.success("Service request cancelled");
    } catch (error) {
      toast.error(error.response?.data?.message || "Unable to cancel request");
    } finally {
      setCancellingId("");
    }
  };

  const getRequestProgressPercentage = (request) => {
    if (!request) return 0;
    if (request.status === "cancelled") return 0;

    const hasAuditLog = (pattern) => {
      return (request.auditLogs || []).some(
        (log) =>
          log.action &&
          log.action.toLowerCase().includes(pattern.toLowerCase()),
      );
    };

    const isRejected = request.verificationStatus === "rejected";

    const isStep1 =
      !!request.assignedTo ||
      !!request.assignedStaffId ||
      request.status !== "pending" ||
      hasAuditLog("Assigned to") ||
      hasAuditLog("Status changed");
    const isStep2 =
      !!request.assignedVendor ||
      !!request.assignedVendorId ||
      hasAuditLog("Vendor assigned");
    const isStep3 =
      (request.jobPhotos || []).some((p) => p.photoType === "before") ||
      hasAuditLog("photos uploaded") ||
      hasAuditLog("photo uploaded");
    const isStep4 = (request.jobPhotos || []).some(
      (p) => p.photoType === "after",
    );
    const isStep5 =
      (request.vendorNotes || []).length > 0 ||
      hasAuditLog("Vendor note added");
    const isStep6 =
      !isRejected &&
      (request.verificationStatus === "submitted" ||
        request.verificationStatus === "staff-approved" ||
        request.verificationStatus === "approved" ||
        hasAuditLog("Completion submitted by vendor"));
    const isStep7 =
      !isRejected &&
      (request.verificationStatus === "submitted" ||
        request.verificationStatus === "staff-approved" ||
        request.verificationStatus === "approved" ||
        hasAuditLog("Waiting for staff verification"));
    const isStep8 =
      !isRejected &&
      ((request.staffNotes || []).length > 0 ||
        hasAuditLog("Staff note added"));
    const isStep9 =
      !isRejected &&
      (request.verificationStatus === "staff-approved" ||
        request.verificationStatus === "approved" ||
        hasAuditLog("Completion verified by staff"));
    const isStep10 =
      !isRejected &&
      (request.verificationStatus === "approved" ||
        request.status === "completed" ||
        hasAuditLog("Completion approved by admin"));

    let s1 = isStep1;
    let s2 = isStep2;
    let s3 = isStep3;
    let s4 = isStep4;
    let s5 = isStep5;
    let s6 = isStep6;
    let s7 = isStep7;
    let s8 = isStep8;
    let s9 = isStep9;
    let s10 = isStep10;

    if (s10) {
      s9 = s8 = s7 = s6 = s5 = s4 = s3 = s2 = s1 = true;
    } else if (s9) {
      s8 = s7 = s6 = s5 = s4 = s3 = s2 = s1 = true;
    } else if (s7 || s6) {
      s5 = s4 = s3 = s2 = s1 = true;
    } else if (s4) {
      s3 = s2 = s1 = true;
    } else if (s3) {
      s2 = s1 = true;
    } else if (s2) {
      s1 = true;
    }

    if (s10) return 100;
    if (s9) return 90;
    if (s8) return 80;
    if (s7) return 70;
    if (s6) return 60;
    if (s5) return 50;
    if (s4) return 40;
    if (s3) return 30;
    if (s2) return 20;
    if (s1) return 10;
    return 0;
  };

  const getProgressColor = (pct) => {
    if (pct <= 10) return "#3b82f6"; // Blue
    if (pct <= 30) return "#a855f7"; // Purple
    if (pct <= 50) return "#ec4899"; // Pink
    if (pct <= 80) return "#f97316"; // Orange
    return "#22c55e"; // Green
  };

  const isCompleted = (request) =>
    request.verificationStatus === "approved" || request.status === "completed";

  const stats = {
    total: requests.length,
    pending: requests.filter((r) => r.status === "pending").length,
    inProgress: requests.filter(
      (r) => r.status === "in-progress" && !isCompleted(r),
    ).length,
    completed: requests.filter(isCompleted).length,
  };

  return (
    <section className="mx-auto flex w-full max-w-[1240px] flex-col gap-6">
      {/* Hero */}
      <div className={`${cardCls} px-10 py-9 md:px-6 md:py-6`}>
        <span className="text-[0.78rem] font-extrabold uppercase tracking-[0.14em] text-[#7b3ff2]">
          My Requests
        </span>
        <h1 className="mt-2 text-[clamp(2.2rem,4vw,3.6rem)] font-black leading-[1.05] text-[#111827]">
          My Requests
        </h1>
        <p className="mt-3 max-w-[680px] leading-[1.7] text-slate-600">
          View, edit and monitor all your submitted service requests.
        </p>
      </div>

      {requests.length === 0 ? (
        /* Empty state */
        <div
          className={`${cardCls} flex flex-col items-center px-10 py-16 text-center`}
        >
          <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-violet-100 text-3xl">
            📋
          </div>
          <h3 className="mb-2 text-2xl font-black text-[#111827]">
            No Requests Yet
          </h3>
          <p className="mb-5 max-w-[420px] text-slate-600">
            Your submitted service requests will appear here.
          </p>
          <button
            type="button"
            onClick={() => navigate("/request-service")}
            className="inline-flex min-h-[52px] items-center justify-center rounded-2xl bg-gradient-to-r from-[#7b3ff2] via-[#ff5ca8] to-[#ff9b54] px-7 font-extrabold text-white shadow-[0_16px_32px_rgba(255,92,168,0.25)] transition hover:-translate-y-0.5 hover:shadow-[0_20px_40px_rgba(255,92,168,0.35)]"
          >
            Create First Request
          </button>
        </div>
      ) : (
        <>
          {/* Stats strip */}
          <div className="flex flex-col gap-4 sm:flex-row">
            <StatChip
              label="Total Active"
              value={stats.total}
              color="#7b3ff2"
            />
            <StatChip label="Pending" value={stats.pending} color="#f59e0b" />
            <StatChip
              label="In Progress"
              value={stats.inProgress}
              color="#a855f7"
            />
            <StatChip
              label="Completed"
              value={stats.completed}
              color="#22c55e"
            />
          </div>

          {/* Request grid */}
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2 xl:grid-cols-3">
            {requests.map((request) => {
              const latestLog = [...(request.auditLogs || [])].slice(-1)[0];
              const progress = getRequestProgressPercentage(request);
              const displayStatus = isCompleted(request)
                ? "completed"
                : request.status;

              return (
                <article
                  key={request._id}
                  className={`${cardCls} flex flex-col gap-4 rounded-[24px] p-6`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <StatusBadge status={displayStatus} />
                    {request.priority && (
                      <PriorityChip priority={request.priority} />
                    )}
                  </div>

                  <div>
                    <h3 className="text-lg font-extrabold leading-snug text-[#111827]">
                      {formatLabel(request.serviceType)}
                    </h3>
                    {request.description && (
                      <p className="mt-1 line-clamp-2 text-sm leading-relaxed text-slate-500">
                        {request.description}
                      </p>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-2.5">
                    <div className="min-w-0 rounded-xl border border-slate-100 bg-white/70 px-3 py-2">
                      <span className="block text-[0.68rem] font-bold uppercase tracking-wide text-slate-400">
                        Preferred
                      </span>
                      <strong className="block truncate text-sm font-extrabold text-[#111827]">
                        {formatDate(request.preferredDate)}
                      </strong>
                    </div>
                    <div className="min-w-0 rounded-xl border border-slate-100 bg-white/70 px-3 py-2">
                      <span className="block text-[0.68rem] font-bold uppercase tracking-wide text-slate-400">
                        Staff
                      </span>
                      <strong className="block truncate text-sm font-extrabold text-[#111827]">
                        {request.assignedTo || "Awaiting"}
                      </strong>
                    </div>
                    <div className="col-span-2 min-w-0 rounded-xl border border-slate-100 bg-white/70 px-3 py-2">
                      <span className="block text-[0.68rem] font-bold uppercase tracking-wide text-slate-400">
                        Vendor
                      </span>
                      <strong className="block truncate text-sm font-extrabold text-[#111827]">
                        {request.assignedVendor || "Pending"}
                      </strong>
                    </div>
                  </div>

                  <div>
                    <div className="mb-1.5 flex items-center justify-between">
                      <span className="text-xs font-bold uppercase tracking-wide text-slate-400">
                        Progress
                      </span>
                      <strong className="text-sm font-extrabold text-[#111827]">
                        {progress}%
                      </strong>
                    </div>
                    <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-100">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${progress}%`,
                          background: getProgressColor(progress),
                        }}
                      />
                    </div>
                  </div>

                  <div className="rounded-2xl border border-slate-100 bg-white/50 px-4 py-3">
                    <p className="mb-1 text-xs font-bold uppercase tracking-wide text-slate-400">
                      Latest Update
                    </p>
                    {!latestLog ? (
                      <p className="text-sm text-slate-400">No updates yet</p>
                    ) : (
                      <div className="flex items-start gap-2.5">
                        <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-[#7b3ff2]" />
                        <div className="min-w-0">
                          <p className="truncate text-sm font-semibold text-[#111827]">
                            {latestLog.action}
                          </p>
                          <p className="text-xs text-slate-400">
                            {new Date(latestLog.createdAt).toLocaleString(
                              "en-IN",
                            )}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="mt-auto flex flex-wrap items-center justify-between gap-2.5 border-t border-slate-100 pt-4">
                    <div className="flex flex-wrap items-center gap-2.5">
                      <GhostButton
                        onClick={() => navigate(`/tracking?id=${request._id}`)}
                      >
                        Track
                      </GhostButton>

                      {canModify(request) && (
                        <GhostButton onClick={() => handleEditRequest(request)}>
                          Edit
                        </GhostButton>
                      )}

                      {request.jobPhotos?.length > 0 && (
                        <GhostButton
                          onClick={() => {
                            setPhotos(request.jobPhotos);
                            setOpenModal(true);
                          }}
                        >
                          Photos
                        </GhostButton>
                      )}
                    </div>

                    {canModify(request) && (
                      <button
                        type="button"
                        disabled={cancellingId === request._id}
                        onClick={() => handleCancelRequest(request._id)}
                        className="inline-flex min-h-[42px] items-center justify-center rounded-2xl bg-gradient-to-r from-[#ef4444] to-[#f97316] px-4 font-extrabold text-white shadow-[0_12px_24px_rgba(239,68,68,0.18)] transition hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:translate-y-0"
                      >
                        {cancellingId === request._id
                          ? "Cancelling…"
                          : "Cancel Service"}
                      </button>
                    )}
                  </div>
                </article>
              );
            })}
          </div>
        </>
      )}

      <EvidenceViewerModal
        open={openModal}
        photos={photos}
        onClose={() => setOpenModal(false)}
      />
    </section>
  );
}

export default ServicesPortal;

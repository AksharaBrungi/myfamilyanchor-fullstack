import { useEffect, useMemo, useState, useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import API from "@api/axios";
import { PLAN_SERVICES } from "../data/planServices";

const MONTHS = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];
const DAYS = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];

const PRIORITIES = [
  {
    value: "low",
    label: "Low",
    hint: "No rush, anytime this month",
    color: "#0ea5e9",
  },
  {
    value: "normal",
    label: "Normal",
    hint: "Within the usual timeframe",
    color: "#7b3ff2",
  },
  {
    value: "high",
    label: "High",
    hint: "Needs attention soon",
    color: "#f97316",
  },
  {
    value: "emergency",
    label: "Emergency",
    hint: "Needs care right away",
    color: "#ef4444",
  },
];

const LIFECYCLE_STAGES = [
  {
    key: "submitted",
    label: "Request submitted",
    desc: "We've received your request.",
  },
  {
    key: "staff",
    label: "Staff assigned",
    desc: "A care coordinator is on it.",
  },
  {
    key: "vendor",
    label: "Vendor assigned",
    desc: "A trusted vendor is matched to the job.",
  },
  {
    key: "progress",
    label: "Service in progress",
    desc: "Before-photos are uploaded and work begins.",
  },
  {
    key: "done",
    label: "Completed & verified",
    desc: "Job is done and verified by our team.",
  },
];

const fieldCls =
  "w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3.5 text-[0.95rem] text-slate-800 placeholder:text-slate-400 transition focus:border-[#7b3ff2]/50 focus:outline-none focus:ring-4 focus:ring-[#7b3ff2]/10 disabled:cursor-not-allowed disabled:bg-slate-50 disabled:text-slate-400";

const cardCls =
  "rounded-[28px] border border-white/80 bg-white/70 shadow-[0_24px_70px_rgba(123,63,242,0.13)] backdrop-blur-xl";

function formatLabel(value = "") {
  return value
    .toString()
    .replace(/[-_]+/g, " ")
    .trim()
    .replace(/\s+/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

function hasBeforePhoto(request) {
  return (request?.jobPhotos || []).some((p) => p.photoType === "before");
}

function getLifecycleStage(request) {
  if (!request) return 0;
  const isDone =
    request.verificationStatus === "approved" || request.status === "completed";
  if (isDone) return 4;
  if (hasBeforePhoto(request)) return 3;
  if (request.assignedVendor || request.assignedVendorId) return 2;
  if (
    request.assignedTo ||
    request.assignedStaffId ||
    request.status !== "pending"
  )
    return 1;
  return 0;
}

function Field({ label, required, hint, children }) {
  return (
    <label className="flex flex-col gap-2">
      <span className="flex items-center gap-1 text-xs font-bold uppercase tracking-[0.06em] text-slate-500">
        {label}
        {required && <span className="text-[#ff5ca8]">*</span>}
      </span>
      {children}
      {hint && (
        <span className="text-xs leading-relaxed text-slate-400">{hint}</span>
      )}
    </label>
  );
}

function LifecycleTracker({ activeIndex, isNew }) {
  return (
    <div className={`${cardCls} p-7`}>
      <span className="text-xs font-bold uppercase tracking-[0.08em] text-slate-500">
        {isNew ? "What happens next" : "Request status"}
      </span>

      <div className="mt-5 flex flex-col">
        {LIFECYCLE_STAGES.map((stage, i) => {
          const done = !isNew && i < activeIndex;
          const current = !isNew && i === activeIndex;
          const last = i === LIFECYCLE_STAGES.length - 1;

          return (
            <div key={stage.key} className="flex gap-3">
              <div className="flex flex-col items-center">
                <span
                  className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-[0.7rem] font-bold ${
                    done
                      ? "bg-gradient-to-br from-[#7b3ff2] to-[#ff5ca8] text-white"
                      : current
                        ? "border-2 border-[#7b3ff2] bg-white text-[#7b3ff2]"
                        : "bg-slate-100 text-slate-400"
                  }`}
                >
                  {done ? "✓" : i + 1}
                </span>
                {!last && (
                  <span
                    className={`mt-1 w-px flex-1 ${
                      done ? "bg-[#7b3ff2]/40" : "bg-slate-200"
                    }`}
                    style={{ minHeight: 26 }}
                  />
                )}
              </div>

              <div className={last ? "pb-0" : "pb-6"}>
                <p
                  className={`text-sm font-bold ${
                    current ? "text-[#7b3ff2]" : "text-[#111827]"
                  }`}
                >
                  {stage.label}
                </p>
                <p className="mt-0.5 text-xs leading-relaxed text-slate-500">
                  {stage.desc}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function DatePicker({ value, onChange }) {
  const now = new Date();
  const tY = now.getFullYear(),
    tM = now.getMonth(),
    tD = now.getDate();
  const [open, setOpen] = useState(false);
  const [yearDrop, setYearDrop] = useState(false);
  const wrap = useRef(null);
  const yearRef = useRef(null);
  const initialDate = useMemo(() => {
    if (!value) return null;

    const [y, m, d] = value.split("-").map(Number);

    return {
      y,
      m: m - 1,
      d,
    };
  }, [value]);

  const [confirmed, setConfirmed] = useState(initialDate);
  const [vY, setVY] = useState(initialDate?.y ?? tY);
  const [vM, setVM] = useState(initialDate?.m ?? tM);

  useEffect(() => {
    const h = (e) => {
      if (wrap.current && !wrap.current.contains(e.target)) {
        setOpen(false);
        setYearDrop(false);
      }
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);

  useEffect(() => {
    if (yearDrop && yearRef.current) {
      const a = yearRef.current.querySelector("[data-active=true]");
      if (a) a.scrollIntoView({ block: "center" });
    }
  }, [yearDrop]);

  const goMonth = (dir) => {
    let m = vM + dir,
      y = vY;
    if (m > 11) {
      m = 0;
      y++;
    }
    if (m < 0) {
      m = 11;
      y--;
    }
    if (y < tY || (y === tY && m < tM)) return;
    setVM(m);
    setVY(y);
  };

  const canBack = vY > tY || (vY === tY && vM > tM);

  const handleDateClick = (e, d) => {
    e.preventDefault();
    e.stopPropagation();

    const selected = {
      y: vY,
      m: vM,
      d,
    };

    setConfirmed(selected);

    onChange(
      `${selected.y}-${String(selected.m + 1).padStart(2, "0")}-${String(selected.d).padStart(2, "0")}`,
    );

    setOpen(false);
  };

  const renderGrid = () => {
    const first = new Date(vY, vM, 1).getDay();
    const total = new Date(vY, vM + 1, 0).getDate();
    const cells = [];
    for (let i = 0; i < first; i++) cells.push(<div key={`e${i}`} />);
    for (let d = 1; d <= total; d++) {
      const past =
        vY < tY || (vY === tY && vM < tM) || (vY === tY && vM === tM && d < tD);
      const isToday = vY === tY && vM === tM && d === tD;
      const isConf =
        confirmed?.y === vY && confirmed?.m === vM && confirmed?.d === d;
      const dd = d;
      cells.push(
        <div
          key={d}
          onMouseDown={past ? undefined : (e) => handleDateClick(e, dd)}
          style={{
            height: 32,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            borderRadius: 8,
            fontSize: 13,
            cursor: past ? "default" : "pointer",
            fontWeight: isConf ? 700 : 400,
            background: isConf
              ? "linear-gradient(135deg,#7b3ff2,#ff5ca8)"
              : isToday
                ? "#f3e8ff"
                : "transparent",
            color: isConf
              ? "#fff"
              : past
                ? "#d1d5db"
                : isToday
                  ? "#7c3aed"
                  : "#374151",
            userSelect: "none",
          }}
          onMouseEnter={(e) => {
            if (!past && !isConf) e.currentTarget.style.background = "#f3e8ff";
          }}
          onMouseLeave={(e) => {
            if (!past && !isConf)
              e.currentTarget.style.background = isToday
                ? "#f3e8ff"
                : "transparent";
          }}
        >
          {d}
        </div>,
      );
    }
    return cells;
  };

  const displayText = confirmed
    ? new Date(confirmed.y, confirmed.m, confirmed.d).toLocaleDateString(
        "en-IN",
        {
          weekday: "short",
          day: "numeric",
          month: "short",
          year: "numeric",
        },
      )
    : "Select a date";

  const years = Array.from({ length: 100 }, (_, i) => tY + i);

  return (
    <div ref={wrap} style={{ position: "relative", width: "100%" }}>
      <div
        onMouseDown={(e) => {
          e.preventDefault();
          e.stopPropagation();
          setOpen((o) => !o);
          setYearDrop(false);
        }}
        style={{
          width: "100%",
          height: 54,
          padding: "0 16px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          border: open ? "1px solid rgba(123,63,242,0.5)" : "1px solid #e2e8f0",
          borderRadius: 16,
          background: "rgba(255,255,255,0.8)",
          cursor: "pointer",
          boxSizing: "border-box",
          boxShadow: open ? "0 0 0 4px rgba(123,63,242,0.1)" : "none",
          transition: "all 0.15s ease",
        }}
      >
        <span
          style={{ fontSize: 15, color: confirmed ? "#1e293b" : "#94a3b8" }}
        >
          {displayText}
        </span>
        <svg
          width="16"
          height="16"
          viewBox="0 0 24 24"
          fill="none"
          stroke="#7b3ff2"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <rect x="3" y="4" width="18" height="18" rx="2" />
          <line x1="16" y1="2" x2="16" y2="6" />
          <line x1="8" y1="2" x2="8" y2="6" />
          <line x1="3" y1="10" x2="21" y2="10" />
        </svg>
      </div>

      {open && (
        <div
          onMouseDown={(e) => e.stopPropagation()}
          style={{
            position: "absolute",
            top: 60,
            left: 0,
            zIndex: 9999,
            background: "#fff",
            borderRadius: 14,
            border: "1px solid #e9d5ff",
            boxShadow: "0 12px 32px rgba(123,63,242,0.18)",
            padding: "12px 10px 10px",
            width: 250,
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              marginBottom: 8,
            }}
          >
            <span
              onMouseDown={(e) => {
                e.preventDefault();
                e.stopPropagation();
                goMonth(-1);
              }}
              style={{
                width: 28,
                height: 28,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: 20,
                cursor: canBack ? "pointer" : "default",
                color: canBack ? "#7c3aed" : "#d1d5db",
                userSelect: "none",
                lineHeight: 1,
              }}
            >
              ‹
            </span>

            <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
              <span style={{ fontSize: 13, fontWeight: 600, color: "#1f2937" }}>
                {MONTHS[vM]}
              </span>
              <div style={{ position: "relative" }}>
                <span
                  onMouseDown={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    setYearDrop((y) => !y);
                  }}
                  style={{
                    background: "#f3e8ff",
                    borderRadius: 6,
                    padding: "2px 7px",
                    fontSize: 12,
                    fontWeight: 600,
                    color: "#7c3aed",
                    cursor: "pointer",
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 3,
                    userSelect: "none",
                  }}
                >
                  {vY} <span style={{ fontSize: 8 }}>▾</span>
                </span>
                {yearDrop && (
                  <div
                    ref={yearRef}
                    style={{
                      position: "absolute",
                      top: 26,
                      left: 0,
                      background: "#fff",
                      border: "1px solid #e9d5ff",
                      borderRadius: 8,
                      zIndex: 10,
                      maxHeight: 140,
                      overflowY: "auto",
                      minWidth: 64,
                      boxShadow: "0 4px 14px rgba(139,92,246,0.12)",
                    }}
                  >
                    {years.map((y) => (
                      <div
                        key={y}
                        data-active={y === vY}
                        onMouseDown={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          let nm = vM;
                          if (y === tY && nm < tM) nm = tM;
                          setVY(y);
                          setVM(nm);
                          setYearDrop(false);
                        }}
                        style={{
                          padding: "4px 10px",
                          fontSize: 12,
                          cursor: "pointer",
                          background: y === vY ? "#7c3aed" : "#fff",
                          color: y === vY ? "#fff" : "#374151",
                          fontWeight: y === vY ? 600 : 400,
                        }}
                      >
                        {y}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <span
              onMouseDown={(e) => {
                e.preventDefault();
                e.stopPropagation();
                goMonth(1);
              }}
              style={{
                width: 28,
                height: 28,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: 20,
                cursor: "pointer",
                color: "#7c3aed",
                userSelect: "none",
                lineHeight: 1,
              }}
            >
              ›
            </span>
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(7,1fr)",
              marginBottom: 4,
            }}
          >
            {DAYS.map((d) => (
              <div
                key={d}
                style={{
                  textAlign: "center",
                  fontSize: 10,
                  fontWeight: 600,
                  color: "#a78bfa",
                  padding: "2px 0",
                }}
              >
                {d}
              </div>
            ))}
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(7,1fr)",
              gap: 2,
            }}
          >
            {renderGrid()}
          </div>
        </div>
      )}
    </div>
  );
}

function RequestService() {
  const location = useLocation();
  const navigate = useNavigate();
  const editRequest = location.state?.editRequest;
  const isEditing = Boolean(editRequest?._id);
  const [dashboard, setDashboard] = useState(null);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    category: "",
    serviceType: "",
    description: "",
    address: "",
    preferredDate: "",
    priority: "normal",
  });

  useEffect(() => {
    if (!editRequest) return;
    setFormData({
      category: editRequest.category || "",
      serviceType: editRequest.serviceType || "",
      description: editRequest.description || "",
      address: editRequest.address || "",
      preferredDate: editRequest.preferredDate
        ? new Date(editRequest.preferredDate).toISOString().slice(0, 10)
        : "",
      priority: editRequest.priority || "normal",
    });
  }, [editRequest]);

  useEffect(() => {
    const fetchDashboard = async () => {
      try {
        const { data } = await API.get("/user/dashboard");
        setDashboard(data);
      } catch (error) {
        console.log(error);
      }
    };
    fetchDashboard();
  }, []);

  const currentPlan = dashboard?.user?.currentPlan;

  const availableCategories = useMemo(() => {
    if (!currentPlan) return {};
    return PLAN_SERVICES[currentPlan]?.categories || {};
  }, [currentPlan]);

  const availableServices = useMemo(() => {
    if (!formData.category) return [];
    return availableCategories[formData.category] || [];
  }, [availableCategories, formData.category]);

  // A request locks for editing once it leaves the pending/in-progress
  // window or the vendor has uploaded before-photos — work has started
  // and the record needs to stay accurate from that point on.
  const isLocked =
    isEditing &&
    (!["pending", "in-progress"].includes(editRequest.status) ||
      hasBeforePhoto(editRequest));

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setLoading(true);
      if (isEditing) {
        await API.put(`/services/edit-service/${editRequest._id}`, formData);
        toast.success("Service request updated successfully");
        navigate("/services-portal");
        return;
      }
      await API.post("/services/create", formData);
      toast.success("Service request submitted successfully");
      setFormData({
        category: "",
        serviceType: "",
        description: "",
        address: "",
        preferredDate: "",
        priority: "normal",
      });
    } catch (error) {
      toast.error(error.response?.data?.message || "Request failed");
    } finally {
      setLoading(false);
    }
  };

  if (!dashboard) {
    return (
      <section className="mx-auto flex w-full max-w-[1240px] flex-col gap-5">
        <div
          className={`${cardCls} flex min-h-[200px] items-center justify-center gap-3 px-10 py-9`}
        >
          <span className="h-5 w-5 animate-spin rounded-full border-2 border-[#7b3ff2]/30 border-t-[#7b3ff2]" />
          <span className="font-semibold text-slate-500">
            Loading your plan…
          </span>
        </div>
      </section>
    );
  }

  if (!currentPlan) {
    return (
      <section className="mx-auto flex w-full max-w-[1240px] flex-col gap-5">
        <div
          className={`${cardCls} flex flex-col items-center gap-3 px-10 py-16 text-center`}
        >
          <h3 className="text-2xl font-black text-[#111827]">No active plan</h3>
          <p className="max-w-[420px] text-slate-600">
            You'll need an active subscription plan before requesting services.
          </p>
        </div>
      </section>
    );
  }

  if (isLocked) {
    const lockedByPhotos = hasBeforePhoto(editRequest);
    return (
      <section className="mx-auto flex w-full max-w-[1240px] flex-col gap-5">
        <div
          className={`${cardCls} flex flex-col items-center gap-4 px-10 py-16 text-center md:px-6`}
        >
          <div className="flex h-14 w-14 items-center justify-center rounded-full bg-amber-100 text-2xl">
            🔒
          </div>
          <h2 className="text-2xl font-black text-[#111827]">
            This request can no longer be edited
          </h2>
          <p className="max-w-[460px] leading-relaxed text-slate-600">
            {lockedByPhotos
              ? "The vendor has already uploaded before-photos for this job. Editing locks at that point to keep the work record accurate."
              : "This request has moved past the pending stage, so its details are locked. You can still track its progress or reach out to support."}
          </p>
          <div className="mt-2 flex flex-wrap justify-center gap-3">
            <button
              type="button"
              onClick={() => navigate(`/tracking?id=${editRequest._id}`)}
              className="rounded-2xl bg-[rgba(123,63,242,0.12)] px-6 py-3 font-extrabold text-[#6d3dea] transition hover:-translate-y-0.5"
            >
              Track this request
            </button>
            <button
              type="button"
              onClick={() => navigate("/services-portal")}
              className="rounded-2xl bg-gradient-to-r from-[#7b3ff2] via-[#ff5ca8] to-[#ff9b54] px-6 py-3 font-extrabold text-white shadow-[0_20px_42px_rgba(255,92,168,0.28)] transition hover:-translate-y-0.5"
            >
              Back to My Requests
            </button>
          </div>
        </div>
      </section>
    );
  }

  const stageIndex = isEditing ? getLifecycleStage(editRequest) : 0;

  return (
    <section className="mx-auto flex w-full max-w-[1240px] flex-col gap-6">
      {/* Hero */}
      <div className={`${cardCls} rounded-[28px] px-10 py-9 md:px-6 md:py-6`}>
        <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
          <div>
            <span className="text-[0.78rem] font-extrabold uppercase tracking-[0.14em] text-[#7b3ff2]">
              Service Support
            </span>
            <h1 className="mt-2 text-[clamp(2.2rem,4vw,3.6rem)] font-black leading-[1.05] text-[#111827]">
              {isEditing ? "Edit Service Request" : "Request a Service"}
            </h1>
            <p className="mt-3 max-w-[640px] leading-[1.7] text-slate-600">
              {isEditing
                ? "Update your request details below — changes save instantly to your active request."
                : "Tell us what you need. A care coordinator will review it and match the right vendor for your plan."}
            </p>
          </div>

          {isEditing && (
            <div className="flex flex-col items-start gap-2 md:items-end">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-violet-100 px-3 py-1 text-xs font-bold text-violet-700">
                Editing existing request
              </span>
              <button
                type="button"
                onClick={() => navigate("/services-portal")}
                className="text-sm font-bold text-[#7b3ff2] hover:underline"
              >
                ← Back to My Requests
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Body */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[1fr_340px]">
        <div className={`${cardCls} p-9 md:p-6`}>
          <div className="mb-7 flex items-center justify-between rounded-2xl bg-gradient-to-r from-[#7b3ff2]/[0.08] to-[#ff6b6b]/[0.08] p-5">
            <div>
              <span className="text-xs font-bold uppercase tracking-[0.08em] text-slate-500">
                Active Plan
              </span>
              <h3 className="mt-1 text-xl font-extrabold text-[#111827]">
                {currentPlan}
              </h3>
            </div>
            <span className="rounded-full bg-green-100 px-3 py-1 text-sm font-bold text-green-700">
              Active
            </span>
          </div>

          <form onSubmit={handleSubmit} className="flex flex-col gap-8">
            <div className="flex flex-col gap-5">
              <h2 className="text-sm font-extrabold uppercase tracking-[0.08em] text-slate-400">
                What do you need help with?
              </h2>

              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                <Field
                  label="Category"
                  required
                  hint={isEditing ? "Locked after submission" : undefined}
                >
                  <select
                    value={formData.category}
                    disabled={isEditing}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        category: e.target.value,
                        serviceType: "",
                      })
                    }
                    required
                    className={fieldCls}
                  >
                    <option value="">Select a category</option>
                    {Object.keys(availableCategories).map((category) => (
                      <option key={category} value={category}>
                        {formatLabel(category)}
                      </option>
                    ))}
                  </select>
                </Field>

                <Field label="Service type" required>
                  <select
                    value={formData.serviceType}
                    onChange={(e) =>
                      setFormData({ ...formData, serviceType: e.target.value })
                    }
                    required
                    disabled={!formData.category}
                    className={fieldCls}
                  >
                    <option value="">
                      {formData.category
                        ? "Select a service"
                        : "Choose a category first"}
                    </option>
                    {availableServices.map((service) => (
                      <option key={service} value={service}>
                        {formatLabel(service)}
                      </option>
                    ))}
                  </select>
                </Field>
              </div>

              <Field
                label="Describe your request"
                required
                hint="The more detail you share, the faster we can match the right vendor."
              >
                <textarea
                  placeholder="e.g. Deep clean for a 3BHK, including kitchen and balconies"
                  value={formData.description}
                  onChange={(e) =>
                    setFormData({ ...formData, description: e.target.value })
                  }
                  required
                  rows={4}
                  className={`${fieldCls} resize-y`}
                />
              </Field>
            </div>

            <div className="flex flex-col gap-5">
              <h2 className="text-sm font-extrabold uppercase tracking-[0.08em] text-slate-400">
                When &amp; where
              </h2>

              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                <Field label="Service address" required>
                  <input
                    type="text"
                    placeholder="House / Street / Area / City"
                    value={formData.address}
                    onChange={(e) =>
                      setFormData({ ...formData, address: e.target.value })
                    }
                    required
                    className={fieldCls}
                  />
                </Field>

                <Field label="Preferred date" required>
                  <DatePicker
                    value={formData.preferredDate}
                    onChange={(val) =>
                      setFormData({ ...formData, preferredDate: val })
                    }
                  />
                </Field>
              </div>
            </div>

            <div className="flex flex-col gap-5">
              <h2 className="text-sm font-extrabold uppercase tracking-[0.08em] text-slate-400">
                Priority
              </h2>

              <div
                role="group"
                aria-label="Priority"
                className="grid grid-cols-2 gap-3 sm:grid-cols-4"
              >
                {PRIORITIES.map((p) => {
                  const active = formData.priority === p.value;
                  return (
                    <button
                      key={p.value}
                      type="button"
                      aria-pressed={active}
                      onClick={() =>
                        setFormData({ ...formData, priority: p.value })
                      }
                      className={`flex flex-col items-start gap-1 rounded-2xl border p-4 text-left transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#7b3ff2] ${
                        active
                          ? "border-transparent text-white shadow-lg"
                          : "border-slate-200 bg-white/70 text-slate-700 hover:border-slate-300"
                      }`}
                      style={
                        active
                          ? {
                              background: p.color,
                              boxShadow: `0 12px 24px ${p.color}40`,
                            }
                          : undefined
                      }
                    >
                      <span className="text-sm font-extrabold">{p.label}</span>
                      <span
                        className={`text-[0.72rem] leading-snug ${
                          active ? "text-white/85" : "text-slate-500"
                        }`}
                      >
                        {p.hint}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="flex flex-col gap-3 border-t border-slate-100 pt-7">
              <button
                type="submit"
                className="inline-flex min-h-[56px] items-center justify-center gap-3 rounded-2xl border border-transparent bg-gradient-to-r from-[#7b3ff2] via-[#ff5ca8] to-[#ff9b54] px-7 font-extrabold text-white shadow-[0_20px_42px_rgba(255,92,168,0.28)] transition hover:-translate-y-0.5 hover:shadow-[0_26px_54px_rgba(123,63,242,0.3)] focus-visible:outline focus-visible:outline-3 focus-visible:outline-offset-4 focus-visible:outline-[rgba(123,63,242,0.4)] disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:translate-y-0"
                disabled={
                  loading ||
                  !formData.category ||
                  !formData.serviceType ||
                  !formData.description.trim() ||
                  !formData.address.trim() ||
                  !formData.preferredDate
                }
              >
                {loading
                  ? isEditing
                    ? "Saving changes…"
                    : "Submitting…"
                  : isEditing
                    ? "Save changes"
                    : "Submit service request"}
              </button>
              <p className="text-center text-xs text-slate-400">
                A care coordinator will review this request and assign a vendor.
              </p>
            </div>
          </form>
        </div>

        {/* Sidebar */}
        <aside className="flex flex-col gap-6">
          <LifecycleTracker activeIndex={stageIndex} isNew={!isEditing} />

          <div className="rounded-[20px] border border-amber-200 bg-amber-50/70 p-5">
            <p className="text-xs font-bold uppercase tracking-wide text-amber-700">
              Good to know
            </p>
            <p className="mt-1.5 text-sm leading-relaxed text-amber-900/80">
              You can edit or cancel this request any time before work begins.
              Once the vendor uploads before-photos, it locks for editing.
            </p>
          </div>
        </aside>
      </div>
    </section>
  );
}

export default RequestService;

import { useEffect, useState, useCallback, useRef } from "react";
import { useNavigate, Link } from "react-router-dom";
import toast from "react-hot-toast";
import API from "@api/axios";
import socket from "@api/socket";
import LoadingPage from "@ui/Loadingpage";

const cardCls =
  "rounded-[28px] border border-white/80 bg-white/70 shadow-[0_24px_70px_rgba(123,63,242,0.13)] backdrop-blur-xl";

const STATUS_THEME = {
  pending: { label: "Pending", bg: "bg-amber-100", text: "text-amber-700" },
  "in-progress": {
    label: "In Progress",
    bg: "bg-violet-100",
    text: "text-violet-700",
  },
  completed: { label: "Completed", bg: "bg-green-100", text: "text-green-700" },
  cancelled: { label: "Cancelled", bg: "bg-slate-100", text: "text-slate-500" },
};

function formatLabel(value = "") {
  return value
    .toString()
    .replace(/[-_]+/g, " ")
    .trim()
    .replace(/\s+/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

function isRequestCompleted(request) {
  return (
    request.verificationStatus === "approved" || request.status === "completed"
  );
}

// Mirrors the lifecycle math used on the Tracking / My Requests pages, so
// progress numbers stay consistent everywhere they're shown.
// function getRequestProgressPercentage(request) {
//   if (!request) return 0;
//   if (request.status === "cancelled") return 0;

//   const hasAuditLog = (pattern) =>
//     (request.auditLogs || []).some(
//       (log) =>
//         log.action && log.action.toLowerCase().includes(pattern.toLowerCase()),
//     );

//   const isRejected = request.verificationStatus === "rejected";

//   const s = {};
//   s[1] =
//     !!request.assignedTo ||
//     !!request.assignedStaffId ||
//     request.status !== "pending" ||
//     hasAuditLog("Assigned to") ||
//     hasAuditLog("Status changed");
//   s[2] =
//     !!request.assignedVendor ||
//     !!request.assignedVendorId ||
//     hasAuditLog("Vendor assigned");
//   s[3] =
//     (request.jobPhotos || []).some((p) => p.photoType === "before") ||
//     hasAuditLog("photos uploaded") ||
//     hasAuditLog("photo uploaded");
//   s[4] = (request.jobPhotos || []).some((p) => p.photoType === "after");
//   s[5] =
//     (request.vendorNotes || []).length > 0 || hasAuditLog("Vendor note added");
//   s[6] =
//     !isRejected &&
//     (["submitted", "staff-approved", "approved"].includes(
//       request.verificationStatus,
//     ) ||
//       hasAuditLog("Completion submitted by vendor"));
//   s[7] =
//     !isRejected &&
//     (["submitted", "staff-approved", "approved"].includes(
//       request.verificationStatus,
//     ) ||
//       hasAuditLog("Waiting for staff verification"));
//   s[8] =
//     !isRejected &&
//     ((request.staffNotes || []).length > 0 || hasAuditLog("Staff note added"));
//   s[9] =
//     !isRejected &&
//     (["staff-approved", "approved"].includes(request.verificationStatus) ||
//       hasAuditLog("Completion verified by staff"));
//   s[10] =
//     !isRejected &&
//     (request.verificationStatus === "approved" ||
//       request.status === "completed" ||
//       hasAuditLog("Completion approved by admin"));

//   if (s[10]) return 100;
//   if (s[9]) return 90;
//   if (s[8]) return 80;
//   if (s[7]) return 70;
//   if (s[6]) return 60;
//   if (s[5]) return 50;
//   if (s[4]) return 40;
//   if (s[3]) return 30;
//   if (s[2]) return 20;
//   if (s[1]) return 10;
//   return 0;
// }

function StatusBadge({ status }) {
  const theme = STATUS_THEME[status] || {
    label: formatLabel(status),
    bg: "bg-slate-100",
    text: "text-slate-500",
  };
  return (
    <span
      className={`rounded-full px-3 py-1 text-xs font-extrabold ${theme.bg} ${theme.text}`}
    >
      {theme.label}
    </span>
  );
}

function StatChip({ label, value, color }) {
  return (
    <div className="flex items-center gap-4 rounded-2xl border border-slate-100 bg-white/60 px-5 py-4">
      <span
        className="h-2.5 w-2.5 shrink-0 rounded-full"
        style={{ background: color, boxShadow: `0 0 0 4px ${color}22` }}
      />
      <div>
        <p className="text-2xl font-black leading-none text-[#111827]">
          {value}
        </p>
        <p className="mt-1 text-xs font-bold uppercase tracking-[0.05em] text-slate-400">
          {label}
        </p>
      </div>
    </div>
  );
}

function QuickAction({ to, title, subtitle, icon }) {
  return (
    <Link
      to={to}
      className={`${cardCls} group flex items-center gap-4 rounded-[22px] p-5 no-underline transition hover:-translate-y-0.5 hover:shadow-[0_28px_60px_rgba(123,63,242,0.18)]`}
    >
      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-[#7b3ff2] to-[#a855f7] text-white shadow-[0_10px_22px_rgba(123,63,242,0.22)]">
        {icon}
      </div>
      <div className="min-w-0 flex-1">
        <p className="font-extrabold text-[#111827]">{title}</p>
        <p className="truncate text-sm text-slate-500">{subtitle}</p>
      </div>
      <svg
        viewBox="0 0 24 24"
        width="18"
        height="18"
        stroke="currentColor"
        strokeWidth="2.5"
        fill="none"
        className="shrink-0 text-slate-300 transition group-hover:translate-x-0.5 group-hover:text-[#7b3ff2]"
      >
        <path d="M9 18l6-6-6-6" />
      </svg>
    </Link>
  );
}

// Mirrors the exact lifecycle math from Tracking.jsx so % stays consistent
function getRequestProgress(request) {
  if (!request) return 0;
  if (request.status === "cancelled") return 0;

  const hasAuditLog = (pattern) =>
    (request.auditLogs || []).some(
      (log) =>
        log.action && log.action.toLowerCase().includes(pattern.toLowerCase()),
    );

  const isRejected = request.verificationStatus === "rejected";

  let s1 =
    !!request.assignedTo ||
    !!request.assignedStaffId ||
    request.status !== "pending" ||
    hasAuditLog("Assigned to") ||
    hasAuditLog("Status changed");
  let s2 =
    !!request.assignedVendor ||
    !!request.assignedVendorId ||
    hasAuditLog("Vendor assigned");
  let s3 =
    (request.jobPhotos || []).some((p) => p.photoType === "before") ||
    hasAuditLog("photos uploaded") ||
    hasAuditLog("photo uploaded");
  let s4 = (request.jobPhotos || []).some((p) => p.photoType === "after");
  let s5 =
    (request.vendorNotes || []).length > 0 || hasAuditLog("Vendor note added");
  let s6 =
    !isRejected &&
    (["submitted", "staff-approved", "approved"].includes(
      request.verificationStatus,
    ) ||
      hasAuditLog("Completion submitted by vendor"));
  let s7 =
    !isRejected &&
    (["submitted", "staff-approved", "approved"].includes(
      request.verificationStatus,
    ) ||
      hasAuditLog("Waiting for staff verification"));
  let s8 =
    !isRejected &&
    ((request.staffNotes || []).length > 0 || hasAuditLog("Staff note added"));
  let s9 =
    !isRejected &&
    (["staff-approved", "approved"].includes(request.verificationStatus) ||
      hasAuditLog("Completion verified by staff"));
  let s10 =
    !isRejected &&
    (request.verificationStatus === "approved" ||
      request.status === "completed" ||
      hasAuditLog("Completion approved by admin"));

  if (s10) return 100;
  if (s9) return 90;
  if (s8) return 80;
  if (s7) return 70;
  if (s6) return 60;
  if (s5) return 50;
  if (s4) return 40;
  if (s3) return 30;
  if (s2) return 20;
  if (s1) return 10;
  return 0;
}

/* ── Mini circular progress ring used on each slider card ── */
function MiniRing({ percent }) {
  const r = 22;
  const c = 2 * Math.PI * r;
  const offset = c - (Math.max(0, Math.min(100, percent)) / 100) * c;
  return (
    <div className="relative h-14 w-14 shrink-0">
      <svg viewBox="0 0 52 52" className="h-full w-full -rotate-90">
        <circle
          cx="26"
          cy="26"
          r={r}
          fill="none"
          stroke="#ede9fe"
          strokeWidth="5"
        />
        <circle
          cx="26"
          cy="26"
          r={r}
          fill="none"
          stroke="url(#dashRingGrad)"
          strokeWidth="5"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={offset}
          style={{ transition: "stroke-dashoffset 0.7s ease" }}
        />
        <defs>
          <linearGradient id="dashRingGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#7b3ff2" />
            <stop offset="55%" stopColor="#ff5ca8" />
            <stop offset="100%" stopColor="#ff9b54" />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute inset-0 flex items-center justify-center text-[11px] font-black text-[#111827]">
        {percent}%
      </div>
    </div>
  );
}

/* ── Swipeable slider for service requests inside the Care Profile card ── */
function RequestSlider({ requests, navigate }) {
  const [idx, setIdx] = useState(0);
  const trackRef = useRef(null);
  const startX = useRef(null);
  const dragging = useRef(false);

  const total = requests.length;
  const go = (n) => setIdx((i) => Math.max(0, Math.min(total - 1, i + n)));

  /* Touch / mouse swipe */
  const onPointerDown = (e) => {
    startX.current = e.touches ? e.touches[0].clientX : e.clientX;
    dragging.current = true;
  };
  const onPointerUp = (e) => {
    if (!dragging.current || startX.current === null) return;
    dragging.current = false;
    const endX = e.changedTouches ? e.changedTouches[0].clientX : e.clientX;
    const diff = startX.current - endX;
    if (Math.abs(diff) > 40) go(diff > 0 ? 1 : -1);
    startX.current = null;
  };

  if (total === 0) {
    return (
      <div className="flex flex-wrap items-center justify-between gap-4 mt-2">
        <p className="text-sm text-slate-500">
          Nothing scheduled right now — submit a request whenever you need a
          hand.
        </p>
        <Link
          to="/request-service"
          className="inline-flex min-h-[40px] items-center justify-center rounded-2xl bg-[rgba(123,63,242,0.10)] px-5 text-sm font-extrabold text-[#6d3dea] no-underline transition hover:-translate-y-0.5"
        >
          Request a Service
        </Link>
      </div>
    );
  }

  const req = requests[idx];
  const progress = getRequestProgress(req);
  const theme = STATUS_THEME[req.status] || {
    label: formatLabel(req.status),
    bg: "bg-slate-100",
    text: "text-slate-500",
  };

  return (
    <div className="select-none">
      {/* Slide track */}
      <div
        ref={trackRef}
        className="cursor-grab active:cursor-grabbing"
        onMouseDown={onPointerDown}
        onMouseUp={onPointerUp}
        onMouseLeave={onPointerUp}
        onTouchStart={onPointerDown}
        onTouchEnd={onPointerUp}
      >
        {/* Card */}
        <div
          className="flex items-center gap-4 rounded-2xl bg-[rgba(123,63,242,0.05)] p-4 transition-all duration-300"
          onClick={() => navigate(`/tracking?id=${req._id}`)}
          style={{ cursor: "pointer" }}
        >
          {/* Progress ring */}
          <MiniRing percent={progress} />

          {/* Info */}
          <div className="min-w-0 flex-1">
            <p className="truncate text-base font-black leading-tight text-[#111827]">
              {formatLabel(req.serviceType)}
            </p>
            <div className="mt-1.5 flex flex-wrap items-center gap-2">
              <span className="text-xs font-semibold text-slate-500">
                {new Date(req.preferredDate).toLocaleDateString("en-IN", {
                  day: "numeric",
                  month: "short",
                  year: "numeric",
                })}
              </span>
              <span
                className={`rounded-full px-2.5 py-0.5 text-[11px] font-extrabold ${theme.bg} ${theme.text}`}
              >
                {theme.label}
              </span>
            </div>
            {/* Mini progress bar */}
            <div className="mt-2.5 h-1.5 w-full overflow-hidden rounded-full bg-violet-100">
              <div
                className="h-full rounded-full transition-all duration-700"
                style={{
                  width: `${progress}%`,
                  background:
                    "linear-gradient(90deg, #7b3ff2, #ff5ca8, #ff9b54)",
                }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Navigation row */}
      {total > 1 && (
        <div className="mt-3 flex items-center justify-between">
          {/* Dot indicators */}
          <div className="flex items-center gap-1.5">
            {requests.map((_, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setIdx(i)}
                aria-label={`Go to request ${i + 1}`}
                className={`h-1.5 rounded-full transition-all duration-300 focus:outline-none ${
                  i === idx
                    ? "w-5 bg-[#7b3ff2]"
                    : "w-1.5 bg-slate-300 hover:bg-slate-400"
                }`}
              />
            ))}
          </div>

          {/* Prev / Next arrows */}
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => go(-1)}
              disabled={idx === 0}
              aria-label="Previous request"
              className="flex h-7 w-7 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-400 transition hover:border-violet-300 hover:text-[#7b3ff2] disabled:opacity-30 focus:outline-none"
            >
              <svg
                viewBox="0 0 24 24"
                width="13"
                height="13"
                stroke="currentColor"
                strokeWidth="2.5"
                fill="none"
              >
                <path d="M15 18l-6-6 6-6" />
              </svg>
            </button>
            <span className="px-1 text-xs font-bold text-slate-400">
              {idx + 1}/{total}
            </span>
            <button
              type="button"
              onClick={() => go(1)}
              disabled={idx === total - 1}
              aria-label="Next request"
              className="flex h-7 w-7 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-400 transition hover:border-violet-300 hover:text-[#7b3ff2] disabled:opacity-30 focus:outline-none"
            >
              <svg
                viewBox="0 0 24 24"
                width="13"
                height="13"
                stroke="currentColor"
                strokeWidth="2.5"
                fill="none"
              >
                <path d="M9 18l6-6-6-6" />
              </svg>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function timeAgo(date) {
  const diffMs = Date.now() - new Date(date).getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return "Just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 7) return `${days}d ago`;
  return new Date(date).toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
  });
}

function Dashboard() {
  const [dashboard, setDashboard] = useState(null);
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const fetchDashboard = useCallback(async () => {
    try {
      const { data } = await API.get("/user/dashboard");
      setDashboard(data);
    } catch (error) {
      console.log(error);
      if (error.response?.status === 403) {
        toast.error("Subscription required to access dashboard");
        navigate("/pricing");
      }
    }
  }, [navigate]);

  const fetchRequests = useCallback(async () => {
    try {
      const { data } = await API.get("/services/my-requests");
      setRequests(data.filter((r) => r.status !== "cancelled"));
    } catch (error) {
      console.log(error);
    }
  }, []);

  const loadDashboard = useCallback(async () => {
    setLoading(true);

    try {
      await Promise.all([fetchDashboard(), fetchRequests()]);
    } finally {
      setLoading(false);
    }
  }, [fetchDashboard, fetchRequests]);

  useEffect(() => {
    loadDashboard();
  }, [loadDashboard]);

  useEffect(() => {
    const handleRealtimeUpdate = () => {
      fetchDashboard();
      fetchRequests();
    };

    socket.on("request-updated", handleRealtimeUpdate);

    return () => {
      socket.off("request-updated", handleRealtimeUpdate);
    };
  }, [fetchDashboard, fetchRequests]);

  if (loading || !dashboard) {
    return (
      <LoadingPage
        title="Loading your dashboard..."
        subtitle="Fetching your care information"
      />
    );
  }

  const { user, payments } = dashboard;
  const totalSpent = payments.reduce((sum, payment) => sum + payment.amount, 0);

  const activeRequests = requests.filter((r) =>
    ["pending", "in-progress"].includes(r.status),
  );
  const completedRequests = requests.filter(isRequestCompleted);

  const isActiveSub = user.subscriptionStatus === "active";

  const recentActivity = requests
    .flatMap((r) =>
      (r.auditLogs || []).map((log) => ({
        ...log,
        serviceType: r.serviceType,
      })),
    )
    .filter((log) => log.createdAt)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 6);

  return (
    <section className="mx-auto flex w-full max-w-[1240px] flex-col gap-6">
      {/* Hero */}
      <div
        className={`${cardCls} flex flex-col gap-6 px-10 py-9 md:flex-row md:items-center md:justify-between md:px-6 md:py-6`}
      >
        <div>
          <span className="text-[0.78rem] font-extrabold uppercase tracking-[0.14em] text-[#7b3ff2]">
            Welcome Back
          </span>
          <h1 className="mt-2 text-[clamp(2.2rem,4vw,3.6rem)] font-black leading-[1.05] text-[#111827]">
            Hello, {user.name}
          </h1>
          <p className="mt-3 max-w-[640px] leading-[1.7] text-slate-600">
            Manage your subscription, payments and family care services from one
            place.
          </p>
        </div>

        <div className="flex shrink-0 flex-col items-start gap-3 md:items-end">
          <span
            className={`rounded-full px-4 py-2 text-sm font-extrabold ${
              isActiveSub
                ? "bg-green-100 text-green-700"
                : "bg-red-100 text-red-600"
            }`}
          >
            {formatLabel(user.subscriptionStatus)}
          </span>
          <span className="text-xs text-slate-400">
            Valid until{" "}
            {user.subscriptionExpiresAt
              ? new Date(user.subscriptionExpiresAt).toLocaleDateString("en-IN")
              : "N/A"}
          </span>
          <Link
            to="/request-service"
            className="inline-flex min-h-[46px] items-center justify-center rounded-2xl bg-gradient-to-r from-[#7b3ff2] via-[#ff5ca8] to-[#ff9b54] px-5 text-sm font-extrabold text-white no-underline shadow-[0_16px_32px_rgba(255,92,168,0.25)] transition hover:-translate-y-0.5 hover:shadow-[0_20px_40px_rgba(255,92,168,0.35)]"
          >
            + Request a Service
          </Link>
        </div>
      </div>

      {/* Care profile */}
      <div className={`${cardCls} p-9 md:p-6`}>
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-[0.06em] text-slate-400">
              Care Profile
            </span>
            <h2 className="mt-1 text-[clamp(1.8rem,3vw,2.6rem)] font-black leading-none text-[#111827]">
              {user.currentPlan || "No Active Plan"}
            </h2>
          </div>
          <span
            className={`rounded-full px-4 py-2 text-sm font-extrabold ${
              isActiveSub
                ? "bg-green-100 text-green-700"
                : "bg-slate-100 text-slate-500"
            }`}
          >
            {isActiveSub ? "Online" : "Inactive"}
          </span>
        </div>

        {/* Service requests slider */}
        <div className="my-6">
          <div className="mb-3 flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-[0.06em] text-slate-400">
              Service Requests
            </span>
            {activeRequests.length > 0 && (
              <Link
                to="/services-portal"
                className="text-xs font-bold text-[#7b3ff2] no-underline hover:underline"
              >
                View all →
              </Link>
            )}
          </div>
          <RequestSlider requests={activeRequests} navigate={navigate} />
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2 lg:grid-cols-4">
          <StatChip
            label="Active Requests"
            value={activeRequests.length}
            color="#7b3ff2"
          />
          <StatChip
            label="Completed"
            value={completedRequests.length}
            color="#22c55e"
          />
          <StatChip
            label="Total Spent"
            value={`₹${totalSpent}`}
            color="#f97316"
          />
          <StatChip
            label="Emergency Support"
            value={isActiveSub ? "24/7" : "—"}
            color="#0ea5e9"
          />
        </div>
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <QuickAction
          to="/request-service"
          title="Request a Service"
          subtitle="Get help from a vendor"
          icon={
            <svg
              viewBox="0 0 24 24"
              width="20"
              height="20"
              stroke="currentColor"
              strokeWidth="2.5"
              fill="none"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <line x1="12" y1="5" x2="12" y2="19" />
              <line x1="5" y1="12" x2="19" y2="12" />
            </svg>
          }
        />
        <QuickAction
          to="/services-portal"
          title="My Requests"
          subtitle={`${requests.length} total request${requests.length === 1 ? "" : "s"}`}
          icon={
            <svg
              viewBox="0 0 24 24"
              width="20"
              height="20"
              stroke="currentColor"
              strokeWidth="2.5"
              fill="none"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
              <polyline points="14 2 14 8 20 8" />
            </svg>
          }
        />
        <QuickAction
          to="/tracking"
          title="Service Tracking"
          subtitle="Live status on active jobs"
          icon={
            <svg
              viewBox="0 0 24 24"
              width="20"
              height="20"
              stroke="currentColor"
              strokeWidth="2.5"
              fill="none"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <circle cx="12" cy="12" r="10" />
              <polyline points="12 6 12 12 16 14" />
            </svg>
          }
        />
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[1fr_360px]">
        {/* Payment history */}
        <div className={`${cardCls} order-2 p-7 lg:order-1`}>
          <h2 className="mb-6 text-lg font-extrabold text-[#111827]">
            Payment History
          </h2>

          {payments.length === 0 ? (
            <p className="text-sm text-slate-500">No payments found.</p>
          ) : (
            <div className="flex flex-col gap-3">
              {payments.map((payment) => (
                <div
                  key={payment._id}
                  className="flex flex-col gap-3 rounded-2xl bg-white/60 px-5 py-4 sm:flex-row sm:items-center sm:justify-between"
                >
                  <div className="min-w-0">
                    <p className="font-extrabold text-[#111827]">
                      {payment.planName}
                    </p>
                    <p className="text-sm text-slate-500">
                      {formatLabel(payment.billingCycle)}
                    </p>
                  </div>
                  <div className="flex items-center justify-between gap-6 sm:justify-end">
                    <div className="text-right">
                      <p className="font-extrabold text-[#111827]">
                        ₹{payment.amount}
                      </p>
                      <p className="text-xs font-bold capitalize text-green-600">
                        {payment.status}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent activity */}
        <div className={`${cardCls} order-1 p-7 lg:order-2`}>
          <h2 className="mb-5 text-lg font-extrabold text-[#111827]">
            Recent Activity
          </h2>

          {recentActivity.length === 0 ? (
            <p className="text-sm text-slate-500">
              Activity from your service requests will show up here.
            </p>
          ) : (
            <div className="flex flex-col gap-5">
              {recentActivity.map((log, i) => (
                <div key={i} className="flex items-start gap-3">
                  <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-[#7b3ff2]" />
                  <div className="min-w-0">
                    <p className="text-sm font-semibold leading-snug text-[#111827]">
                      {log.action}
                    </p>
                    <p className="mt-0.5 text-xs text-slate-400">
                      {formatLabel(log.serviceType)} · {timeAgo(log.createdAt)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

export default Dashboard;

import { useEffect, useState, useCallback } from "react";
import { Link, useSearchParams } from "react-router-dom";
import toast from "react-hot-toast";
import API from "@api/axios";
import socket from "@api/socket";
import LoadingPage from "@ui/Loadingpage";

const cardCls =
  "rounded-[28px] border border-white/80 bg-white/70 shadow-[0_24px_70px_rgba(123,63,242,0.13)] backdrop-blur-xl";

const PRIORITY_THEME = {
  low: { label: "Low", color: "#0ea5e9" },
  normal: { label: "Normal", color: "#7b3ff2" },
  high: { label: "High", color: "#f97316" },
  emergency: { label: "Emergency", color: "#ef4444" },
};

const STATUS_THEME = {
  pending: { label: "Pending", bg: "bg-amber-100", text: "text-amber-700" },
  "in-progress": {
    label: "In Progress",
    bg: "bg-violet-100",
    text: "text-violet-700",
  },
  completed: { label: "Completed", bg: "bg-green-100", text: "text-green-700" },
  cancelled: { label: "Cancelled", bg: "bg-slate-100", text: "text-slate-500" },
};

// Color theme per timeline step, grouped by phase of the request lifecycle.
const STEP_COLORS = [
  "#0ea5e9", // staff
  "#7b3ff2", // vendor
  "#7b3ff2", // before photo
  "#ec4899", // after photo
  "#ec4899", // vendor note
  "#f97316", // submitted
  "#f97316", // waiting verification
  "#f97316", // staff note
  "#16a34a", // verified
  "#16a34a", // approved
];

function formatLabel(value = "") {
  return value
    .toString()
    .replace(/[-_]+/g, " ")
    .trim()
    .replace(/\s+/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

function ProgressRing({ percent }) {
  const r = 30;
  const c = 2 * Math.PI * r;
  const offset = c - (Math.max(0, Math.min(100, percent)) / 100) * c;

  return (
    <div className="relative h-[78px] w-[78px] shrink-0">
      <svg viewBox="0 0 72 72" className="h-full w-full -rotate-90">
        <circle
          cx="36"
          cy="36"
          r={r}
          fill="none"
          stroke="#ede9fe"
          strokeWidth="7"
        />
        <circle
          cx="36"
          cy="36"
          r={r}
          fill="none"
          stroke="url(#trackingProgressGradient)"
          strokeWidth="7"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={offset}
          style={{ transition: "stroke-dashoffset 0.6s ease" }}
        />
        <defs>
          <linearGradient
            id="trackingProgressGradient"
            x1="0%"
            y1="0%"
            x2="100%"
            y2="100%"
          >
            <stop offset="0%" stopColor="#7b3ff2" />
            <stop offset="55%" stopColor="#ff5ca8" />
            <stop offset="100%" stopColor="#ff9b54" />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute inset-0 flex items-center justify-center text-sm font-black text-[#111827]">
        {percent}%
      </div>
    </div>
  );
}

function SummaryRow({ label, value }) {
  return (
    <div className="flex items-center justify-between gap-3 py-3">
      <span className="text-xs font-bold uppercase tracking-[0.05em] text-slate-400">
        {label}
      </span>
      <span className="text-right text-sm font-bold text-[#111827]">
        {value}
      </span>
    </div>
  );
}

function Tracking() {
  const [searchParams, setSearchParams] = useSearchParams();
  const requestIdParam = searchParams.get("id");

  const [requests, setRequests] = useState([]);
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchRequests = useCallback(
    async (selectId = null) => {
      try {
        const { data } = await API.get("/services/my-requests");
        const activeRequests = data.filter((req) => req.status !== "cancelled");
        setRequests(activeRequests);

        if (activeRequests.length > 0) {
          if (selectId) {
            const found = activeRequests.find((r) => r._id === selectId);
            const target = found || activeRequests[0];
            setSelectedRequest(target);
            if (!found) {
              setSearchParams({ id: activeRequests[0]._id }, { replace: true });
            }
          } else if (!selectedRequest) {
            setSelectedRequest(activeRequests[0]);
            setSearchParams({ id: activeRequests[0]._id }, { replace: true });
          } else {
            const updated = activeRequests.find(
              (r) => r._id === selectedRequest._id,
            );
            setSelectedRequest(updated || activeRequests[0]);
          }
        } else {
          setSelectedRequest(null);
        }
      } catch (error) {
        console.error("Error fetching requests for tracking:", error);
        toast.error("Failed to load request tracking details");
      } finally {
        setLoading(false);
      }
    },
    [selectedRequest, setSearchParams],
  );

  useEffect(() => {
    fetchRequests(requestIdParam);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const handleRealtimeUpdate = () => {
      fetchRequests(selectedRequest?._id);
    };

    socket.on("request-updated", handleRealtimeUpdate);

    return () => {
      socket.off("request-updated", handleRealtimeUpdate);
    };
  }, [fetchRequests, selectedRequest]);

  const handleSelectRequest = (e) => {
    const id = e.target.value;
    const found = requests.find((r) => r._id === id);
    setSelectedRequest(found);
    setSearchParams({ id });
  };

  const getHeaderDate = (request) => {
    if (!request) return "";
    const date = request.createdAt || request.preferredDate;
    return new Date(date).toLocaleDateString("en-US", {
      month: "long",
      day: "numeric",
      year: "numeric",
    });
  };

  const getStepStatus = (stepIndex, request) => {
    if (!request) return "upcoming";

    const hasAuditLog = (pattern) => {
      return (request.auditLogs || []).some(
        (log) =>
          log.action &&
          log.action.toLowerCase().includes(pattern.toLowerCase()),
      );
    };

    const isRejected = request.verificationStatus === "rejected";

    // Calculate step statuses exactly as in database logic
    const isStep1 =
      !!request.assignedTo ||
      !!request.assignedStaffId ||
      request.status !== "pending" ||
      hasAuditLog("Assigned to") ||
      hasAuditLog("Status changed");
    const isStep2 =
      !!request.assignedVendor ||
      !!request.assignedVendorId ||
      hasAuditLog("Vendor assigned");
    const isStep3 =
      (request.jobPhotos || []).some((p) => p.photoType === "before") ||
      hasAuditLog("photos uploaded") ||
      hasAuditLog("photo uploaded");
    const isStep4 = (request.jobPhotos || []).some(
      (p) => p.photoType === "after",
    );
    const isStep5 =
      (request.vendorNotes || []).length > 0 ||
      hasAuditLog("Vendor note added");
    const isStep6 =
      !isRejected &&
      (request.verificationStatus === "submitted" ||
        request.verificationStatus === "staff-approved" ||
        request.verificationStatus === "approved" ||
        hasAuditLog("Completion submitted by vendor"));
    const isStep7 =
      !isRejected &&
      (request.verificationStatus === "submitted" ||
        request.verificationStatus === "staff-approved" ||
        request.verificationStatus === "approved" ||
        hasAuditLog("Waiting for staff verification"));
    const isStep8 =
      !isRejected &&
      ((request.staffNotes || []).length > 0 ||
        hasAuditLog("Staff note added"));
    const isStep9 =
      !isRejected &&
      (request.verificationStatus === "staff-approved" ||
        request.verificationStatus === "approved" ||
        hasAuditLog("Completion verified by staff"));
    const isStep10 =
      !isRejected &&
      (request.verificationStatus === "approved" ||
        request.status === "completed" ||
        hasAuditLog("Completion approved by admin"));

    let s1 = isStep1;
    let s2 = isStep2;
    let s3 = isStep3;
    let s4 = isStep4;
    let s5 = isStep5;
    let s6 = isStep6;
    let s7 = isStep7;
    let s8 = isStep8;
    let s9 = isStep9;
    let s10 = isStep10;

    if (s10) {
      s9 = s8 = s7 = s6 = s5 = s4 = s3 = s2 = s1 = true;
    } else if (s9) {
      s8 = s7 = s6 = s5 = s4 = s3 = s2 = s1 = true;
    } else if (s7 || s6) {
      s5 = s4 = s3 = s2 = s1 = true;
    } else if (s4) {
      s3 = s2 = s1 = true;
    } else if (s3) {
      s2 = s1 = true;
    } else if (s2) {
      s1 = true;
    }

    const statuses = [
      s1,
      s1 && s2,
      s1 && s2 && s3,
      s1 && s2 && s3 && s4,
      s1 && s2 && s3 && s4 && s5,
      s1 && s2 && s3 && s4 && s5 && s6,
      s1 && s2 && s3 && s4 && s5 && s6 && s7,
      s1 && s2 && s3 && s4 && s5 && s6 && s7 && s8,
      s1 && s2 && s3 && s4 && s5 && s6 && s7 && s8 && s9,
      s1 && s2 && s3 && s4 && s5 && s6 && s7 && s8 && s9 && s10,
    ];

    if (statuses[stepIndex]) {
      return "completed";
    }

    const firstUncompletedIndex = statuses.indexOf(false);
    if (stepIndex === firstUncompletedIndex) {
      return "active";
    }

    return "upcoming";
  };

  const steps = [
    {
      title: "Assigned to Staff",
      percentage: 10,
      subtext: "A care coordinator is reviewing this request.",
      icon: (
        <svg
          viewBox="0 0 24 24"
          width="20"
          height="20"
          stroke="currentColor"
          strokeWidth="2.5"
          fill="none"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
          <circle cx="12" cy="7" r="4" />
        </svg>
      ),
    },
    {
      title: "Vendor Assigned",
      percentage: 20,
      subtext: "A trusted vendor has been matched to the job.",
      icon: (
        <svg
          viewBox="0 0 24 24"
          width="20"
          height="20"
          stroke="currentColor"
          strokeWidth="2.5"
          fill="none"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
          <polyline points="9 22 9 12 15 12 15 22" />
        </svg>
      ),
    },
    {
      title: "Before Photo Uploaded",
      percentage: 30,
      subtext: "The vendor has documented the starting condition.",
      icon: (
        <svg
          viewBox="0 0 24 24"
          width="20"
          height="20"
          stroke="currentColor"
          strokeWidth="2.5"
          fill="none"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
          <circle cx="8.5" cy="8.5" r="1.5" />
          <polyline points="21 15 16 10 5 21" />
        </svg>
      ),
    },
    {
      title: "After Photo Uploaded",
      percentage: 40,
      subtext: "Work is wrapping up — final photos are in.",
      icon: (
        <svg
          viewBox="0 0 24 24"
          width="20"
          height="20"
          stroke="currentColor"
          strokeWidth="2.5"
          fill="none"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
          <circle cx="8.5" cy="8.5" r="1.5" />
          <polyline points="21 15 16 10 5 21" />
        </svg>
      ),
    },
    {
      title: "Vendor Note Added",
      percentage: 50,
      subtext: "The vendor has shared notes about the job.",
      icon: (
        <svg
          viewBox="0 0 24 24"
          width="20"
          height="20"
          stroke="currentColor"
          strokeWidth="2.5"
          fill="none"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
        </svg>
      ),
    },
    {
      title: "Submitted by Vendor",
      percentage: 60,
      subtext: "The vendor has marked the job as complete.",
      icon: (
        <svg
          viewBox="0 0 24 24"
          width="20"
          height="20"
          stroke="currentColor"
          strokeWidth="2.5"
          fill="none"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <line x1="22" y1="2" x2="11" y2="13" />
          <polygon points="22 2 15 22 11 13 2 9 22 2" />
        </svg>
      ),
    },
    {
      title: "Waiting for Verification",
      percentage: 70,
      subtext: "Our team is reviewing the completed work.",
      icon: (
        <svg
          viewBox="0 0 24 24"
          width="20"
          height="20"
          stroke="currentColor"
          strokeWidth="2.5"
          fill="none"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <circle cx="12" cy="12" r="10" />
          <polyline points="12 6 12 12 16 14" />
        </svg>
      ),
    },
    {
      title: "Staff Note Added",
      percentage: 80,
      subtext: "A staff member has added review notes.",
      icon: (
        <svg
          viewBox="0 0 24 24"
          width="20"
          height="20"
          stroke="currentColor"
          strokeWidth="2.5"
          fill="none"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
          <polyline points="14 2 14 8 20 8" />
          <line x1="16" y1="13" x2="8" y2="13" />
          <line x1="16" y1="17" x2="8" y2="17" />
          <polyline points="10 9 9 9 8 9" />
        </svg>
      ),
    },
    {
      title: "Verified by Staff",
      percentage: 90,
      subtext: "The completed work has been verified.",
      icon: (
        <svg
          viewBox="0 0 24 24"
          width="20"
          height="20"
          stroke="currentColor"
          strokeWidth="2.5"
          fill="none"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
          <polyline points="9 11 11 13 15 9" />
        </svg>
      ),
    },
    {
      title: "Approved by Admin",
      percentage: 100,
      subtext: "Final sign-off — this request is fully closed out.",
      icon: (
        <svg
          viewBox="0 0 24 24"
          width="20"
          height="20"
          stroke="currentColor"
          strokeWidth="2.5"
          fill="none"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M2 4l3 12h14l3-12-6 7-4-7-4 7-6-7z" />
          <path d="M3 20h18v2H3z" />
        </svg>
      ),
    },
  ];

  const isRequestFullyCompleted =
    selectedRequest && getStepStatus(9, selectedRequest) === "completed";

  const completedCount = selectedRequest
    ? steps.filter((_, i) => getStepStatus(i, selectedRequest) === "completed")
        .length
    : 0;
  const activeIndex = selectedRequest
    ? steps.findIndex((_, i) => getStepStatus(i, selectedRequest) === "active")
    : -1;
  const overallPercent = isRequestFullyCompleted
    ? 100
    : completedCount > 0
      ? steps[completedCount - 1].percentage
      : 0;
  const activeStepLabel = isRequestFullyCompleted
    ? "All steps completed"
    : activeIndex >= 0
      ? steps[activeIndex].title
      : "Awaiting next update";

  if (loading) {
    return <LoadingPage />;
  }

  return (
    <section className="mx-auto flex w-full max-w-[1240px] flex-col gap-6 pb-14">
      {/* Hero */}
      <div className={`${cardCls} px-10 py-9 md:px-6 md:py-6`}>
        <span className="text-[0.78rem] font-extrabold uppercase tracking-[0.14em] text-[#7b3ff2]">
          Real-Time Care Support
        </span>
        <h1 className="mt-2 text-[clamp(2.2rem,4vw,3.6rem)] font-black leading-[1.05] text-[#111827]">
          Service Tracking
        </h1>
        <p className="mt-3 max-w-[640px] leading-[1.7] text-slate-600">
          Monitor your active family care and property services in real-time.
        </p>
      </div>

      {requests.length === 0 ? (
        <div
          className={`${cardCls} flex flex-col items-center px-10 py-16 text-center`}
        >
          <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-violet-100 text-3xl">
            🛰️
          </div>
          <h3 className="mb-2 text-2xl font-black text-[#111827]">
            No Active Requests
          </h3>
          <p className="mb-2 max-w-[420px] text-slate-600">
            Submit a service request to start tracking its status in real-time.
          </p>
          <Link
            to="/request-service"
            className="mt-3 inline-flex min-h-[52px] items-center justify-center rounded-2xl bg-gradient-to-r from-[#7b3ff2] via-[#ff5ca8] to-[#ff9b54] px-7 font-extrabold text-white no-underline shadow-[0_16px_32px_rgba(255,92,168,0.25)] transition hover:-translate-y-0.5 hover:shadow-[0_20px_40px_rgba(255,92,168,0.35)]"
          >
            Request a Service
          </Link>
        </div>
      ) : (
        <>
          {/* Request selector */}
          <div className={`${cardCls} px-7 py-6 md:px-5`}>
            <label
              htmlFor="request-select"
              className="mb-2 block text-xs font-bold uppercase tracking-[0.06em] text-slate-500"
            >
              Select request to track
            </label>
            <select
              id="request-select"
              value={selectedRequest?._id || ""}
              onChange={handleSelectRequest}
              className="w-full cursor-pointer rounded-2xl border border-slate-200 bg-white/85 px-4 py-3.5 text-[0.95rem] font-bold text-slate-800 outline-none transition focus:border-[#7b3ff2]/50 focus:ring-4 focus:ring-[#7b3ff2]/10"
            >
              {requests.map((req) => (
                <option key={req._id} value={req._id}>
                  {formatLabel(req.serviceType)} — Preferred:{" "}
                  {new Date(req.preferredDate).toLocaleDateString("en-IN")} (
                  {formatLabel(req.status)})
                </option>
              ))}
            </select>
          </div>

          {selectedRequest && (
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-[1fr_320px]">
              {/* Timeline */}
              <div className={`${cardCls} p-9 md:p-6`}>
                <div className="mb-9 flex flex-wrap items-center justify-between gap-6 border-b border-slate-100 pb-7">
                  <div className="flex items-center gap-4">
                    <div className="flex h-[54px] w-[54px] shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-[#7b3ff2] to-[#a855f7] text-white shadow-[0_10px_24px_rgba(123,63,242,0.22)]">
                      <svg
                        viewBox="0 0 24 24"
                        width="24"
                        height="24"
                        stroke="currentColor"
                        strokeWidth="2.5"
                        fill="none"
                      >
                        <line x1="8" y1="6" x2="21" y2="6" />
                        <line x1="8" y1="12" x2="21" y2="12" />
                        <line x1="8" y1="18" x2="21" y2="18" />
                        <line x1="3" y1="6" x2="3.01" y2="6" strokeWidth="3" />
                        <line
                          x1="3"
                          y1="12"
                          x2="3.01"
                          y2="12"
                          strokeWidth="3"
                        />
                        <line
                          x1="3"
                          y1="18"
                          x2="3.01"
                          y2="18"
                          strokeWidth="3"
                        />
                      </svg>
                    </div>
                    <div>
                      <h2 className="text-[1.6rem] font-black text-[#111827]">
                        Care Tracking
                      </h2>
                      <span className="text-sm font-bold text-slate-500">
                        Started {getHeaderDate(selectedRequest)}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="text-xs font-bold uppercase tracking-[0.06em] text-slate-400">
                        Current stage
                      </p>
                      <p className="text-sm font-extrabold text-[#111827]">
                        {activeStepLabel}
                      </p>
                    </div>
                    <ProgressRing percent={overallPercent} />
                  </div>
                </div>

                {/* Steps */}
                <div className="flex flex-col">
                  {steps.map((step, idx) => {
                    const status = getStepStatus(idx, selectedRequest);
                    const color = STEP_COLORS[idx];
                    const isLast = idx === steps.length - 1;
                    const isCompleted = status === "completed";
                    const isActive = status === "active";

                    return (
                      <div key={idx} className="flex gap-5">
                        {/* Connector */}
                        <div className="flex flex-col items-center">
                          <div
                            className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-xs font-extrabold transition-all ${
                              isCompleted || isActive
                                ? "text-white"
                                : "bg-slate-100 text-slate-400"
                            } ${isActive ? "ring-4 ring-offset-2" : ""}`}
                            style={
                              isCompleted || isActive
                                ? {
                                    background: color,
                                    boxShadow: `0 8px 18px ${color}40`,
                                    ...(isActive
                                      ? { "--tw-ring-color": `${color}40` }
                                      : {}),
                                  }
                                : undefined
                            }
                          >
                            {isCompleted ? (
                              <svg
                                viewBox="0 0 24 24"
                                width="15"
                                height="15"
                                fill="currentColor"
                              >
                                <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" />
                              </svg>
                            ) : (
                              String(idx + 1).padStart(2, "0")
                            )}
                          </div>
                          {!isLast && (
                            <span
                              className="w-px flex-1"
                              style={{
                                minHeight: 24,
                                background: isCompleted ? color : "#e2e8f0",
                                opacity: isCompleted ? 0.4 : 1,
                              }}
                            />
                          )}
                        </div>

                        {/* Card */}
                        <div
                          className={`mb-6 flex flex-1 flex-col items-start gap-4 rounded-[20px] border p-5 transition-all sm:flex-row sm:items-center sm:gap-5 sm:p-6 ${
                            isActive
                              ? "border-[#7b3ff2]/25 bg-white shadow-[0_14px_38px_rgba(123,63,242,0.14)]"
                              : isCompleted
                                ? "border-slate-100 bg-white/70"
                                : "border-transparent bg-slate-50/60"
                          }`}
                        >
                          <div
                            className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${
                              isCompleted || isActive
                                ? "text-white"
                                : "bg-slate-100 text-slate-400"
                            }`}
                            style={
                              isCompleted || isActive
                                ? { background: color }
                                : undefined
                            }
                          >
                            {step.icon}
                          </div>

                          <div className="flex flex-1 flex-col gap-1">
                            <div className="flex flex-wrap items-center gap-2.5">
                              <h3
                                className={`text-[1.05rem] font-extrabold ${
                                  isCompleted || isActive
                                    ? "text-[#111827]"
                                    : "text-slate-400"
                                }`}
                              >
                                {step.title}
                              </h3>
                              {isActive && (
                                <span className="rounded-full bg-[rgba(123,63,242,0.1)] px-2.5 py-1 text-[0.7rem] font-extrabold text-[#7b3ff2]">
                                  In Progress
                                </span>
                              )}
                              {isCompleted && (
                                <span className="rounded-full bg-green-50 px-2.5 py-1 text-[0.7rem] font-extrabold text-green-600">
                                  Done
                                </span>
                              )}
                            </div>
                            {(isActive || isCompleted) && step.subtext && (
                              <p className="text-[0.82rem] leading-relaxed text-slate-500">
                                {step.subtext}
                              </p>
                            )}
                          </div>

                          <div className="flex w-full shrink-0 flex-col gap-2 sm:w-[110px] sm:text-right">
                            <span
                              className={`text-sm font-extrabold ${
                                isCompleted || isActive
                                  ? "text-[#111827]"
                                  : "text-slate-300"
                              }`}
                            >
                              {step.percentage}%
                            </span>
                            <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-100">
                              <div
                                className="h-full rounded-full transition-all duration-500"
                                style={{
                                  width:
                                    isCompleted || isActive
                                      ? `${step.percentage}%`
                                      : "0%",
                                  background: color,
                                }}
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}

                  {/* Final completed banner */}
                  <div
                    className={`flex items-center gap-4 rounded-[20px] p-6 transition-all ${
                      isRequestFullyCompleted
                        ? "bg-gradient-to-r from-[#7b3ff2] via-[#ff5ca8] to-[#ff9b54] text-white shadow-[0_20px_42px_rgba(255,92,168,0.28)]"
                        : "bg-slate-50/60 text-slate-400"
                    }`}
                  >
                    <div
                      className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${
                        isRequestFullyCompleted ? "bg-white/20" : "bg-slate-100"
                      }`}
                    >
                      <svg
                        viewBox="0 0 24 24"
                        width="20"
                        height="20"
                        fill="currentColor"
                      >
                        <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-extrabold">Completed</h3>
                      <p
                        className={`text-sm ${
                          isRequestFullyCompleted
                            ? "text-white/85"
                            : "text-slate-400"
                        }`}
                      >
                        {isRequestFullyCompleted
                          ? "All steps completed successfully."
                          : "Will be marked once every step above is done."}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Sidebar */}
              <aside className="flex flex-col gap-6">
                <div className={`${cardCls} p-7`}>
                  <span className="text-xs font-bold uppercase tracking-[0.08em] text-slate-500">
                    Request details
                  </span>

                  <div className="mt-3 divide-y divide-slate-100">
                    <SummaryRow
                      label="Service"
                      value={formatLabel(selectedRequest.serviceType)}
                    />
                    {selectedRequest.category && (
                      <SummaryRow
                        label="Category"
                        value={formatLabel(selectedRequest.category)}
                      />
                    )}
                    <SummaryRow
                      label="Status"
                      value={
                        <span
                          className={`rounded-full px-2.5 py-1 text-xs font-bold ${
                            STATUS_THEME[selectedRequest.status]?.bg ||
                            "bg-slate-100"
                          } ${STATUS_THEME[selectedRequest.status]?.text || "text-slate-500"}`}
                        >
                          {STATUS_THEME[selectedRequest.status]?.label ||
                            formatLabel(selectedRequest.status)}
                        </span>
                      }
                    />
                    {selectedRequest.priority && (
                      <SummaryRow
                        label="Priority"
                        value={
                          <span
                            className="rounded-full px-2.5 py-1 text-xs font-bold text-white"
                            style={{
                              background:
                                PRIORITY_THEME[selectedRequest.priority]
                                  ?.color || "#7b3ff2",
                            }}
                          >
                            {PRIORITY_THEME[selectedRequest.priority]?.label ||
                              formatLabel(selectedRequest.priority)}
                          </span>
                        }
                      />
                    )}
                    {selectedRequest.preferredDate && (
                      <SummaryRow
                        label="Preferred date"
                        value={new Date(
                          selectedRequest.preferredDate,
                        ).toLocaleDateString("en-IN", {
                          day: "numeric",
                          month: "short",
                          year: "numeric",
                        })}
                      />
                    )}
                    {selectedRequest.address && (
                      <SummaryRow
                        label="Address"
                        value={selectedRequest.address}
                      />
                    )}
                  </div>
                </div>

                <div className="rounded-[20px] border border-violet-100 bg-violet-50/60 p-5">
                  <p className="text-xs font-bold uppercase tracking-wide text-violet-700">
                    Live updates
                  </p>
                  <p className="mt-1.5 text-sm leading-relaxed text-violet-900/70">
                    This page updates automatically as your vendor and care
                    coordinator make progress — no need to refresh.
                  </p>
                </div>
              </aside>
            </div>
          )}
        </>
      )}
    </section>
  );
}

export default Tracking;

import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

function Success() {
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setTimeout(() => {
      navigate("/loading", {
        replace: true,
        state: {
          title: "Preparing your dashboard...",
          subtitle: "Please wait while we set everything up for you",
          redirectTo: "/dashboard",
          duration: 2500,
        },
      });
    }, 4000);

    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <section className="[min-height:80vh] [display:flex] [align-items:center] [justify-content:center] [padding:2rem]">
      <div className="[max-width:700px] [width:100%] [text-align:center] [&_h1]:[font-size:clamp(2rem,_5vw,_3.5rem)] [&_h1]:[margin-bottom:16px]">
        <div className="[width:90px] [height:90px] [margin:0_auto_24px] [border-radius:50%] [background:linear-gradient(_135deg,_#22c55e,_#16a34a_)] [color:white] [display:flex] [align-items:center] [justify-content:center] [font-size:42px] [font-weight:700] [box-shadow:0_20px_50px_rgba(34,197,94,.25)] [animation:popIn_.6s_ease]">✓</div>

        <span className="[display:inline-block] [padding:8px_16px] [background:#ecfdf5] [color:#15803d] [border-radius:999px] [font-weight:600] [margin-bottom:18px]">Subscription Activated</span>

        <h1>Payment Successful 🎉</h1>

        <p className="[color:#64748b] [font-size:1.1rem] [margin-bottom:40px]">
          Your care plan is now active and we're preparing your personalized
          dashboard.
        </p>

        <div className="[display:flex] [flex-direction:column] [gap:14px] [margin-bottom:30px]">
          <div className="[padding:18px] [border-radius:16px] [background:white] [border:1px_solid_#e2e8f0] [display:flex] [align-items:center] [gap:12px] [border-color:#22c55e]">
            <span>✓</span>
            Payment Verified
          </div>

          <div className="[padding:18px] [border-radius:16px] [background:white] [border:1px_solid_#e2e8f0] [display:flex] [align-items:center] [gap:12px] [border-color:#22c55e]">
            <span>✓</span>
            Subscription Activated
          </div>

          <div className="[padding:18px] [border-radius:16px] [background:white] [border:1px_solid_#e2e8f0] [display:flex] [align-items:center] [gap:12px] [border-color:#8b5cf6]">
            <span>⏳</span>
            Preparing Dashboard
          </div>
        </div>

        <div className="[color:#8b5cf6] [font-weight:600]">Redirecting you automatically...</div>
      </div>
    </section>
  );
}

export default Success;

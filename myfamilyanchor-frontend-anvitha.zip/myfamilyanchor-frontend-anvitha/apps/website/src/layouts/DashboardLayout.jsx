import { Outlet, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import { FiMenu, FiX } from "react-icons/fi";

import { useAuth } from "@auth/AuthContext";
import Sidebar from "../components/Sidebar";
import LogoutModal from "@ui/LogoutModal";

function DashboardLayout() {
  const [showLogoutModal, setShowLogoutModal] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  const navigate = useNavigate();
  const { logout } = useAuth();

  const handleLogout = () => {
    logout();
    navigate("/", { replace: true });
  };

  // Lock body scroll when drawer is open
  useEffect(() => {
    document.body.style.overflow = mobileSidebarOpen ? "hidden" : "auto";
    return () => {
      document.body.style.overflow = "auto";
    };
  }, [mobileSidebarOpen]);

  // Close drawer on Escape
  useEffect(() => {
    const closeOnEscape = (e) => {
      if (e.key === "Escape") setMobileSidebarOpen(false);
    };
    window.addEventListener("keydown", closeOnEscape);
    return () => window.removeEventListener("keydown", closeOnEscape);
  }, []);

  return (
    <div
      className="
        flex items-start min-h-screen
        bg-[radial-gradient(circle_at_24%_0%,rgba(255,92,168,0.12),transparent_30%),radial-gradient(circle_at_88%_4%,rgba(255,155,84,0.14),transparent_28%),linear-gradient(180deg,#fff8fc_0%,#f8f3ff_52%,#ffffff_100%)]
        lg:h-screen lg:max-h-screen lg:overflow-hidden lg:items-stretch
      "
    >
      <LogoutModal
        open={showLogoutModal}
        onClose={() => setShowLogoutModal(false)}
        onConfirm={handleLogout}
      />

      {/* Desktop Sidebar — left side */}
      <div className="hidden lg:flex">
        <Sidebar onLogoutClick={() => setShowLogoutModal(true)} />
      </div>

      {/* Mobile right-side Drawer */}
      <div
        className={`
          fixed inset-0 z-[999]
          lg:hidden
          transition-all duration-300
          ${mobileSidebarOpen ? "visible opacity-100" : "invisible opacity-0"}
        `}
      >
        {/* Backdrop */}
        <div
          className="absolute inset-0 bg-black/40 backdrop-blur-sm"
          onClick={() => setMobileSidebarOpen(false)}
        />

        {/* Drawer panel — slides from RIGHT */}
        <div
          className={`
            absolute right-0 top-0
            h-full w-[300px] max-w-[85vw]
            overflow-y-auto shadow-2xl
            transition-transform duration-300
            ${mobileSidebarOpen ? "translate-x-0" : "translate-x-full"}
          `}
        >
          {/* Close button */}
          <div className="flex justify-start bg-white/95 p-4">
            <button
              onClick={() => setMobileSidebarOpen(false)}
              className="w-10 h-10 rounded-xl flex items-center justify-center hover:bg-slate-100"
              aria-label="Close menu"
            >
              <FiX size={22} />
            </button>
          </div>

          <Sidebar
            onLogoutClick={() => {
              setMobileSidebarOpen(false);
              setShowLogoutModal(true);
            }}
          />
        </div>
      </div>

      <main
        className="
          flex-1 min-w-0
          px-5 pt-5 pb-28
          md:px-6 md:pt-6
          lg:px-[34px] lg:pt-[34px] lg:pb-[64px]
          lg:h-screen lg:overflow-y-auto
        "
      >
        {/* Mobile Header */}
        <header
          className="
            lg:hidden
            sticky top-0 z-50
            mb-5 h-16 rounded-2xl px-4
            bg-white/80 backdrop-blur-xl
            border border-white/60
            flex items-center justify-between
            shadow-[0_10px_30px_rgba(123,63,242,0.08)]
          "
        >
          {/* Left spacer */}
          <div className="w-10" />

          <h1 className="text-[1rem] font-black text-[#111827]">
            MyFamilyAnchor
          </h1>

          {/* Hamburger on the RIGHT */}
          <button
            onClick={() => setMobileSidebarOpen(true)}
            className="w-10 h-10 rounded-xl flex items-center justify-center hover:bg-slate-100"
            aria-label="Open menu"
          >
            <FiMenu size={22} />
          </button>
        </header>

        <Outlet />
      </main>
    </div>
  );
}

export default DashboardLayout;

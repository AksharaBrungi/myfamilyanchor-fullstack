﻿
import { useEffect, useRef, useState } from "react";
import { FiMessageCircle, FiX, FiSend, FiMinus } from "react-icons/fi";
import API from "@api/axios";
import { PLAN_SERVICES } from "../data/planServices";
import "./AIAssistant.css";

const GUIDED_MENUS = {
  main: [
    { label: "Explore Plans", message: "Show plans", next: "plans" },
    { label: "Family Care", message: "What family care services are available?", next: "family" },
    { label: "Property Care", message: "What property care services are available?", next: "property" },
    { label: "Pricing & Allowances", message: "Explain included allowances and on-demand costs", next: "pricing" },
    { label: "Request a Service", message: "How can I request a service?", next: "request" },
    { label: "Emergency Assistance", message: "Explain emergency assistance", next: "emergency" },
  ],
  plans: [
    { label: "Property Guardian", message: "Explain Property Guardian" },
    { label: "Family Guardian", message: "Explain Family Guardian" },
    { label: "Guardian Premium", message: "Explain Guardian Premium" },
    { label: "Compare Plans", message: "Compare plans" },
  ],
  family: [
    { label: "Medicine Delivery", message: "What is medicine delivery?" },
    { label: "Doctor Appointment", message: "What is doctor appointment support?" },
    { label: "Hospital Visit Support", message: "Explain hospital visit support" },
    { label: "Wellness Check", message: "Explain wellness check" },
    { label: "Companionship Visit", message: "Explain companionship visit" },
    { label: "Grocery Assistance", message: "Explain grocery assistance" },
  ],
  property: [
    { label: "Property Inspection", message: "Explain property inspection" },
    { label: "Plumbing Support", message: "Explain plumbing support" },
    { label: "Electrical Repair", message: "Explain electrical repair" },
    { label: "House Cleaning", message: "Explain house cleaning" },
    { label: "Gardening", message: "Explain gardening" },
    { label: "AC Servicing", message: "Explain AC servicing" },
  ],
  pricing: [
    { label: "Included Allowances", message: "Explain included allowances" },
    { label: "On-demand Costs", message: "Explain on-demand service costs" },
    { label: "Compare Plans", message: "Compare plans" },
  ],
  request: [
    { label: "Start a Service Request", action: "request" },
    { label: "Family Care Request", message: "How can I request family care?" },
    { label: "Property Care Request", message: "How can I request property care?" },
    { label: "Check Request Status", message: "What is my request status?" },
  ],
  emergency: [
    { label: "Family Emergency Assistance", message: "Explain family emergency assistance" },
    { label: "Property Emergency Visit", message: "Explain emergency property visit" },
    { label: "Contact Support", message: "How do I contact MyFamilyAnchor support?" },
  ],
};

const INITIAL_MESSAGE = {
  role: "assistant",
  text: "Hi! I'm the MyFamilyAnchor assistant. I can explain care plans and services, and help you submit a service request. General answers are running in demo mode.",
};

const initialRequestForm = {
  category: "",
  serviceType: "",
  description: "",
  address: "",
  preferredDate: "",
  priority: "normal",
};

const today = () => {
  const date = new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
};

export default function AIAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState([INITIAL_MESSAGE]);
  const [isSending, setIsSending] = useState(false);
  const [error, setError] = useState("");
  const [activeMenu, setActiveMenu] = useState("main");

  const [showRequestForm, setShowRequestForm] = useState(false);
  const [requestForm, setRequestForm] = useState(initialRequestForm);
  const [isSubmittingRequest, setIsSubmittingRequest] = useState(false);
  const [requestError, setRequestError] = useState("");

  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isOpen, showRequestForm]);

  useEffect(() => {
    if (isOpen && !showRequestForm) inputRef.current?.focus();
  }, [isOpen, showRequestForm]);

  async function handleSubmit(event, quickText) {
    event?.preventDefault();

    const text = (quickText ?? message).trim();
    if (!text || isSending) return;

    if (text.length > 1000) {
      setError("Please keep your message within 1000 characters.");
      return;
    }

    setError("");
    setMessage("");
    setMessages((current) => [...current, { role: "user", text }]);
    setIsSending(true);

    try {
      const response = await API.post("/ai/chat", { message: text });
      const data = response.data;

      if (typeof data?.reply !== "string" || !data.reply.trim()) {
        throw new Error("The assistant returned an unexpected response.");
      }

      setMessages((current) => [
        ...current,
        {
          role: "assistant",
          text: data.reply,
          label: data.label || "Demo mode - scripted replies",
        },
      ]);
    } catch (requestError) {
      const status = requestError.response?.status;
      const reply =
        status === 503
          ? "The demo assistant is currently unavailable. Please try again later."
          : status === 400
            ? "Please enter a valid message and try again."
            : "I couldn't connect to the assistant. Please check that the backend is running and try again.";

      setMessages((current) => [
        ...current,
        { role: "assistant", text: reply, label: "Connection notice" },
      ]);
    } finally {
      setIsSending(false);
    }
  }

  function updateRequestField(field, value) {
    setRequestForm((current) => ({
      ...current,
      [field]: value,
    }));
    setRequestError("");
  }

  async function handleRequestSubmit(event) {
    event.preventDefault();
    if (isSubmittingRequest) return;

    const token = localStorage.getItem("token");

    if (!token) {
      setRequestError(
        "Please log in to your MyFamilyAnchor user account before submitting a service request."
      );
      return;
    }

    const payload = {
      category: requestForm.category,
      serviceType: requestForm.serviceType.trim(),
      description: requestForm.description.trim(),
      address: requestForm.address.trim(),
      preferredDate: requestForm.preferredDate,
      priority: requestForm.priority,
    };

    if (
      !payload.category ||
      !payload.serviceType ||
      !payload.description ||
      !payload.address ||
      !payload.preferredDate
    ) {
      setRequestError("Please complete all required fields.");
      return;
    }

    setRequestError("");
    setIsSubmittingRequest(true);

    try {
      const response = await API.post("/services/create", payload);
      const createdRequest = response.data;

      setMessages((current) => [
        ...current,
        {
          role: "assistant",
          text:
            `Your service request has been submitted successfully!\n\n` +
            `Service: ${createdRequest.serviceType || payload.serviceType}\n` +
            `Category: ${createdRequest.category || payload.category}\n` +
            `Preferred date: ${payload.preferredDate}\n` +
            `Status: ${createdRequest.status || "pending"}\n\n` +
            "Your request is awaiting review. This is not a confirmed appointment slot; the team will review your request and coordinate the service.",
          label: "Service request submitted",
        },
      ]);

      setRequestForm(initialRequestForm);
      setShowRequestForm(false);
      setActiveMenu("main");
    } catch (requestError) {
      const status = requestError.response?.status;
      const serverMessage = requestError.response?.data?.message;

      if (status === 401) {
        setRequestError(
          "Your login may have expired. Please log in again and retry your request."
        );
      } else if (status === 403) {
        setRequestError(
          serverMessage ||
            "This service may not be available on your current plan or allowance."
        );
      } else if (status === 400) {
        setRequestError(
          serverMessage || "Some request details are invalid. Please check them."
        );
      } else {
        setRequestError(
          serverMessage ||
            "We couldn't submit the request. Please check your connection and try again."
        );
      }
    } finally {
      setIsSubmittingRequest(false);
    }
  }

  function startRequestForm() {
    setRequestError("");
    setShowRequestForm(true);
  }

  return (
    <div className="mfa-chat">
      {isOpen && (
        <section
          className="mfa-chat-panel"
          role="dialog"
          aria-label="MyFamilyAnchor assistant"
          aria-modal="false"
        >
          <header className="mfa-chat-header">
            <div className="mfa-chat-brand">
              <span className="mfa-chat-avatar" aria-hidden="true">
                <FiMessageCircle />
              </span>
              <div>
                <h2>MyFamilyAnchor</h2>
                <p>Care &amp; services assistant</p>
              </div>
            </div>

            <div className="mfa-chat-header-actions">
              <button
                type="button"
                className="mfa-chat-icon-button"
                aria-label="Minimize chat"
                onClick={() => setIsOpen(false)}
              >
                <FiMinus />
              </button>
              <button
                type="button"
                className="mfa-chat-icon-button"
                aria-label="Close chat"
                onClick={() => setIsOpen(false)}
              >
                <FiX />
              </button>
            </div>
          </header>

          <div className="mfa-chat-demo-notice">
            Demo answers · Service requests require login
          </div>

          <div className="mfa-chat-messages" aria-live="polite">
            {messages.map((item, index) => (
              <div
                className={`mfa-chat-message mfa-chat-message-${item.role}`}
                key={`${index}-${item.role}`}
              >
                <div className="mfa-chat-bubble">{item.text}</div>
                {item.label && item.role === "assistant" && index > 0 && (
                  <span className="mfa-chat-message-label">{item.label}</span>
                )}
              </div>
            ))}

            {isSending && (
              <div className="mfa-chat-message mfa-chat-message-assistant">
                <div className="mfa-chat-bubble mfa-chat-typing">
                  Thinking…
                </div>
              </div>
            )}

            {!isSending && !showRequestForm && (
              <div
                className="mfa-chat-quick-options"
                aria-label="Suggested questions"
              >
                {GUIDED_MENUS[activeMenu].map((option) => (
                  <button
                    key={option.label}
                    type="button"
                    className="mfa-chat-quick-option"
                    onClick={() => {
                      if (option.action === "request") {
                        startRequestForm();
                        return;
                      }

                      if (option.next) setActiveMenu(option.next);
                      if (option.message) {
                        void handleSubmit(null, option.message);
                      }
                    }}
                  >
                    {option.label}
                  </button>
                ))}

                {activeMenu !== "main" && (
                  <button
                    type="button"
                    className="mfa-chat-quick-option"
                    onClick={() => setActiveMenu("main")}
                  >
                    ← Back to Main Menu
                  </button>
                )}
              </div>
            )}

            {showRequestForm && (
              <form
                className="mfa-chat-request-form"
                onSubmit={handleRequestSubmit}
                style={{
                  display: "grid",
                  gap: "12px",
                  padding: "14px",
                  margin: "8px 0",
                  border: "1px solid #e3e7eb",
                  borderRadius: "12px",
                  background: "var(--mfa-chat-form-bg, #fff)",
                }}
              >
                <h3 style={{ margin: 0 }}>Request a Service</h3>
                <p style={{ margin: 0, fontSize: "13px" }}>
                  Complete the details below. Your request will be reviewed by
                  the MyFamilyAnchor team.
                </p>

                <label style={fieldStyle}>
                  Category *
                  <select
                    required
                    value={requestForm.category}
                    onChange={(event) => {
                      setRequestForm((current) => ({
                        ...current,
                        category: event.target.value,
                        serviceType: "",
                      }));
                      setRequestError("");
                    }}
                    style={requestInputStyle}
                  >
                    <option value="">Select a category</option>
                    {Object.keys(
                      PLAN_SERVICES["Guardian Premium"]?.categories || {}
                    ).map((category) => (
                      <option key={category} value={category}>
                        {category === "property"
                          ? "Property Care"
                          : category === "family"
                            ? "Family Care"
                            : "Premium"}
                      </option>
                    ))}
                  </select>
                </label>

                <label style={fieldStyle}>
                  Service type *
                  <select
                    required
                    value={requestForm.serviceType}
                    onChange={(event) =>
                      updateRequestField("serviceType", event.target.value)
                    }
                    disabled={!requestForm.category}
                    style={requestInputStyle}
                  >
                    <option value="">Select a service</option>
                    {(
                      PLAN_SERVICES["Guardian Premium"]?.categories?.[
                        requestForm.category
                      ] || []
                    ).map((service) => (
                      <option key={service} value={service}>
                        {service}
                      </option>
                    ))}
                  </select>
                </label>

                <p style={hintStyle}>
                  Services are shown using the Guardian Premium catalogue. Your
                  backend still verifies eligibility before accepting a request.
                </p>

                <label style={fieldStyle}>
                  Describe your request *
                  <textarea
                    required
                    maxLength={1500}
                    rows={3}
                    value={requestForm.description}
                    onChange={(event) =>
                      updateRequestField("description", event.target.value)
                    }
                    placeholder="Tell us what help you need"
                    style={requestInputStyle}
                  />
                </label>

                <label style={fieldStyle}>
                  Service address *
                  <textarea
                    required
                    maxLength={500}
                    rows={2}
                    value={requestForm.address}
                    onChange={(event) =>
                      updateRequestField("address", event.target.value)
                    }
                    placeholder="Where is the service required?"
                    style={requestInputStyle}
                  />
                </label>

                <label style={fieldStyle}>
                  Preferred date *
                  <input
                    type="date"
                    required
                    min={today()}
                    value={requestForm.preferredDate}
                    onChange={(event) =>
                      updateRequestField("preferredDate", event.target.value)
                    }
                    style={requestInputStyle}
                  />
                </label>

                <label style={fieldStyle}>
                  Priority
                  <select
                    value={requestForm.priority}
                    onChange={(event) =>
                      updateRequestField("priority", event.target.value)
                    }
                    style={requestInputStyle}
                  >
                    <option value="low">Low</option>
                    <option value="normal">Normal</option>
                    <option value="high">High</option>
                    <option value="emergency">Emergency</option>
                  </select>
                </label>

                <p style={{ margin: 0, fontSize: "12px" }}>
                  Selecting a preferred date does not reserve or confirm a
                  time slot.
                </p>

                {requestError && (
                  <p
                    role="alert"
                    className="mfa-chat-error"
                    style={{ margin: 0 }}
                  >
                    {requestError}
                  </p>
                )}

                <button
                  type="submit"
                  className="mfa-chat-quick-option"
                  disabled={isSubmittingRequest}
                >
                  {isSubmittingRequest
                    ? "Submitting…"
                    : "Submit Service Request"}
                </button>

                <button
                  type="button"
                  className="mfa-chat-quick-option"
                  disabled={isSubmittingRequest}
                  onClick={() => {
                    setShowRequestForm(false);
                    setRequestError("");
                  }}
                >
                  Cancel
                </button>
              </form>
            )}

            <div ref={messagesEndRef} />
          </div>

          {!showRequestForm && (
            <form className="mfa-chat-form" onSubmit={handleSubmit}>
              <label className="mfa-chat-sr-only" htmlFor="mfa-chat-input">
                Type your message
              </label>
              <textarea
                id="mfa-chat-input"
                ref={inputRef}
                value={message}
                onChange={(event) => {
                  setMessage(event.target.value);
                  if (error) setError("");
                }}
                onKeyDown={(event) => {
                  if (event.key === "Enter" && !event.shiftKey) {
                    event.preventDefault();
                    event.currentTarget.form?.requestSubmit();
                  }
                }}
                placeholder="Ask about our care plans…"
                rows={1}
                maxLength={1000}
                disabled={isSending}
              />
              <button
                type="submit"
                className="mfa-chat-send"
                aria-label="Send message"
                disabled={isSending || !message.trim()}
              >
                <FiSend />
              </button>
            </form>
          )}

          {error && <p className="mfa-chat-error">{error}</p>}
          <p className="mfa-chat-footnote">
            Please don't share passwords or sensitive personal information.
          </p>
        </section>
      )}

      <button
        type="button"
        className={`mfa-chat-launcher ${isOpen ? "is-open" : ""}`}
        aria-label={isOpen ? "Close assistant" : "Open assistant"}
        aria-expanded={isOpen}
        onClick={() => {
          setIsOpen((current) => {
            const next = !current;
            if (next) setActiveMenu("main");
            return next;
          });
        }}
      >
        {isOpen ? <FiX /> : <FiMessageCircle />}
        {!isOpen && <span>Chat with us</span>}
      </button>
    </div>
  );
}

const fieldStyle = {
  display: "grid",
  gap: "5px",
  fontSize: "13px",
};

const hintStyle = {
  margin: "-6px 0 0",
  fontSize: "12px",
  opacity: 0.8,
};

const requestInputStyle = {
  width: "100%",
  boxSizing: "border-box",
  padding: "10px",
  border: "1px solid #d5dbe1",
  borderRadius: "8px",
  background: "white",
  color: "#20252b",
  font: "inherit",
};

import heroImage from "@assets/hero.png";
import { Link } from "react-router-dom";

const careUpdates = [
  ["Health Check", "All Good", "✓"],
  ["Medicine", "Taken on time", "✓"],
  ["Activity", "Morning walk", "✓"],
  ["Mood", "Happy", "✓"],
];

function Hero() {
  return (
    <div className="pt-[50px]">
      <section
        className="relative w-[min(1480px,calc(100%-32px))] mx-auto mt-[34px] px-6 pt-[54px] pb-[88px] overflow-hidden max-[980px]:pt-[34px] max-[640px]:w-[min(calc(100%-20px),520px)] max-[640px]:px-1"
        id="home"
      >
        {/* Glow blobs */}
        <div className="absolute rounded-full blur-[28px] opacity-65 w-[300px] h-[300px] -left-20 top-[100px] bg-[rgba(255,92,168,0.22)] pointer-events-none" />
        <div className="absolute rounded-full blur-[28px] opacity-65 w-[360px] h-[360px] -right-[90px] bottom-5 bg-[rgba(255,155,84,0.2)] pointer-events-none" />

        {/* Main grid */}
        <div
          className="relative grid grid-cols-[0.92fr_1.08fr] items-center gap-[46px] min-h-[650px]
             max-[980px]:grid-cols-1 max-[980px]:gap-7
             [animation:fadeUp_0.8s_ease_both]"
        >
          {/* ── Left copy column ── */}
          <div className="relative z-[2]">
            {/* Badge */}
            <span className="inline-flex items-center min-h-[42px] px-[18px] rounded-full text-[#6d28d9] bg-[rgba(246,240,255,0.9)] border border-[rgba(123,63,242,0.12)] text-[0.78rem] font-black tracking-[0.08em] uppercase shadow-[0_18px_40px_rgba(123,63,242,0.1)]">
              India's most trusted NRI parent care
            </span>

            {/* Headline */}
            <h1 className="mt-6 mb-5 font-['Cormorant_Garamond',serif] text-[#080f2a] text-[clamp(4rem,6vw,7.4rem)] leading-[0.86] tracking-normal max-[980px]:text-[clamp(3.6rem,13vw,6rem)] max-[640px]:text-[3.7rem]">
              Because They
              <br />
              Cared for You,
              <br />
              <span className="bg-gradient-to-br from-[#7b3ff2] via-[#ff5ca8] to-[#ff9b54] bg-clip-text text-transparent">
                Now It's Your Turn.
              </span>
            </h1>

            {/* Body */}
            <p className="w-[min(590px,100%)] text-[#374151] text-[1.12rem] leading-[1.8] max-[640px]:text-base">
              Complete care and peace of mind for your parents in India. From
              health and wellness to daily support and emotional companionship,
              we're there like family.
            </p>

            {/* CTA buttons */}
            <div className="flex flex-wrap items-center gap-4 mt-[30px] max-[640px]:grid max-[640px]:grid-cols-1">
              <a
                href="/booking"
                className="
                   inline-flex items-center justify-center gap-[10px]
                   min-h-[58px] px-9 rounded-full flex-1 min-w-[240px]
                   bg-gradient-to-br from-[#7b3ff2] via-[#ff5ca8] to-[#ff9b54] [background-size:200%_200%]
                   text-white text-base font-extrabold tracking-[0.02em]
                   border-none cursor-pointer relative overflow-hidden no-underline
                   shadow-[0_6px_24px_rgba(123,63,242,0.35),0_2px_8px_rgba(255,92,168,0.2),inset_0_1px_0_rgba(255,255,255,0.18)]
                   transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)]
                   [animation:gradientShift_4s_ease_infinite]
                   before:content-[''] before:absolute before:inset-0 before:bg-[linear-gradient(135deg,rgba(255,255,255,0.18),transparent_60%)] before:rounded-[inherit] before:pointer-events-none
                   hover:-translate-y-[3px] hover:scale-[1.03]
                   hover:shadow-[0_14px_40px_rgba(123,63,242,0.45),0_4px_16px_rgba(255,92,168,0.3),inset_0_1px_0_rgba(255,255,255,0.2)]
                   active:-translate-y-[1px] active:scale-[1.01]
                   [&_span]:inline-block [&_span]:transition-transform [&_span]:duration-300
                   hover:[&_span]:translate-x-1
                   max-[640px]:w-full
                 "
              >
                Book Your Consultation <span>→</span>
              </a>

              <Link
                to="/how-it-works"
                className="
                   inline-flex items-center justify-center gap-[10px]
                   min-h-[58px] px-8 rounded-full flex-1 min-w-[240px]
                   bg-[rgba(255,255,255,0.85)] text-[#7b3ff2]
                   text-base font-extrabold tracking-[0.02em] no-underline cursor-pointer
                   relative border-2 border-transparent [background-clip:padding-box]
                   shadow-[0_4px_20px_rgba(123,63,242,0.12),inset_0_1px_0_rgba(255,255,255,0.9)]
                   backdrop-blur-[12px]
                   transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)]
                   outline outline-2 outline-[rgba(123,63,242,0.2)]
                   hover:bg-[rgba(246,240,255,0.95)] hover:outline-[rgba(123,63,242,0.5)]
                   hover:-translate-y-[3px] hover:scale-[1.03]
                   hover:shadow-[0_10px_32px_rgba(123,63,242,0.2),inset_0_1px_0_rgba(255,255,255,1)]
                   hover:text-[#5b1fd1]
                   active:-translate-y-[1px] active:scale-[1.01]
                   max-[640px]:w-full
                 "
              >
                Watch How It Works
              </Link>
            </div>

            {/* Trust row */}
            <div className="flex items-center gap-[18px] mt-[34px] max-[640px]:items-start">
              {/* Avatar stack */}
              <div className="flex">
                {["A", "P", "R", "S", "+"].map((letter, i) => (
                  <span
                    key={letter}
                    className={`w-[42px] h-[42px] ${i === 0 ? "ml-0" : "-ml-[10px]"} rounded-full grid place-items-center text-white bg-gradient-to-br from-[#7b3ff2] to-[#ff5ca8] border-[3px] border-white text-[0.8rem] font-black`}
                  >
                    {letter}
                  </span>
                ))}
              </div>
              <div>
                <strong className="text-[#f6b800] tracking-[0.2em]">
                  ★★★★★
                </strong>
                <p className="mt-[5px] text-[#374151] text-[0.94rem] leading-[1.4]">
                  Trusted by 10,000+ NRI families across 30+ countries
                </p>
              </div>
            </div>
          </div>

          {/* ── Right visual column ── */}
          <div className="relative min-h-[620px] max-[980px]:min-h-[560px] max-[640px]:min-h-[600px]">
            {/* Hero image */}
            <div className="absolute inset-[22px_40px_0_0] rounded-[46%_46%_28px_28px] overflow-hidden shadow-[0_36px_90px_rgba(123,63,242,0.18)] max-[640px]:inset-[20px_0_160px] max-[640px]:rounded-[34px]">
              <img
                src={heroImage}
                alt="Smiling elderly Indian parents"
                className="w-full h-full object-cover"
              />
            </div>

            {/* Live Care Updates card */}
            <div
              className="
                 absolute z-[3] rounded-[28px] top-[42px] right-0 w-[285px] p-[22px]
                 bg-[rgba(255,255,255,0.72)] border border-[rgba(255,255,255,0.78)]
                 shadow-[0_24px_70px_rgba(123,63,242,0.13)] backdrop-blur-[22px]
                 [animation:floatSoft_5s_ease-in-out_infinite]
                 max-[640px]:relative max-[640px]:top-auto max-[640px]:right-auto
                 max-[640px]:w-full max-[640px]:mt-[330px]
               "
            >
              <div className="flex items-center justify-between mb-[18px]">
                <strong>Live Care Updates</strong>
                <span className="text-[#16a34a] text-[0.76rem] font-black uppercase">
                  ● Live
                </span>
              </div>

              {careUpdates.map(([title, value, check]) => (
                <div key={title} className="flex items-center gap-3 py-3">
                  <span className="w-[34px] h-[34px] rounded-[14px] text-[#16a34a] bg-[#ecfdf5] grid place-items-center font-black flex-shrink-0">
                    {check}
                  </span>
                  <div>
                    <small className="block text-[#6b7280] font-bold">
                      {title}
                    </small>
                    <strong className="text-[#111827] text-[0.95rem]">
                      {value}
                    </strong>
                  </div>
                </div>
              ))}
            </div>

            {/* Care Manager card */}
            <div
              className="
                 absolute z-[3] rounded-[28px] right-0 bottom-[82px] w-[310px] p-[18px]
                 flex items-center gap-[14px]
                 bg-[rgba(255,255,255,0.72)] border border-[rgba(255,255,255,0.78)]
                 shadow-[0_24px_70px_rgba(123,63,242,0.13)] backdrop-blur-[22px]
                 [animation:floatSoft_6s_ease-in-out_infinite]
                 max-[640px]:relative max-[640px]:right-auto max-[640px]:bottom-auto
                 max-[640px]:w-full max-[640px]:mt-[14px]
               "
            >
              <div className="w-[62px] h-[62px] rounded-[22px] grid place-items-center text-white bg-gradient-to-br from-[#ff5ca8] to-[#7b3ff2] font-black flex-shrink-0">
                SR
              </div>
              <div>
                <small className="block text-[#6b7280] font-bold">
                  Your Care Manager
                </small>
                <strong className="text-[#111827] text-[0.95rem]">
                  Sneha R.
                </strong>
                <p className="mt-1 text-[#6b7280] text-[0.85rem]">
                  Available 24x7
                </p>
              </div>
              <span className="ml-auto w-[42px] h-[42px] rounded-[16px] text-[#7b3ff2] bg-[#f6f0ff] grid place-items-center flex-shrink-0">
                ☎
              </span>
            </div>

            {/* Location card */}
            <div
              className="
                 absolute z-[3] rounded-[28px] left-0 bottom-[30px] w-[360px] p-[18px]
                 flex items-center gap-[14px]
                 bg-[rgba(255,255,255,0.72)] border border-[rgba(255,255,255,0.78)]
                 shadow-[0_24px_70px_rgba(123,63,242,0.13)] backdrop-blur-[22px]
                 [animation:floatSoft_7s_ease-in-out_infinite]
                 max-[640px]:relative max-[640px]:left-auto max-[640px]:bottom-auto
                 max-[640px]:w-full max-[640px]:mt-[14px]
               "
            >
              <span className="w-[54px] h-[54px] rounded-[19px] text-white bg-gradient-to-br from-[#7b3ff2] to-[#9b6cff] grid place-items-center text-2xl flex-shrink-0">
                ⌖
              </span>
              <div>
                <strong className="text-[#111827] text-[0.95rem]">
                  Hyderabad, Telangana
                </strong>
                <p className="mt-1 text-[#6b7280] text-[0.85rem]">
                  Care team nearby
                </p>
              </div>
              {/* Mini faces */}
              <div className="ml-auto flex items-center">
                {["bg-[#ff9b54]", "bg-[#ff5ca8]", "bg-[#7b3ff2]"].map(
                  (bg, i) => (
                    <span
                      key={i}
                      className={`w-[28px] h-[28px] -ml-2 first:ml-0 rounded-full border-2 border-white ${bg}`}
                    />
                  ),
                )}
                <b className="w-[28px] h-[28px] -ml-2 rounded-full border-2 border-white grid place-items-center text-white bg-[#7b3ff2] text-[0.65rem]">
                  +12
                </b>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Hero;

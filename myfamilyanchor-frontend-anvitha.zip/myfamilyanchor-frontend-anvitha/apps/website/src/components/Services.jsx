import { Link } from "react-router-dom";
import { heroMD, gradientText } from "@ui/heroTypography";

const services = [
  [
    "Health & Wellness",
    "Regular checkups, doctor visits, teleconsultations, reports tracking, vitals monitoring and wellness guidance.",
    "♥",
  ],
  [
    "Daily Living Support",
    "Assistance with groceries, meals, bill payments, errands, housekeeping and everyday comfort needs.",
    "⌂",
  ],
  [
    "24/7 Emergency Care",
    "Emergency coordination, ambulance support, hospital admission assistance and family alerts.",
    "!",
  ],
  [
    "Companionship",
    "Warm conversations, festival visits, hobby engagement, walks and emotional support.",
    "☻",
  ],
  [
    "NRI Property Care",
    "Home inspections, maintenance coordination, security checks and tenant/vendor support.",
    "⌁",
  ],
  [
    "Medicine Management",
    "Prescription refills, reminders, medicine delivery coordination and adherence updates.",
    "✚",
  ],
  [
    "Doctor Consultation",
    "Online and in-person consultation planning with trusted local medical partners.",
    "◉",
  ],
  [
    "Travel & Stay Support",
    "Airport assistance, local transport, hotel help and family visit coordination.",
    "✈",
  ],
];

const serviceIconColors = [
  "linear-gradient(135deg, #ff5ca8, #ff8fba)",
  "linear-gradient(135deg, #5b8cff, #7b3ff2)",
  "linear-gradient(135deg, #ffbf2f, #ff9b54)",
  "linear-gradient(135deg, #b13cff, #7b3ff2)",
  "linear-gradient(135deg, #48c774, #16a34a)",
];

function Services() {
  return (
    <div className="pt-[10px]">
      <section
        className="[width:min(1360px,_calc(100%_-_36px))] [margin:48px_auto_0] [padding:48px_0_96px] max-[640px]:[width:min(100%_-_20px,_520px)] max-[640px]:[padding-left:4px] max-[640px]:[padding-right:4px]"
        id="services"
      >
        <div
          className="[min-height:auto] [padding:64px_54px_52px] [border-radius:34px] [background:radial-gradient(_circle_at_80%_20%,_rgba(255,_155,_84,_0.2),_transparent_30%_),_radial-gradient(_circle_at_20%_10%,_rgba(255,_92,_168,_0.16),_transparent_28%_),_rgba(255,_255,_255,_0.62)] [border:1px_solid_rgba(255,_255,_255,_0.82)] [box-shadow:0_28px_80px_rgba(123,_63,_242,_0.1)] [-webkit-backdrop-filter:blur(18px)] [backdrop-filter:blur(18px)] [text-align:center] [&_h1]:[width:100%]
        [&_h1]:[max-width:980px] [&_h1]:[margin:12px_auto_0] [&_h1]:[text-align:center] [&_h1]:[font-family:Cormorant_Garamond_serif] [&_h1]:[color:#0b1026] [&_h1]:[font-size:clamp(3.6rem,_6vw,_6.8rem)] [&_h1]:[line-height:0.9] [&_p]:[max-width:720px] [&_p]:[width:min(640px,_100%)] [&_p]:[margin:0_auto] [&_p]:[color:#374151] [&_p]:[font-size:1.08rem] [&_p]:[line-height:1.8] max-[980px]:[padding:42px_24px]"
        >
          <span className="[color:#7b3ff2] [font-size:0.78rem] [font-weight:800] [letter-spacing:0.14em] [text-transform:uppercase]">
            Care that connects hearts
          </span>
          <h1 className={heroMD}>
            Our <span style={gradientText}>Services</span>
          </h1>
          <p>
            Comprehensive care solutions for your parents, elders, home and
            family responsibilities in India.
          </p>
        </div>

        <div className="[display:grid] [grid-template-columns:repeat(4,_1fr)] [gap:18px] [margin-top:28px] max-[980px]:[grid-template-columns:repeat(2,_1fr)] max-[640px]:[grid-template-columns:1fr]">
          {services.map(([title, description, icon], index) => (
            <article
              className="[min-height:265px] [padding:26px] [border-radius:28px] [background:rgba(255,_255,_255,_0.72)] [border:1px_solid_rgba(255,_255,_255,_0.88)] [box-shadow:0_24px_70px_rgba(123,_63,_242,_0.1)] [-webkit-backdrop-filter:blur(18px)] [backdrop-filter:blur(18px)] [transition:0.28s_ease] hover:[transform:translateY(-10px)] hover:[box-shadow:0_34px_80px_rgba(123,_63,_242,_0.16)] [&_h3]:[margin:22px_0_10px] [&_h3]:[color:#111827] [&_h3]:[font-size:1.08rem] [&_h3]:[font-weight:700] [&_p]:[margin:0] [&_p]:[color:#4b5563] [&_p]:[font-size:0.92rem] [&_p]:[line-height:1.65] [&_a]:[display:inline-flex] [&_a]:[margin-top:22px] [&_a]:[color:#7b3ff2] [&_a]:[font-weight:900] [&_a]:[font-size:0.92rem]"
              key={title}
            >
              <span
                style={{
                  width: "62px",
                  height: "62px",
                  borderRadius: "22px",
                  display: "grid",
                  placeItems: "center",
                  color: "white",
                  fontSize: "1.45rem",
                  fontWeight: "900",
                  boxShadow: "0 18px 34px rgba(123, 63, 242, 0.2)",
                  background: serviceIconColors[index % 5],
                }}
              >
                {icon}
              </span>
              <h3>{title}</h3>
              <p>{description}</p>
              <Link to="/booking">Book Free Call →</Link>
            </article>
          ))}
        </div>

        <div className="[margin-top:30px] [padding:28px] [border-radius:30px] [color:white] [background:linear-gradient(135deg,_#7b3ff2,_#9d4edd,_#ff5ca8,_#ff9b54)] [display:grid] [grid-template-columns:repeat(4,_1fr)] [gap:18px] [box-shadow:0_30px_80px_rgba(123,_63,_242,_0.24)] [&_div]:[text-align:center] [&_strong]:[display:block] [&_strong]:[font-size:2rem] [&_p]:[margin:6px_0_0] [&_p]:[opacity:0.9] max-[980px]:[grid-template-columns:repeat(2,_1fr)] max-[640px]:[grid-template-columns:1fr]">
          <div>
            <strong>10,000+</strong>
            <p>Happy Families</p>
          </div>
          <div>
            <strong>30+</strong>
            <p>Cities in India</p>
          </div>
          <div>
            <strong>24/7</strong>
            <p>Care Support</p>
          </div>
          <div>
            <strong>100+</strong>
            <p>Verified Experts</p>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Services;

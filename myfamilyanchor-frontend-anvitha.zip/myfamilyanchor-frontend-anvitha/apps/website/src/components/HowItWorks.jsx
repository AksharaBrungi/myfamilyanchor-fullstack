import { Link } from "react-router-dom";

const journeySteps = [
  {
    number: "01",
    title: "Understanding Your Family’s Needs",
    text: "We begin with a warm consultation where your family shares your parents’ health needs, routines, worries, preferences and emotional support requirements.",
    pills: [
      "Video consultation",
      "Care assessment",
      "Medical discussion",
      "Family priorities",
    ],
    visual: "consultation",
  },
  {
    number: "02",
    title: "Customized Care Designed Around Your Parents",
    text: "We create a personalized care plan covering health monitoring, medicine reminders, daily living, companionship, emergency support and property care.",
    pills: [
      "Medicine planning",
      "Health monitoring",
      "Emergency contacts",
      "Companion visits",
    ],
    visual: "plan",
    reverse: true,
  },
  {
    number: "03",
    title: "Dedicated Local Care Teams You Can Trust",
    text: "Your parents are supported by verified local care partners, a dedicated relationship manager and city-based support teams who understand your family.",
    pills: [
      "Verified caregivers",
      "Care manager",
      "City support",
      "Multilingual help",
    ],
    visual: "team",
  },
  {
    number: "04",
    title: "Stay Connected Through Real-Time Care Updates",
    text: "Every important moment is shared with you through simple updates: medicine taken, vitals stable, doctor visit complete, mood happy and emergencies resolved.",
    pills: [
      "Live updates",
      "Health vitals",
      "Doctor reports",
      "Emergency status",
    ],
    visual: "updates",
    reverse: true,
  },
  {
    number: "05",
    title: "Long-Term Support That Feels Like Family",
    text: "Care continues with monthly reports, emotional wellbeing tracking, family coordination, companionship and emergency readiness whenever your parents need help.",
    pills: [
      "Monthly reports",
      "Family coordination",
      "24/7 support",
      "Emotional care",
    ],
    visual: "support",
  },
];

function VisualMockup({ type }) {
  if (type === "consultation") {
    return (
      <div className="[position:relative] [min-height:430px] [padding:28px] [border-radius:34px] [overflow:hidden] [transition:0.3s_ease] hover:[transform:translateY(-8px)_scale(1.01)] max-[640px]:[min-height:360px] [background:rgba(255,_255,_255,_0.72)] [border:1px_solid_rgba(255,_255,_255,_0.78)] [box-shadow:0_24px_70px_rgba(123,_63,_242,_0.13)] [-webkit-backdrop-filter:blur(22px)] [backdrop-filter:blur(22px)]">
        <div className="[height:230px] [border-radius:28px] [padding:18px] [display:grid] [grid-template-columns:1fr_1fr] [gap:14px] [background:linear-gradient(_135deg,_rgba(123,_63,_242,_0.12),_rgba(255,_92,_168,_0.12)_)] max-[640px]:[grid-template-columns:1fr]">
          <div className="[border-radius:24px] [display:grid] [place-items:center] [color:white] [background:linear-gradient(135deg,_#7b3ff2,_#ff5ca8)] [font-weight:900] [&.parent]:[background:linear-gradient(135deg,_#ff9b54,_#ff5ca8)]">
            Care Expert
          </div>
          <div className="[border-radius:24px] [display:grid] [place-items:center] [color:white] [background:linear-gradient(135deg,_#7b3ff2,_#ff5ca8)] [font-weight:900] [&.parent]:[background:linear-gradient(135deg,_#ff9b54,_#ff5ca8)] parent">
            Parents
          </div>
        </div>
        <div className="[position:absolute] [padding:14px_18px] [border-radius:18px] [color:#111827] [background:rgba(255,_255,_255,_0.82)] [box-shadow:0_20px_48px_rgba(123,_63,_242,_0.16)] [font-weight:900] [animation:floatSoft_5s_ease-in-out_infinite] max-[640px]:[position:relative] max-[640px]:[inset:auto] max-[640px]:[margin-top:12px] [top:42px] [right:34px]">
          Call Scheduled
        </div>
        <div className="[position:absolute] [padding:14px_18px] [border-radius:18px] [color:#111827] [background:rgba(255,_255,_255,_0.82)] [box-shadow:0_20px_48px_rgba(123,_63,_242,_0.16)] [font-weight:900] [animation:floatSoft_5s_ease-in-out_infinite] max-[640px]:[position:relative] max-[640px]:[inset:auto] max-[640px]:[margin-top:12px] [left:36px] [bottom:124px]">
          Assessment Started
        </div>
        <div className="[margin-top:18px] [padding:20px] [border-radius:24px] [background:rgba(255,_255,_255,_0.74)] [display:grid] [gap:10px] [&_span]:[color:#4b5563] [&_span]:[font-weight:700]">
          <strong>Family Profile</strong>
          <span>Health needs reviewed</span>
          <span>Care expert assigned</span>
        </div>
      </div>
    );
  }

  if (type === "plan") {
    return (
      <div className="[position:relative] [min-height:430px] [padding:28px] [border-radius:34px] [overflow:hidden] [transition:0.3s_ease] hover:[transform:translateY(-8px)_scale(1.01)] max-[640px]:[min-height:360px] [background:rgba(255,_255,_255,_0.72)] [border:1px_solid_rgba(255,_255,_255,_0.78)] [box-shadow:0_24px_70px_rgba(123,_63,_242,_0.13)] [-webkit-backdrop-filter:blur(22px)] [backdrop-filter:blur(22px)] [display:grid] [align-content:center] [gap:16px]">
        {[
          "Medicine Reminder Active",
          "Weekly Health Monitoring",
          "Companion Visit Confirmed",
        ].map((item) => (
          <div
            className="[display:flex] [align-items:center] [gap:14px] [padding:18px] [border-radius:24px] [background:rgba(255,_255,_255,_0.78)] [box-shadow:0_18px_44px_rgba(123,_63,_242,_0.08)] [&_span]:[width:38px] [&_span]:[height:38px] [&_span]:[border-radius:15px] [&_span]:[color:#16a34a] [&_span]:[background:#ecfdf5] [&_span]:[display:grid] [&_span]:[place-items:center] [&_span]:[font-weight:900] [&_small]:[display:block] [&_small]:[color:#6b7280] [&_small]:[margin-top:4px]"
            key={item}
          >
            <span>✓</span>
            <div>
              <strong>{item}</strong>
              <small>Care plan updated</small>
            </div>
          </div>
        ))}
        <div className="[margin-top:18px] [padding:20px] [border-radius:24px] [background:rgba(255,_255,_255,_0.74)] [&_b]:[color:#111827] [&_p]:[margin:8px_0_0] [&_p]:[color:#4b5563]">
          <b>Today’s Plan</b>
          <p>Breakfast support · Medicine · Evening walk</p>
        </div>
      </div>
    );
  }

  if (type === "team") {
    return (
      <div className="[position:relative] [min-height:430px] [padding:28px] [border-radius:34px] [overflow:hidden] [transition:0.3s_ease] hover:[transform:translateY(-8px)_scale(1.01)] max-[640px]:[min-height:360px] [background:rgba(255,_255,_255,_0.72)] [border:1px_solid_rgba(255,_255,_255,_0.78)] [box-shadow:0_24px_70px_rgba(123,_63,_242,_0.13)] [-webkit-backdrop-filter:blur(22px)] [backdrop-filter:blur(22px)] [display:grid] [align-content:center] [gap:20px]">
        <div className="[display:flex] [align-items:center] [gap:14px] [padding:18px] [border-radius:24px] [background:rgba(255,_255,_255,_0.78)] [box-shadow:0_18px_44px_rgba(123,_63,_242,_0.08)] [&_b]:[margin-left:auto] [&_b]:[color:#16a34a] [&_b]:[background:#ecfdf5] [&_b]:[padding:8px_12px] [&_b]:[border-radius:999px] [&_span]:[display:block] [&_span]:[color:#6b7280] [&_span]:[margin-top:4px]">
          <div className="manager-avatar">SR</div>
          <div>
            <strong>Sneha R.</strong>
            <span>Dedicated Care Manager</span>
          </div>
          <b>Verified</b>
        </div>
        <div className="[display:flex] [flex-wrap:wrap] [gap:10px] [&_span]:[padding:12px_14px] [&_span]:[border-radius:999px] [&_span]:[color:#7b3ff2] [&_span]:[background:rgba(246,_240,_255,_0.86)] [&_span]:[font-weight:900]">
          <span>Hyderabad</span>
          <span>Hindi</span>
          <span>Telugu</span>
          <span>4.9 Rating</span>
        </div>
        <div className="[display:flex] [&_i]:[width:56px] [&_i]:[height:56px] [&_i]:[margin-left:-10px] [&_i]:[border-radius:50%] [&_i]:[border:3px_solid_white] [&_i]:[display:grid] [&_i]:[place-items:center] [&_i]:[color:white] [&_i]:[background:linear-gradient(135deg,_#7b3ff2,_#ff5ca8)] [&_i]:[font-style:normal] [&_i]:[font-weight:900] [&_i:first-child]:[margin-left:0]">
          <i>A</i>
          <i>P</i>
          <i>K</i>
          <i>+8</i>
        </div>
      </div>
    );
  }

  if (type === "updates") {
    return (
      <div className="[position:relative] [min-height:430px] [padding:28px] [border-radius:34px] [overflow:hidden] [transition:0.3s_ease] hover:[transform:translateY(-8px)_scale(1.01)] max-[640px]:[min-height:360px] [background:rgba(255,_255,_255,_0.72)] [border:1px_solid_rgba(255,_255,_255,_0.78)] [box-shadow:0_24px_70px_rgba(123,_63,_242,_0.13)] [-webkit-backdrop-filter:blur(22px)] [backdrop-filter:blur(22px)] [display:grid] [align-content:center] [gap:14px]">
        <div className="[display:flex] [justify-content:space-between] [margin-bottom:8px] [&_span]:[color:#16a34a] [&_span]:[font-weight:900]">
          <strong>Live Care Dashboard</strong>
          <span>● Live</span>
        </div>
        {[
          "Vitals Stable",
          "Doctor Visit Complete",
          "Mood: Happy",
          "Emergency Resolved",
        ].map((item) => (
          <div
            className="[display:flex] [align-items:center] [gap:14px] [padding:18px] [border-radius:24px] [background:rgba(255,_255,_255,_0.78)] [box-shadow:0_18px_44px_rgba(123,_63,_242,_0.08)] [&_span]:[width:38px] [&_span]:[height:38px] [&_span]:[border-radius:15px] [&_span]:[color:#16a34a] [&_span]:[background:#ecfdf5] [&_span]:[display:grid] [&_span]:[place-items:center] [&_span]:[font-weight:900] [&_small]:[margin-left:auto] [&_small]:[color:#6b7280]"
            key={item}
          >
            <span>✓</span>
            <strong>{item}</strong>
            <small>Just now</small>
          </div>
        ))}
        <div className="[height:112px] [padding:18px] [border-radius:24px] [background:rgba(255,_255,_255,_0.74)] [display:flex] [align-items:end] [gap:14px] [&_span]:[flex:1] [&_span]:[border-radius:999px] [&_span]:[background:linear-gradient(180deg,_#ff5ca8,_#7b3ff2)] [&_span:nth-child(1)]:[height:44%] [&_span:nth-child(2)]:[height:72%] [&_span:nth-child(3)]:[height:56%] [&_span:nth-child(4)]:[height:86%]">
          <span />
          <span />
          <span />
          <span />
        </div>
      </div>
    );
  }

  return (
    <div className="[position:relative] [min-height:430px] [padding:28px] [border-radius:34px] [overflow:hidden] [transition:0.3s_ease] hover:[transform:translateY(-8px)_scale(1.01)] max-[640px]:[min-height:360px] [background:rgba(255,_255,_255,_0.72)] [border:1px_solid_rgba(255,_255,_255,_0.78)] [box-shadow:0_24px_70px_rgba(123,_63,_242,_0.13)] [-webkit-backdrop-filter:blur(22px)] [backdrop-filter:blur(22px)] [display:grid] [place-items:center] [text-align:center] [&_strong]:[display:block] [&_strong]:[margin-top:18px] [&_strong]:[color:#111827] [&_strong]:[font-size:1.35rem] [&_p]:[color:#4b5563]">
      <div className="[width:160px] [height:160px] [border-radius:50%] [display:grid] [place-items:center] [color:white] [background:radial-gradient(circle,_#7b3ff2_52%,_transparent_53%),_conic-gradient(#ff5ca8_0_82%,_rgba(255,_255,_255,_0.4)_82%_100%)] [font-size:2.5rem] [font-weight:900] [box-shadow:0_28px_70px_rgba(123,_63,_242,_0.24)]">
        98%
      </div>
      <div>
        <strong>Monthly Care Report</strong>
        <p>Wellbeing stable · Family updated · Support active</p>
      </div>
      <div className="[display:flex] [gap:10px] [margin-top:18px] [&_span]:[width:64px] [&_span]:[height:10px] [&_span]:[border-radius:999px] [&_span]:[background:linear-gradient(135deg,_#7b3ff2,_#ff5ca8)]">
        <span />
        <span />
        <span />
        <span />
      </div>
    </div>
  );
}

function JourneyContent({ step }) {
  return (
    <>
      <div
        className="
        flex h-24 w-24
        items-center justify-center
        rounded-[32px]
        bg-gradient-to-br
        from-violet-600
        via-pink-500
        to-orange-400
        text-4xl
        font-black
        text-white
        shadow-[0_30px_70px_rgba(123,63,242,0.25)]
      "
      >
        {step.number}
      </div>

      <h2
        className="
        mt-8
        max-w-none
        font-serif
        lg:text-[72px]
        text-[48px]
        leading-[0.9]
        tracking-[-0.04em]
        text-[#091126]
      "
      >
        {step.title}
      </h2>

      <p
        className="
        mt-6
        max-w-[58ch]
        text-lg
        leading-9
        text-slate-600
      "
      >
        {step.text}
      </p>

      <div className="mt-8 flex flex-wrap gap-3">
        {step.pills.map((pill) => (
          <span
            key={pill}
            className="
            rounded-full
            border
            border-violet-100
            bg-white/70
            px-5
            py-3
            text-sm
            font-semibold
            text-violet-700
          "
          >
            {pill}
          </span>
        ))}
      </div>
    </>
  );
}

function HowItWorks() {
  return (
    <div className="pt-[10px]">
      <section className="[position:relative] [width:min(1440px,_calc(100%_-_36px))] [margin:48px_auto_0] [padding:54px_0_110px] [overflow:hidden] max-[640px]:[width:min(100%_-_20px,_520px)]">
        <div className="[position:absolute] [z-index:0] [border-radius:50%] [filter:blur(42px)] [opacity:0.55] [width:420px] [height:420px] [top:120px] [left:-120px] [background:rgba(255,_92,_168,_0.28)]" />
        <div className="[position:absolute] [z-index:0] [border-radius:50%] [filter:blur(42px)] [opacity:0.55] [width:520px] [height:520px] [right:-150px] [top:780px] [background:rgba(123,_63,_242,_0.22)]" />

        <div className="[position:relative] [z-index:2] [max-width:980px] [margin:0_auto_80px] [text-align:center] [&_h1]:[margin:14px_0_18px] [&_h1]:[font-family:Cormorant_Garamond_serif] [&_h1]:[color:#080f2a] [&_h1]:[font-size:clamp(3.5rem,_6vw,_6.5rem)] [&_h1]:[line-height:0.86] [&_p]:[max-width:760px] [&_p]:[margin:0_auto] [&_p]:[color:#374151] [&_p]:[font-size:1.12rem] [&_p]:[line-height:1.85] max-[640px]:[&_h1]:[font-size:3.8rem]">
          <span className="[color:#7b3ff2] [font-size:0.78rem] [font-weight:800] [letter-spacing:0.14em] [text-transform:uppercase]">
            How It Works
          </span>
          <h1>
            From the first call to{" "}
            <span className="bg-gradient-to-br from-[#7b3ff2] via-[#ff5ca8] to-[#ff9b54] bg-clip-text text-transparent">
              continuous family care.
            </span>
          </h1>
          <p>
            A cinematic care journey designed to help NRIs stay emotionally
            close, operationally informed and deeply reassured about their
            parents in India.
          </p>
        </div>

        <div className="relative z-10 mx-auto max-w-[1440px]">
          {/* Timeline Spine */}
          <div
            className="
      hidden lg:block
      absolute
      left-1/2
      top-0
      bottom-0
      w-px
      bg-gradient-to-b
      from-transparent
      via-violet-300/40
      to-transparent
      -translate-x-1/2
    "
          />

          <div className="space-y-32">
            {journeySteps.map((step, index) => (
              <section
                key={step.number}
                className={`
        grid items-center gap-12
        lg:grid-cols-[0.85fr_1.15fr]
      `}
              >
                {/* ODD STEPS */}
                {(index + 1) % 2 !== 0 ? (
                  <>
                    <div className="max-w-[650px]">
                      <JourneyContent step={step} />
                    </div>

                    <div className="w-full">
                      <VisualMockup type={step.visual} />
                    </div>
                  </>
                ) : (
                  <>
                    <div className="order-2 lg:order-1">
                      <VisualMockup type={step.visual} />
                    </div>

                    <div className="order-1 lg:order-2 max-w-[650px] lg:ml-auto">
                      <JourneyContent step={step} />
                    </div>
                  </>
                )}
              </section>
            ))}
          </div>
        </div>

        <section className="mt-32 text-center">
          <h2
            className="
      mx-auto
      max-w-none
      font-serif
      text-[clamp(2.75rem,4vw,3.75rem)]
      leading-[1.08]
      tracking-[-0.02em]
      text-[#091126]
    "
          >
            Even from thousands of miles away,
            <br />
            you remain connected.
          </h2>

          <p
            className="
      mx-auto
      mt-8
      max-w-[650px]
      text-lg
      leading-relaxed
      text-slate-600
    "
          >
            Begin a care journey that keeps your parents safe, loved and never
            alone.
          </p>

          <Link
            to="/pricing"
            className="
      inline-block
      mt-10
      rounded-[20px]
      bg-gradient-to-r
      from-violet-600
      via-pink-500
      to-orange-400
      px-10
      py-4
      text-base
      font-semibold
      text-white
      shadow-lg
      transition-all
      duration-300
      hover:-translate-y-1
    "
          >
            Start Care Journey
          </Link>
        </section>
      </section>
    </div>
  );
}

export default HowItWorks;

import { useState, useEffect, useRef } from "react";
import API from "@api/axios";
import toast from "react-hot-toast";

const MONTHS = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];
const DAYS = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];

const gradientText = {
  background: "linear-gradient(135deg, #7b3ff2, #ff5ca8, #ff9b54)",
  WebkitBackgroundClip: "text",
  backgroundClip: "text",
  color: "transparent",
};

function DatePicker({ onChange }) {
  const now = new Date();
  const tY = now.getFullYear(),
    tM = now.getMonth(),
    tD = now.getDate();
  const [open, setOpen] = useState(false);
  const [vY, setVY] = useState(tY);
  const [vM, setVM] = useState(tM);
  const [yearDrop, setYearDrop] = useState(false);
  const wrap = useRef(null);
  const yearRef = useRef(null);
  const [confirmed, setConfirmed] = useState(null);

  useEffect(() => {
    const h = (e) => {
      if (wrap.current && !wrap.current.contains(e.target)) {
        setOpen(false);
        setYearDrop(false);
      }
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);

  useEffect(() => {
    if (yearDrop && yearRef.current) {
      const a = yearRef.current.querySelector("[data-active=true]");
      if (a) a.scrollIntoView({ block: "center" });
    }
  }, [yearDrop]);

  const goMonth = (dir) => {
    let m = vM + dir,
      y = vY;
    if (m > 11) {
      m = 0;
      y++;
    }
    if (m < 0) {
      m = 11;
      y--;
    }
    if (y < tY || (y === tY && m < tM)) return;
    setVM(m);
    setVY(y);
  };

  const canBack = vY > tY || (vY === tY && vM > tM);

  const handleDateClick = (e, d) => {
    e.preventDefault();
    e.stopPropagation();

    const selected = {
      y: vY,
      m: vM,
      d,
    };

    setConfirmed(selected);

    onChange(
      `${selected.y}-${String(selected.m + 1).padStart(2, "0")}-${String(selected.d).padStart(2, "0")}`,
    );

    setOpen(false);
  };

  const renderGrid = () => {
    const first = new Date(vY, vM, 1).getDay();
    const total = new Date(vY, vM + 1, 0).getDate();
    const cells = [];
    for (let i = 0; i < first; i++) cells.push(<div key={`e${i}`} />);
    for (let d = 1; d <= total; d++) {
      const past =
        vY < tY || (vY === tY && vM < tM) || (vY === tY && vM === tM && d < tD);
      const isToday = vY === tY && vM === tM && d === tD;
      const isConf =
        confirmed?.y === vY && confirmed?.m === vM && confirmed?.d === d;
      const dd = d;
      cells.push(
        <div
          key={d}
          onMouseDown={past ? undefined : (e) => handleDateClick(e, dd)}
          style={{
            height: 32,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            borderRadius: 6,
            fontSize: 13,
            cursor: past ? "default" : "pointer",
            fontWeight: isConf ? 700 : 400,
            background: isConf
              ? "linear-gradient(135deg,#8b5cf6,#ec4899)"
              : isToday
                ? "#f3e8ff"
                : "transparent",
            color: isConf
              ? "#fff"
              : past
                ? "#d1d5db"
                : isToday
                  ? "#7c3aed"
                  : "#374151",
            userSelect: "none",
          }}
          onMouseEnter={(e) => {
            if (!past && !isConf) e.currentTarget.style.background = "#f3e8ff";
          }}
          onMouseLeave={(e) => {
            if (!past && !isConf)
              e.currentTarget.style.background = isToday
                ? "#f3e8ff"
                : "transparent";
          }}
        >
          {d}
        </div>,
      );
    }
    return cells;
  };

  const displayText = confirmed
    ? new Date(confirmed.y, confirmed.m, confirmed.d).toLocaleDateString(
        "en-IN",
        { weekday: "short", day: "numeric", month: "short", year: "numeric" },
      )
    : "Select date";

  const years = Array.from({ length: 100 }, (_, i) => tY + i);

  return (
    <div ref={wrap} style={{ position: "relative", width: "100%" }}>
      {/* Trigger */}
      <div
        onMouseDown={(e) => {
          e.preventDefault();
          e.stopPropagation();
          setOpen((o) => !o);
          setYearDrop(false);
        }}
        style={{
          width: "100%",
          height: 54,
          padding: "0 16px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          border: open ? "1px solid rgba(123,63,242,0.5)" : "1px solid #e2e8f0",
          borderRadius: 16,
          background: "rgba(255,255,255,0.8)",
          cursor: "pointer",
          boxSizing: "border-box",
          boxShadow: open ? "0 0 0 4px rgba(123,63,242,0.1)" : "none",
          transition: "all 0.15s ease",
        }}
      >
        <span
          style={{ fontSize: 15, color: confirmed ? "#1f2937" : "#9ca3af" }}
        >
          {displayText}
        </span>
        <svg
          width="16"
          height="16"
          viewBox="0 0 24 24"
          fill="none"
          stroke="#7b3ff2"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <rect x="3" y="4" width="18" height="18" rx="2" />
          <line x1="16" y1="2" x2="16" y2="6" />
          <line x1="8" y1="2" x2="8" y2="6" />
          <line x1="3" y1="10" x2="21" y2="10" />
        </svg>
      </div>

      {open && (
        <div
          onMouseDown={(e) => e.stopPropagation()}
          style={{
            position: "absolute",
            top: 60,
            left: 0,
            zIndex: 9999,
            background: "#fff",
            borderRadius: 14,
            border: "1px solid #e9d5ff",
            boxShadow: "0 12px 32px rgba(123,63,242,0.18)",
            padding: "12px 10px 10px",
            width: 250,
          }}
        >
          {/* Header */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              marginBottom: 8,
            }}
          >
            <span
              onMouseDown={(e) => {
                e.preventDefault();
                e.stopPropagation();
                goMonth(-1);
              }}
              style={{
                width: 28,
                height: 28,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: 20,
                cursor: canBack ? "pointer" : "default",
                color: canBack ? "#7c3aed" : "#d1d5db",
                userSelect: "none",
                lineHeight: 1,
              }}
            >
              ‹
            </span>

            <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
              <span style={{ fontSize: 13, fontWeight: 600, color: "#1f2937" }}>
                {MONTHS[vM]}
              </span>
              <div style={{ position: "relative" }}>
                <span
                  onMouseDown={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    setYearDrop((y) => !y);
                  }}
                  style={{
                    background: "#f3e8ff",
                    borderRadius: 4,
                    padding: "2px 7px",
                    fontSize: 12,
                    fontWeight: 600,
                    color: "#7c3aed",
                    cursor: "pointer",
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 3,
                    userSelect: "none",
                  }}
                >
                  {vY} <span style={{ fontSize: 8 }}>▾</span>
                </span>
                {yearDrop && (
                  <div
                    ref={yearRef}
                    style={{
                      position: "absolute",
                      top: 26,
                      left: 0,
                      background: "#fff",
                      border: "1px solid #e9d5ff",
                      borderRadius: 7,
                      zIndex: 10,
                      maxHeight: 140,
                      overflowY: "auto",
                      minWidth: 64,
                      boxShadow: "0 4px 14px rgba(139,92,246,0.12)",
                    }}
                  >
                    {years.map((y) => (
                      <div
                        key={y}
                        data-active={y === vY}
                        onMouseDown={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          let nm = vM;
                          if (y === tY && nm < tM) nm = tM;
                          setVY(y);
                          setVM(nm);
                          setYearDrop(false);
                        }}
                        style={{
                          padding: "4px 10px",
                          fontSize: 12,
                          cursor: "pointer",
                          background: y === vY ? "#7c3aed" : "#fff",
                          color: y === vY ? "#fff" : "#374151",
                          fontWeight: y === vY ? 600 : 400,
                        }}
                      >
                        {y}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <span
              onMouseDown={(e) => {
                e.preventDefault();
                e.stopPropagation();
                goMonth(1);
              }}
              style={{
                width: 28,
                height: 28,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: 20,
                cursor: "pointer",
                color: "#7c3aed",
                userSelect: "none",
                lineHeight: 1,
              }}
            >
              ›
            </span>
          </div>

          {/* Day names */}
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(7,1fr)",
              marginBottom: 4,
            }}
          >
            {DAYS.map((d) => (
              <div
                key={d}
                style={{
                  textAlign: "center",
                  fontSize: 10,
                  fontWeight: 600,
                  color: "#a78bfa",
                  padding: "2px 0",
                }}
              >
                {d}
              </div>
            ))}
          </div>

          {/* Days grid */}
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(7,1fr)",
              gap: 2,
            }}
          >
            {renderGrid()}
          </div>
        </div>
      )}
    </div>
  );
}

const benefits = [
  "Personalized guidance",
  "Understand care plans",
  "All your questions answered",
  "No obligation",
];

function Booking() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    preferredDate: "",
    preferredTime: "",
    careNeed: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (isSubmitting) return;
    try {
      setIsSubmitting(true);
      const { data } = await API.post("/booking", formData);
      toast.success(data.message);
      setFormData({
        name: "",
        email: "",
        phone: "",
        preferredDate: "",
        preferredTime: "",
        careNeed: "",
      });
    } catch (error) {
      toast.error(error.response?.data?.message || "Failed to submit booking");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="pt-[10px]">
      <section className="[width:min(1360px,_calc(100%_-_36px))] [margin:48px_auto_0] [padding:48px_0_96px] max-[640px]:[width:min(100%_-_20px,_520px)] max-[640px]:[padding-left:4px] max-[640px]:[padding-right:4px]">
        <div className="[display:grid] [grid-template-columns:0.9fr_1.1fr] [gap:42px] [align-items:center] max-[980px]:[grid-template-columns:1fr]">
          {/* LEFT COPY */}
          <div>
            <span className="[color:#7b3ff2] [font-size:0.78rem] [font-weight:800] [letter-spacing:0.14em] [text-transform:uppercase]">
              Book Free Call
            </span>
            <h1 className="[margin:12px_0_18px] [font-family:Cormorant_Garamond_serif] [color:#0b1026] [font-size:clamp(3.4rem,_5.2vw,_6.2rem)] [line-height:0.9]">
              Book a free call with{" "}
              <span style={gradientText}>a care expert</span>
            </h1>
            <p className="[color:#374151] [font-size:1.08rem] [line-height:1.8]">
              Talk to our care expert and discover the best care plan for your
              parents, elders or property needs in India.
            </p>

            <div className="[display:grid] [gap:14px] [margin-top:28px]">
              {benefits.map((b) => (
                <span key={b} className="[color:#111827] [font-weight:800]">
                  <span style={{ marginRight: "10px", color: "#16a34a" }}>
                    ✓
                  </span>
                  {b}
                </span>
              ))}
            </div>
          </div>

          {/* RIGHT FORM */}
          <form
            onSubmit={handleSubmit}
            className="[padding:34px] [border-radius:32px] [background:rgba(255,_255,_255,_0.72)] [border:1px_solid_rgba(255,_255,_255,_0.78)] [box-shadow:0_24px_70px_rgba(123,_63,_242,_0.13)] [-webkit-backdrop-filter:blur(22px)] [backdrop-filter:blur(22px)]"
          >
            <h2 className="[margin:0_0_24px] [color:#111827]">
              Choose a Date & Time
            </h2>

            {/* Name + Phone row */}
            <div className="[display:grid] [grid-template-columns:1fr_1fr] [gap:14px] [margin-bottom:0] max-[640px]:[grid-template-columns:1fr]">
              <label className="[display:grid] [gap:8px] [margin-bottom:16px] [color:#374151] [font-weight:800]">
                Your Name
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                  placeholder="Enter your name"
                  className="[width:100%] [border:1px_solid_rgba(123,_63,_242,_0.14)] [border-radius:18px] [padding:16px_18px] [color:#111827] [background:rgba(255,_255,_255,_0.74)] [outline:none] focus:[border-color:rgba(123,_63,_242,_0.5)] focus:[box-shadow:0_0_0_4px_rgba(123,_63,_242,_0.08)]"
                />
              </label>
              <label className="[display:grid] [gap:8px] [margin-bottom:16px] [color:#374151] [font-weight:800]">
                Phone Number
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) =>
                    setFormData({ ...formData, phone: e.target.value })
                  }
                  placeholder="Enter phone number"
                  className="[width:100%] [border:1px_solid_rgba(123,_63,_242,_0.14)] [border-radius:18px] [padding:16px_18px] [color:#111827] [background:rgba(255,_255,_255,_0.74)] [outline:none] focus:[border-color:rgba(123,_63,_242,_0.5)] focus:[box-shadow:0_0_0_4px_rgba(123,_63,_242,_0.08)]"
                />
              </label>
            </div>

            {/* Email */}
            <label className="[display:grid] [gap:8px] [margin-bottom:16px] [color:#374151] [font-weight:800]">
              Email Address
              <input
                type="email"
                value={formData.email}
                onChange={(e) =>
                  setFormData({ ...formData, email: e.target.value })
                }
                placeholder="Enter your email"
                className="[width:100%] [border:1px_solid_rgba(123,_63,_242,_0.14)] [border-radius:18px] [padding:16px_18px] [color:#111827] [background:rgba(255,_255,_255,_0.74)] [outline:none] focus:[border-color:rgba(123,_63,_242,_0.5)] focus:[box-shadow:0_0_0_4px_rgba(123,_63,_242,_0.08)]"
              />
            </label>

            {/* Date + Time row */}
            <div className="[display:grid] [grid-template-columns:1fr_1fr] [gap:14px] max-[640px]:[grid-template-columns:1fr]">
              <label className="[display:grid] [gap:8px] [margin-bottom:16px] [color:#374151] [font-weight:800]">
                Preferred Date
                <DatePicker
                  // value={formData.preferredDate}
                  onChange={(val) =>
                    setFormData({ ...formData, preferredDate: val })
                  }
                />
              </label>
              <label className="[display:grid] [gap:8px] [margin-bottom:16px] [color:#374151] [font-weight:800]">
                Preferred Time
                <select
                  value={formData.preferredTime}
                  onChange={(e) =>
                    setFormData({ ...formData, preferredTime: e.target.value })
                  }
                  className="[width:100%] [border:1px_solid_rgba(123,_63,_242,_0.14)] [border-radius:18px] [padding:16px_18px] [color:#111827] [background:rgba(255,_255,_255,_0.74)] [outline:none] focus:[border-color:rgba(123,_63,_242,_0.5)] focus:[box-shadow:0_0_0_4px_rgba(123,_63,_242,_0.08)]"
                >
                  <option value="">Select time</option>
                  <option value="09:00 AM - 11:00 AM">
                    09:00 AM - 11:00 AM
                  </option>
                  <option value="11:00 AM - 01:00 PM">
                    11:00 AM - 01:00 PM
                  </option>
                  <option value="03:00 PM - 05:00 PM">
                    03:00 PM - 05:00 PM
                  </option>
                  <option value="06:00 PM - 08:00 PM">
                    06:00 PM - 08:00 PM
                  </option>
                </select>
              </label>
            </div>

            {/* Care Need */}
            <label className="[display:grid] [gap:8px] [margin-bottom:16px] [color:#374151] [font-weight:800]">
              Care Need
              <select
                value={formData.careNeed}
                onChange={(e) =>
                  setFormData({ ...formData, careNeed: e.target.value })
                }
                className="[width:100%] [border:1px_solid_rgba(123,_63,_242,_0.14)] [border-radius:18px] [padding:16px_18px] [color:#111827] [background:rgba(255,_255,_255,_0.74)] [outline:none] focus:[border-color:rgba(123,_63,_242,_0.5)] focus:[box-shadow:0_0_0_4px_rgba(123,_63,_242,_0.08)]"
              >
                <option value="">Select care need</option>
                <option value="Parent care">Parent care</option>
                <option value="Emergency care">Emergency care</option>
                <option value="Health & wellness">Health & wellness</option>
                <option value="Property care">Property care</option>
                <option value="Complete family support">
                  Complete family support
                </option>
              </select>
            </label>

            <button
              type="submit"
              disabled={isSubmitting}
              className="[width:100%] [min-height:58px] [border:0] [border-radius:18px] [color:white] [background:linear-gradient(135deg,_#7b3ff2,_#ff5ca8,_#ff9b54)] [font-weight:900] [box-shadow:0_18px_38px_rgba(123,_63,_242,_0.22)] disabled:[opacity:0.7] disabled:[cursor:not-allowed]"
            >
              {isSubmitting ? "Submitting..." : "Book My Free Call"}
            </button>
            <p className="[margin:16px_0_0] [color:#6b7280] [text-align:center] [font-size:0.9rem] [font-weight:700]">
              100% secure and confidential
            </p>
          </form>
        </div>
      </section>
    </div>
  );
}

export default Booking;

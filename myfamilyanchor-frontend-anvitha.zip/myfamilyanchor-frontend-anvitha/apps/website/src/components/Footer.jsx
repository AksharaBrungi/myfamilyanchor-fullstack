import { useState } from "react";
import toast from "react-hot-toast";
import { Link } from "react-router-dom";
import {
  FaFacebookF,
  FaLinkedinIn,
  FaInstagram,
  FaXTwitter,
} from "react-icons/fa6";
import API from "@api/axios";
import logo from "@assets/logonbg.png";

function Footer() {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogoClick = () => {
    if (window.location.pathname === "/") {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const handleSubscribe = async () => {
    if (!email.trim()) {
      toast.error("Please enter your email");
      return;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      toast.error("Please enter a valid email address");
      return;
    }
    try {
      setLoading(true);
      const { data } = await API.post("/subscribe", { email });
      toast.success(data.message || "Subscribed successfully!");
      setEmail("");
    } catch (error) {
      toast.error(
        error.response?.data?.message ||
          "Unable to subscribe. Please try again.",
      );
    } finally {
      setLoading(false);
    }
  };

  const socialLinks = [
    { href: "https://facebook.com/myfamilyanchor", icon: <FaFacebookF /> },
    { href: "https://linkedin.com/in/myfamilyanchor", icon: <FaLinkedinIn /> },
    { href: "https://instagram.com/myfamilyanchor", icon: <FaInstagram /> },
    { href: "https://x.com/myfamilyanchor", icon: <FaXTwitter /> },
  ];

  return (
    <footer
      className="relative mt-10 overflow-hidden pt-16 pb-7 text-white"
      style={{
        background:
          "radial-gradient(circle at 16% 20%, rgba(255,92,168,0.28), transparent 26%), radial-gradient(circle at 84% 8%, rgba(255,155,84,0.22), transparent 28%), linear-gradient(135deg, #10071f, #25104b 52%, #471d6f)",
      }}
    >
      {/* Decorative blob */}
      <div
        className="pointer-events-none absolute -right-32 -bottom-44 h-96 w-96 rounded-full"
        style={{
          background: "rgba(255,92,168,0.22)",
          filter: "blur(32px)",
        }}
      />

      {/* ── Main grid ──
          Desktop  (>900px) : 3 cols  — brand | links | subscribe
          Tablet (601-900px) : 2 cols  — brand spans full top row; links + subscribe below
          Mobile  (≤600px)  : 1 col stack
      */}
      <div
        className="
          relative z-10
          mx-auto w-full max-w-[1320px] px-5
          grid gap-x-14 gap-y-10
          grid-cols-1
          sm:grid-cols-2
          lg:grid-cols-[1.35fr_1fr_1.05fr]
        "
      >
        {/* ── Zone 1: Brand ── */}
        {/* sm: spans both columns so links+subscribe sit below */}
        <div className="sm:col-span-2 lg:col-span-1">
          <Link
            to="/"
            onClick={handleLogoClick}
            className="flex items-center gap-3 no-underline"
          >
            <img
              src={logo}
              alt="MyFamilyAnchor"
              className="h-12 w-12 flex-shrink-0 object-contain"
            />
            <span className="flex flex-col gap-0.5">
              <strong
                className="font-serif text-2xl font-bold tracking-tight text-white"
                style={{ fontFamily: "Georgia, 'Times New Roman', serif" }}
              >
                MyFamily<span className="text-[#ff9b54]">Anchor</span>
              </strong>
              <small className="text-[10px] font-bold uppercase tracking-[0.14em] text-white/75">
                Care that connects hearts
              </small>
            </span>
          </Link>

          <p className="mt-5 mb-5 max-w-xs text-sm leading-relaxed text-white/70 sm:max-w-full lg:max-w-xs">
            A premium NRI parent care and family support platform helping
            families abroad keep loved ones in India safe, cared for and never
            alone.
          </p>

          <div className="flex flex-wrap gap-2.5">
            {socialLinks.map(({ href, icon }) => (
              <a
                key={href}
                href={href}
                target="_blank"
                rel="noreferrer"
                className="
                  grid h-9 w-9 place-items-center rounded-xl
                  bg-white/10 text-white no-underline
                  transition-all duration-250
                  hover:-translate-y-1
                  hover:shadow-[0_12px_24px_rgba(255,92,168,0.28)]
                "
                style={{ transition: "all 0.25s ease" }}
                onMouseEnter={(e) =>
                  (e.currentTarget.style.background =
                    "linear-gradient(135deg,#7b3ff2,#ff5ca8,#ff9b54)")
                }
                onMouseLeave={(e) =>
                  (e.currentTarget.style.background = "rgba(255,255,255,0.10)")
                }
              >
                {icon}
              </a>
            ))}
          </div>
        </div>

        {/* ── Zone 2: Links — Company + Care always side by side ── */}
        <div className="grid grid-cols-2 gap-x-12 content-start">
          {/* Company */}
          <div className="flex flex-col gap-1">
            <h3 className="mb-4 text-[13px] font-black uppercase tracking-[0.12em] text-white">
              Company
            </h3>
            {[
              "About Us|/about",
              "Services|/services",
              "Pricing|/pricing",
              "Contact|/contact",
              "Cities|/cities",
            ].map((item) => {
              const [label, to] = item.split("|");
              return (
                <Link
                  key={to}
                  to={to}
                  className="py-[2px] text-[15px] font-medium text-white/70 no-underline transition-all duration-200 hover:translate-x-0.5 hover:text-white"
                >
                  {label}
                </Link>
              );
            })}
          </div>

          {/* Care */}
          <div className="flex flex-col gap-1">
            <h3 className="mb-4 text-[13px] font-black uppercase tracking-[0.12em] text-white">
              Care
            </h3>
            {[
              ["Health & Wellness", "/services"],
              ["Emergency Care", "/services"],
              ["Companionship", "/services"],
              ["Property Care", "/services"],
              ["Stay Support", "/services"],
            ].map(([label, to]) => (
              <Link
                key={label}
                to={to}
                className="py-[2px] text-[15px] font-medium text-white/70 no-underline transition-all duration-200 hover:translate-x-0.5 hover:text-white"
              >
                {label}
              </Link>
            ))}
          </div>
        </div>

        {/* ── Zone 3: Stay Connected ── */}
        <div className="flex flex-col gap-3">
          <h3 className="mb-4 text-[13px] font-black uppercase tracking-[0.12em] text-white">
            Stay Connected
          </h3>
          <p className="text-sm leading-relaxed text-white/70">
            Get family care insights and updates for NRI families.
          </p>

          <div className="mt-1 flex gap-2 rounded-[18px] border border-white/10 bg-white/10 py-1.5 pl-3.5 pr-1.5">
            <input
              type="email"
              placeholder="Email address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSubscribe()}
              className="min-w-0 flex-1 border-0 bg-transparent text-sm text-white outline-none placeholder:text-white/45"
              style={{ colorScheme: "dark" }}
            />
            <button
              type="button"
              onClick={handleSubscribe}
              disabled={loading}
              className="shrink-0 cursor-pointer rounded-xl border-0 px-5 py-2.5 text-sm font-bold text-white transition-opacity duration-200 disabled:cursor-not-allowed disabled:opacity-60"
              style={{
                background: "linear-gradient(135deg, #ff5ca8, #ff9b54)",
              }}
            >
              {loading ? "Joining…" : "Join"}
            </button>
          </div>
        </div>
      </div>

      {/* ── Bottom bar ── */}
      <div
        className="
          relative z-10 mx-auto mt-12 flex w-full max-w-[1320px] flex-wrap
          items-center justify-between gap-4 border-t border-white/10 px-5 pt-5
          text-[13px] text-white/75
          flex-col items-start
          sm:flex-row sm:items-center
        "
      >
        <span>© 2026 MyFamilyAnchor. All rights reserved.</span>
        <div className="flex items-center gap-3">
          <Link to="/privacy">Privacy Policy</Link>
          <span className="text-white/25">|</span>
          <Link to="/terms">Terms</Link>
          <span className="text-white/25">|</span>
          <Link to="/safety">Safety Standards</Link>
        </div>
      </div>
    </footer>
  );
}

export default Footer;

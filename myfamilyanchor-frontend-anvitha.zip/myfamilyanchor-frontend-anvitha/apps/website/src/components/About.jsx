import { heroSM, gradientText } from "@ui/heroTypography";
import heroImage from "@assets/hero.png";

const highlights = [
  "Founded in Hyderabad in 2026 for NRI families living abroad",
  "Support for parents, elders, homes, tenants, repairs and emergencies",
  "Verified staff and vendor coordination on the ground",
  "Transparent updates with service notes, photos and completion approval",
];

const trustPillars = [
  {
    title: "Human Care Network",
    text: "Our local teams and verified partners help with elder care, wellness visits, doctor appointments, medicine coordination, property inspections, repairs and emergency support.",
  },
  {
    title: "Digital Tracking",
    text: "Families can submit requests, follow service progress, receive updates and review proof from anywhere in the world.",
  },
  {
    title: "Verified Completion",
    text: "Service work is documented with notes, photos, staff/vendor updates and final approval, so families have clarity before a task is closed.",
  },
];

const serviceAreas = [
  {
    title: "Family and elder care",
    symbol: "\u2665",
    tone: "linear-gradient(135deg, #ff5ca8, #ff9b54)",
  },
  {
    title: "Property management",
    symbol: "\u2302",
    tone: "linear-gradient(135deg, #7b3ff2, #5b8cff)",
  },
  {
    title: "Emergency coordination",
    symbol: "\u26a1",
    tone: "linear-gradient(135deg, #ff9b54, #f59e0b)",
  },
  {
    title: "Premium concierge support",
    symbol: "\u2726",
    tone: "linear-gradient(135deg, #0b1026, #7b3ff2)",
  },
];

const processSteps = [
  "Raise service request",
  "Assign verified team",
  "Track live progress",
  "Review proof and approval",
];

function About() {
  return (
    <div className="pt-[35px]">
      <section className="[width:min(1280px,_calc(100%_-_36px))] [margin:40px_auto_0] [padding:32px_0_92px] max-[640px]:[width:min(100%_-_20px,_520px)]">
        <div className="[display:grid] [grid-template-columns:1.05fr_0.95fr] [gap:34px] [align-items:stretch] max-[980px]:[grid-template-columns:1fr]">
          {/* ── LEFT COPY PANEL ── */}
          <div className="[padding:42px] [border-radius:28px] [background:rgba(255,_255,_255,_0.82)] [border:1px_solid_rgba(255,_255,_255,_0.86)] [box-shadow:0_24px_70px_rgba(123,_63,_242,_0.11)] [-webkit-backdrop-filter:blur(20px)] [backdrop-filter:blur(20px)] max-[640px]:[padding:28px_20px]">
            {/* eyebrow */}
            <span className="[display:inline-flex] [align-items:center] [gap:10px] [padding:9px_13px] [border-radius:999px] [background:#f1e9ff] [color:#7b3ff2] [font-size:0.76rem] [font-weight:900] [letter-spacing:0.12em] [text-transform:uppercase] [margin-bottom:20px]">
              About MyFamilyAnchor
            </span>

            {/* hero heading — heroSM already provides margin-bottom:28px */}
            <h1 className={heroSM}>
              Your trusted local family representative in{" "}
              <span style={gradientText}>India</span>
            </h1>

            {/* body copy — no extra top margin needed; heading's mb handles gap */}
            <div className="[display:grid] [gap:16px] [width:min(780px,_100%)]">
              <p className="[margin:0] [color:#374151] [font-size:1.06rem] [line-height:1.85]">
                MyFamilyAnchor was started in Hyderabad in 2026 with a simple
                purpose: to support NRI families who live away from India but
                remain responsible for their parents, elders, homes, tenants,
                repairs, emergencies and local coordination.
              </p>
              <p className="[margin:0] [color:#374151] [font-size:1.06rem] [line-height:1.85]">
                We combine trusted local care teams with a digital platform so
                families abroad can raise service requests, track progress,
                receive timely updates and get verified proof through photos,
                notes and final approvals.
              </p>
            </div>

            {/* highlight chips */}
            <div className="[display:grid] [grid-template-columns:repeat(2,_1fr)] [gap:12px] [margin-top:32px] max-[700px]:[grid-template-columns:1fr]">
              {highlights.map((point) => (
                <div
                  key={point}
                  className="[display:flex] [gap:11px] [align-items:flex-start] [padding:16px] [border-radius:16px] [background:#ffffff] [border:1px_solid_rgba(123,_63,_242,_0.1)] [box-shadow:0_12px_30px_rgba(15,_23,_42,_0.05)]"
                >
                  <span className="[display:grid] [place-items:center] [width:24px] [height:24px] [border-radius:999px] [background:#ecfdf5] [color:#16a34a] [font-size:0.9rem] [font-weight:900] [flex:0_0_auto]">
                    {"\u2713"}
                  </span>
                  <span className="[color:#111827] [font-size:0.95rem] [font-weight:800] [line-height:1.45]">
                    {point}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* ── RIGHT ASIDE ── */}
          <aside className="[display:grid] [grid-template-rows:auto_1fr] [gap:16px]">
            <div className="[position:relative] [min-height:360px] [overflow:hidden] [border-radius:28px] [background:#111827] [box-shadow:0_24px_70px_rgba(11,_16,_38,_0.16)] max-[640px]:[min-height:320px]">
              <img
                src={heroImage}
                alt="Smiling elderly Indian parents"
                className="[width:100%] [height:100%] [object-fit:cover] [position:absolute] [inset:0]"
              />
              <div className="[position:absolute] [inset:0] [background:linear-gradient(180deg,_rgba(11,_16,_38,_0.04),_rgba(11,_16,_38,_0.58))]" />
              <div className="[position:absolute] [left:22px] [right:22px] [bottom:22px] [padding:20px] [border-radius:20px] [background:rgba(255,_255,_255,_0.92)] [box-shadow:0_18px_48px_rgba(11,_16,_38,_0.22)] [-webkit-backdrop-filter:blur(18px)] [backdrop-filter:blur(18px)]">
                <strong className="[display:block] [color:#0b1026] [font-size:1.55rem] [line-height:1]">
                  Founded 2026
                </strong>
                <p className="[margin:8px_0_0] [color:#4b5563] [line-height:1.55]">
                  Built from Hyderabad for NRI families who need dependable
                  support back home.
                </p>
              </div>
            </div>

            <div className="[position:relative] [overflow:hidden] [padding:24px] [border-radius:24px] [background:linear-gradient(135deg,_#ffffff_0%,_#fff7ed_48%,_#f7f0ff_100%)] [border:1px_solid_rgba(245,_158,_11,_0.2)] [box-shadow:0_24px_70px_rgba(123,_63,_242,_0.12)]">
              <div className="[position:absolute] [right:-54px] [top:-54px] [width:150px] [height:150px] [border-radius:999px] [background:rgba(255,_155,_84,_0.16)]" />
              <span className="[color:#b45309] [font-size:0.74rem] [font-weight:900] [letter-spacing:0.12em] [text-transform:uppercase]">
                How trust is created
              </span>
              <div className="[display:grid] [gap:12px] [margin-top:18px]">
                {processSteps.map((step, index) => (
                  <div
                    key={step}
                    className="[display:flex] [align-items:center] [gap:12px]"
                  >
                    <span className="[display:grid] [place-items:center] [width:34px] [height:34px] [border-radius:12px] [background:linear-gradient(135deg,_#ff9b54,_#7b3ff2)] [color:white] [font-weight:900] [box-shadow:0_10px_24px_rgba(123,_63,_242,_0.22)]">
                      {index + 1}
                    </span>
                    <span className="[color:#111827] [font-weight:900]">
                      {step}
                    </span>
                  </div>
                ))}
              </div>

              <div className="[margin-top:26px] [padding-top:20px] [border-top:1px_solid_rgba(180,_83,_9,_0.14)]">
                <span className="[color:#7b3ff2] [font-size:0.72rem] [font-weight:900] [letter-spacing:0.12em] [text-transform:uppercase]">
                  Service coverage
                </span>
                <div className="[display:grid] [grid-template-columns:repeat(2,_minmax(0,_1fr))] [gap:10px] [margin-top:12px] max-[520px]:[grid-template-columns:1fr]">
                  {serviceAreas.map((area) => (
                    <div
                      key={area.title}
                      className="[display:flex] [align-items:center] [gap:10px] [padding:12px] [border-radius:16px] [background:rgba(255,_255,_255,_0.78)] [border:1px_solid_rgba(123,_63,_242,_0.1)] [box-shadow:0_12px_26px_rgba(123,_63,_242,_0.07)]"
                    >
                      <span
                        className="[display:grid] [place-items:center] [width:36px] [height:36px] [border-radius:13px] [color:white] [font-size:1rem] [font-weight:900] [flex:0_0_auto] [box-shadow:0_10px_22px_rgba(123,_63,_242,_0.18)]"
                        style={{ background: area.tone }}
                      >
                        {area.symbol}
                      </span>
                      <span className="[color:#111827] [font-size:0.86rem] [font-weight:900] [line-height:1.25]">
                        {area.title}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </aside>
        </div>

        {/* ── SECOND ROW: Mission + Trust pillars ── */}
        <div className="[display:grid] [grid-template-columns:0.82fr_1.18fr] [gap:24px] [margin-top:24px] max-[980px]:[grid-template-columns:1fr]">
          <div className="[padding:34px] [border-radius:28px] [background:#ffffff] [border:1px_solid_rgba(123,_63,_242,_0.1)] [box-shadow:0_18px_50px_rgba(123,_63,_242,_0.08)] max-[640px]:[padding:26px_20px]">
            <span className="[color:#7b3ff2] [font-size:0.78rem] [font-weight:900] [letter-spacing:0.14em] [text-transform:uppercase]">
              Our Mission
            </span>
            <h2 className="[margin:12px_0_16px] [font-family:Cormorant_Garamond_serif] [color:#0b1026] [font-size:clamp(2.25rem,_3.4vw,_4.2rem)] [line-height:1.05]">
              To make distance feel less stressful for families abroad.
            </h2>
            <p className="[margin:0] [color:#374151] [font-size:1.03rem] [line-height:1.78]">
              Our mission is to become the trusted local support system for NRIs
              who need reliable care and property management in India. Whether a
              parent needs appointment support, a home needs inspection, or an
              urgent issue needs local coordination, MyFamilyAnchor brings care,
              visibility and accountability into every request.
            </p>
          </div>

          <div className="[padding:34px] [border-radius:28px] [background:rgba(255,_255,_255,_0.76)] [border:1px_solid_rgba(255,_255,_255,_0.86)] [box-shadow:0_18px_50px_rgba(123,_63,_242,_0.08)] [-webkit-backdrop-filter:blur(20px)] [backdrop-filter:blur(20px)] max-[640px]:[padding:26px_20px]">
            <span className="[color:#7b3ff2] [font-size:0.78rem] [font-weight:900] [letter-spacing:0.14em] [text-transform:uppercase]">
              Built on care, visibility and accountability
            </span>
            <div className="[display:grid] [grid-template-columns:repeat(3,_1fr)] [gap:14px] [margin-top:18px] max-[900px]:[grid-template-columns:1fr]">
              {trustPillars.map((pillar) => (
                <article
                  key={pillar.title}
                  className="[padding:22px] [border-radius:18px] [background:#ffffff] [border:1px_solid_rgba(123,_63,_242,_0.1)] [box-shadow:0_12px_30px_rgba(15,_23,_42,_0.05)]"
                >
                  <h3 className="[margin:0_0_10px] [color:#0b1026] [font-size:1.04rem] [font-weight:900]">
                    {pillar.title}
                  </h3>
                  <p className="[margin:0] [color:#4b5563] [line-height:1.68] [font-size:0.96rem]">
                    {pillar.text}
                  </p>
                </article>
              ))}
            </div>
          </div>
        </div>

        {/* ── THIRD ROW: What we stand for ── */}
        <div className="[margin-top:24px]">
          <div className="[position:relative] [overflow:hidden] [padding:38px] [border-radius:28px] [background:linear-gradient(135deg,_#ffffff_0%,_#fff8f2_44%,_#f5edff_100%)] [border:1px_solid_rgba(245,_158,_11,_0.18)] [box-shadow:0_24px_70px_rgba(123,_63,_242,_0.12)] max-[640px]:[padding:26px_20px]">
            <div className="[position:absolute] [right:-70px] [bottom:-80px] [width:260px] [height:260px] [border-radius:999px] [background:rgba(123,_63,_242,_0.08)]" />
            <div className="[display:grid] [grid-template-columns:minmax(0,_0.85fr)_minmax(280px,_0.55fr)] [gap:38px] [align-items:center] max-[900px]:[grid-template-columns:1fr]">
              <div>
                <span className="[color:#b45309] [font-size:0.78rem] [font-weight:900] [letter-spacing:0.14em] [text-transform:uppercase]">
                  What We Stand For
                </span>
                <h2 className="[margin:12px_0_16px] [font-family:Cormorant_Garamond_serif] [color:#0b1026] [font-size:clamp(2.1rem,_3.1vw,_3.5rem)] [line-height:1.05]">
                  Trust that can be seen, tracked and verified.
                </h2>
                <p className="[margin:0] [color:#374151] [line-height:1.75] [font-size:1.03rem]">
                  Families should not have to depend on guesswork when caring
                  for parents or property from another country. We focus on
                  reliable local execution, clear ownership, timely
                  communication and proof-based service completion.
                </p>
              </div>
              <div className="[position:relative] [z-index:1] [padding:22px] [border-radius:22px] [background:rgba(255,_255,_255,_0.72)] [border:1px_solid_rgba(123,_63,_242,_0.1)]">
                <span className="[display:block] [color:#7b3ff2] [font-size:0.76rem] [font-weight:900] [letter-spacing:0.12em] [text-transform:uppercase]">
                  Our promise
                </span>
                <p className="[margin:10px_0_0] [color:#111827] [font-size:1.35rem] [font-weight:900] [line-height:1.25]">
                  Every request should have ownership, proof and a clear next
                  step.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default About;

import { useState } from "react";
import { Link } from "react-router-dom";
import { heroXL, gradientText } from "@ui/heroTypography";

const plans = {
  monthly: [
    {
      name: "Property Guardian",
      price: "₹6,999",
      note: "/month",
      tagline: "For NRIs managing properties remotely",
      cta: "Secure My Property",
      features: [
        "Monthly property inspection reports",
        "Video proof & real-time updates",
        "House cleaning & maintenance support",
        "Repairs and renovation coordination",
        "Tenant management assistance",
        "Emergency property visits",
        "Dedicated support hotline",
      ],
    },
    {
      name: "Family Guardian",
      price: "₹11,999",
      note: "/month",
      tagline: "Complete elder care & wellbeing support",
      popular: true,
      cta: "Protect My Family",
      features: [
        "Weekly home wellness visits",
        "Medicine & appointment reminders",
        "Hospital and doctor visit assistance",
        "Emergency response coordination",
        "Companionship & wellbeing check-ins",
        "Priority family updates",
        "Care activity reports",
      ],
    },
    {
      name: "Guardian Premium",
      price: "₹17,999",
      note: "/month",
      tagline: "All-in-one premium care & property management",
      cta: "Get Premium Support",
      features: [
        "Everything in Property Guardian",
        "Everything in Family Guardian",
        "Dedicated relationship manager",
        "24/7 priority emergency support",
        "Advanced care coordination",
        "Combined family & property monitoring",
        "Airport pickup & travel assistance",
        "Premium concierge support",
      ],
    },
  ],
  yearly: [
    {
      name: "Property Guardian",
      price: "₹71,999",
      note: "/year",
      tagline: "For NRIs managing properties remotely",
      cta: "Secure My Property",
      features: [
        "Monthly property inspection reports",
        "Video proof & real-time updates",
        "House cleaning & maintenance support",
        "Repairs and renovation coordination",
        "Tenant management assistance",
        "Emergency property visits",
        "Dedicated support hotline",
      ],
    },
    {
      name: "Family Guardian",
      price: "₹1,19,999",
      note: "/year",
      tagline: "Complete elder care & wellbeing support",
      popular: true,
      cta: "Protect My Family",
      features: [
        "Weekly home wellness visits",
        "Medicine & appointment reminders",
        "Hospital and doctor visit assistance",
        "Emergency response coordination",
        "Companionship & wellbeing check-ins",
        "Priority family updates",
        "Care activity reports",
      ],
    },
    {
      name: "Guardian Premium",
      price: "₹1,79,999",
      note: "/year",
      tagline: "All-in-one premium care & property management",
      cta: "Get Premium Support",
      features: [
        "Everything in Property Guardian",
        "Everything in Family Guardian",
        "Dedicated relationship manager",
        "24/7 priority emergency support",
        "Advanced care coordination",
        "Combined family & property monitoring",
        "Airport pickup & travel assistance",
        "Premium concierge support",
      ],
    },
  ],
};

function Pricing() {
  const [billing, setBilling] = useState("monthly");

  return (
    <div className="pt-2.5">
      <style>{`
        .pricing-section {
          width: min(1360px, calc(100% - 48px));
          margin: 48px auto 0;
          padding: 48px 0 96px;
        }

        /* ── Hero ── */
        .pricing-hero {
          padding: 72px 64px 60px;
          border-radius: 34px;
          background:
            radial-gradient(circle at 80% 20%, rgba(255,155,84,0.2), transparent 30%),
            radial-gradient(circle at 20% 10%, rgba(255,92,168,0.16), transparent 28%),
            rgba(255,255,255,0.62);
          border: 1px solid rgba(255,255,255,0.82);
          box-shadow: 0 28px 80px rgba(123,63,242,0.1);
          backdrop-filter: blur(18px);
          -webkit-backdrop-filter: blur(18px);
          text-align: center;
        }
        .pricing-hero-eyebrow {
          color: #7b3ff2;
          font-size: 0.78rem;
          font-weight: 800;
          letter-spacing: 0.14em;
          text-transform: uppercase;
          display: block;
          margin-bottom: 16px;
        }
        .pricing-hero h1 {
          font-family: "Cormorant Garamond", serif;
          color: #0b1026;
          font-size: clamp(2.8rem, 6vw, 6.8rem);
          line-height: 0.92;
          margin: 0 auto 24px;
          max-width: 960px;
          width: 100%;
          text-align: center;
        }
        .pricing-hero p {
          max-width: 640px;
          margin: 0 auto;
          color: #374151;
          font-size: 1.08rem;
          line-height: 1.8;
          text-align: center;
        }

        /* ── Trust + Toggle bar ── */
        .pricing-controls {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 24px;
          margin: 36px auto 30px;
          padding: 28px 24px;
          border-radius: 24px;
          backdrop-filter: blur(16px);
          -webkit-backdrop-filter: blur(16px);
          width: min(100%, 960px);
        }
        .trust-indicators {
          display: flex;
          justify-content: center;
          align-items: center;
          flex-wrap: wrap;
          gap: 12px 28px;
          color: #5b6475;
          font-weight: 600;
          font-size: 0.95rem;
          text-align: center;
        }
        .billing-toggle {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 16px;
        }
        .billing-label {
          font-weight: 600;
          transition: color 0.3s;
        }
        .billing-label.active { color: #0f172a; }
        .billing-label.inactive { color: #94a3b8; }
        .toggle-track {
          position: relative;
          width: 62px;
          height: 34px;
          display: block;
        }
        .toggle-track input { display: none; }
        .toggle-thumb {
          position: absolute;
          inset: 0;
          background: #e2e8f0;
          border-radius: 999px;
          cursor: pointer;
          transition: background 0.3s;
        }
        .toggle-thumb::before {
          content: '';
          position: absolute;
          height: 26px;
          width: 26px;
          left: 4px;
          top: 4px;
          border-radius: 50%;
          background: white;
          transition: transform 0.3s;
          box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        .toggle-track input:checked + .toggle-thumb {
          background: linear-gradient(135deg, #8b5cf6, #ec4899);
        }
        .toggle-track input:checked + .toggle-thumb::before {
          transform: translateX(28px);
        }
        .save-badge {
          background: #f3e8ff;
          color: #7c3aed;
          padding: 4px 10px;
          border-radius: 999px;
          font-size: 12px;
          font-weight: 700;
        }

        /* ── Cards grid ── */
        .pricing-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 24px;
          margin-top: 20px;
          align-items: start;
        }

        /* ── Individual card ── */
        .pricing-card {
          display: flex;
          flex-direction: column;
          position: relative;
          padding: 40px 36px 36px;
          border-radius: 28px;
          background: rgba(255,255,255,0.74);
          border: 1px solid rgba(255,255,255,0.9);
          box-shadow: 0 28px 80px rgba(123,63,242,0.08);
          backdrop-filter: blur(18px);
          -webkit-backdrop-filter: blur(18px);
          transition: transform 0.28s ease, box-shadow 0.28s ease;
        }
        .pricing-card:hover {
          transform: translateY(-6px);
          box-shadow: 0 36px 80px rgba(123,63,242,0.14);
        }
        .pricing-card.popular {
          border: 1.5px solid rgba(255,92,168,0.4);
          background: linear-gradient(rgba(255,255,255,0.85), rgba(255,248,252,0.9));
          box-shadow: 0 28px 60px rgba(124,58,237,0.14);
          padding-top: 56px;
        }

        /* Popular badge */
        .popular-badge {
          position: absolute;
          top: -1px;
          left: 0;
          right: 0;
          height: 44px;
          border-radius: 28px 28px 0 0;
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          background: linear-gradient(135deg, #ff5ca8, #ff9b54);
          font-size: 0.8rem;
          font-weight: 900;
          letter-spacing: 0.04em;
        }

        /* Card content */
        .card-name {
          font-size: 1.22rem;
          font-weight: 700;
          color: #111827;
          margin: 0 0 8px;
        }
        .card-tagline {
          color: #6b7280;
          margin: 0 0 24px;
          line-height: 1.5;
          font-size: 0.95rem;
        }
        .card-price-row {
          display: flex;
          align-items: flex-end;
          gap: 6px;
          margin-bottom: 28px;
        }
        .card-price {
          color: #111827;
          font-size: clamp(2rem, 3.5vw, 2.8rem);
          font-weight: 800;
          line-height: 1;
        }
        .card-price-note {
          color: #6b7280;
          font-weight: 700;
          font-size: 0.95rem;
          padding-bottom: 4px;
        }
        .card-divider {
          height: 1px;
          background: rgba(0,0,0,0.06);
          margin-bottom: 24px;
          border: none;
        }
        .card-features {
          display: flex;
          flex-direction: column;
          gap: 14px;
          margin: 0 0 32px;
          padding: 0;
          list-style: none;
          flex: 1;
          color: #4b5563;
          font-size: 0.97rem;
          line-height: 1.5;
        }
        .card-feature-item {
          display: flex;
          align-items: flex-start;
          gap: 10px;
        }
        .card-check {
          color: #7b3ff2;
          font-weight: 800;
          flex-shrink: 0;
          margin-top: 1px;
          font-size: 0.85rem;
        }
        .card-cta {
          display: flex;
          align-items: center;
          justify-content: center;
          min-height: 52px;
          border-radius: 14px;
          color: white;
          background: linear-gradient(135deg, #7b3ff2, #ff5ca8);
          font-weight: 800;
          font-size: 0.97rem;
          box-shadow: 0 12px 32px rgba(123,63,242,0.22);
          text-decoration: none;
          transition: opacity 0.2s ease, transform 0.2s ease;
          letter-spacing: 0.01em;
        }
        .card-cta:hover {
          opacity: 0.92;
          transform: translateY(-1px);
        }

        /* ── CTA banner ── */
        .cta-banner {
          background: linear-gradient(90deg, #4b6ef5 0%, #b357a7 100%);
          border-radius: 24px;
          padding: 60px 48px;
          text-align: center;
          color: white;
          width: min(1040px, 100%);
          margin: 64px auto 0;
        }
        .cta-banner h2 {
          font-size: clamp(1.4rem, 3vw, 2rem);
          margin: 0 0 12px;
          font-weight: 700;
        }
        .cta-banner p {
          font-size: 1rem;
          margin: 0 0 32px;
          opacity: 0.9;
          max-width: 560px;
          margin-left: auto;
          margin-right: auto;
          line-height: 1.7;
        }
        .cta-buttons {
          display: flex;
          justify-content: center;
          gap: 16px;
          flex-wrap: wrap;
        }
        .cta-btn-primary {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 14px 28px;
          border-radius: 12px;
          font-weight: 600;
          font-size: 1rem;
          text-decoration: none;
          background: #f1f4f9;
          color: #4b6ef5;
          transition: transform 0.2s ease;
          white-space: nowrap;
        }
        .cta-btn-primary:hover { transform: translateY(-2px); }
        .cta-btn-outline {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 14px 28px;
          border-radius: 12px;
          font-weight: 600;
          font-size: 1rem;
          text-decoration: none;
          background: transparent;
          color: white;
          border: 1px solid rgba(255,255,255,0.5);
          transition: transform 0.2s ease;
          white-space: nowrap;
        }
        .cta-btn-outline:hover { transform: translateY(-2px); }

        /* ── Responsive: tablet (641px – 980px) ── */
        @media (max-width: 980px) {
          .pricing-grid {
            grid-template-columns: 1fr;
            max-width: 520px;
            margin-left: auto;
            margin-right: auto;
          }
          .pricing-card.popular {
            /* No negative margin on single-column */
          }
        }

        /* ── Responsive: mobile (≤ 640px) ── */
        @media (max-width: 640px) {
          .pricing-section {
            width: calc(100% - 24px);
            margin: 24px auto 0;
            padding: 24px 0 64px;
          }
          .pricing-hero {
            padding: 40px 24px 36px;
            border-radius: 24px;
          }
          .pricing-hero h1 {
            font-size: clamp(2.4rem, 9vw, 3.2rem);
            line-height: 1;
            margin-bottom: 16px;
          }
          .pricing-hero p {
            font-size: 0.97rem;
          }
          .pricing-controls {
            padding: 20px 16px;
            gap: 20px;
            margin: 24px auto 16px;
          }
          .trust-indicators {
            font-size: 0.85rem;
            gap: 8px 16px;
          }
          .pricing-grid {
            max-width: 100%;
            gap: 20px;
          }
          .pricing-card {
            padding: 36px 24px 28px;
            border-radius: 22px;
          }
          .pricing-card.popular {
            padding-top: 52px;
          }
          .card-price {
            font-size: 2.2rem;
          }
          .card-features {
            font-size: 0.93rem;
            gap: 12px;
          }
          .cta-banner {
            padding: 40px 24px;
            border-radius: 20px;
            margin-top: 48px;
          }
          .cta-banner h2 {
            font-size: 1.35rem;
          }
          .cta-banner p {
            font-size: 0.93rem;
          }
          .cta-buttons {
            flex-direction: column;
            align-items: center;
          }
          .cta-btn-primary,
          .cta-btn-outline {
            width: 100%;
            justify-content: center;
            max-width: 320px;
          }
        }
      `}</style>

      <section className="pricing-section">
        {/* Hero */}
        <div className="pricing-hero">
          <span className="pricing-hero-eyebrow">
            Transparent Pricing For Complete Peace Of Mind
          </span>
          <h1 className={heroXL}>
            Care & property management for{" "}
            <span style={gradientText}>NRI families</span>
          </h1>
          <p>
            Trusted local support for your parents, property, and emergencies —
            all managed through one reliable platform.
          </p>
        </div>

        {/* Trust + Toggle */}
        <div className="pricing-controls">
          <div className="trust-indicators">
            <span>✔ Verified Local Teams</span>
            <span>✔ Real-Time Updates</span>
            <span>✔ Emergency Response Support</span>
            <span>✔ Trusted By NRI Families</span>
          </div>

          <div className="billing-toggle">
            <span
              className={`billing-label ${billing === "monthly" ? "active" : "inactive"}`}
            >
              Monthly
            </span>

            <label className="toggle-track">
              <input
                type="checkbox"
                checked={billing === "yearly"}
                onChange={() =>
                  setBilling(billing === "monthly" ? "yearly" : "monthly")
                }
              />
              <span className="toggle-thumb" />
            </label>

            <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              <span
                className={`billing-label ${billing === "yearly" ? "active" : "inactive"}`}
              >
                Yearly
              </span>
              <span className="save-badge">Save 15%</span>
            </div>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="pricing-grid">
          {plans[billing].map((plan) => (
            <article
              className={`pricing-card${plan.popular ? " popular" : ""}`}
              key={plan.name}
            >
              {plan.popular && (
                <span className="popular-badge">Most Popular</span>
              )}

              <h2 className="card-name">{plan.name}</h2>
              <p className="card-tagline">{plan.tagline}</p>

              <div className="card-price-row">
                <span className="card-price">{plan.price}</span>
                <span className="card-price-note">{plan.note}</span>
              </div>

              <hr className="card-divider" />

              <ul className="card-features">
                {plan.features.map((feature) => (
                  <li key={feature} className="card-feature-item">
                    <span className="card-check">✓</span>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>

              <Link to="/auth" state={plan} className="card-cta">
                {plan.cta}
              </Link>
            </article>
          ))}
        </div>

        {/* CTA Banner */}
        <div className="cta-banner">
          <h2>Not sure which plan is right for your family?</h2>
          <p>
            Speak with our care experts and get a personalized support plan
            tailored to your parents and property needs.
          </p>
          <div className="cta-buttons">
            <Link to="/booking" className="cta-btn-primary">
              📅 Book Free Consultation
            </Link>
            <a href="tel:+919951159777" className="cta-btn-outline">
              📞 Talk To An Expert
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Pricing;

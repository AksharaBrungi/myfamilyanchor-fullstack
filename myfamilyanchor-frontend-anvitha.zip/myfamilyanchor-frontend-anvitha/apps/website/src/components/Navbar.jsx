/* Version 2 */
import { useEffect, useRef, useState } from "react";
import { Link, NavLink } from "react-router-dom";
import logo from "@assets/logonbg.png";
import { useAuth } from "@auth/AuthContext";

const navItems = [
  ["Home", "/"],
  ["Services", "/services"],
  ["Pricing", "/pricing"],
  ["Cities We Serve", "/cities"],
  ["About Us", "/about"],
  ["Contact", "/contact"],
];

function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const menuRef = useRef(null);
  const { user } = useAuth();

  useEffect(() => {
    function handleClickOutside(event) {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setIsMenuOpen(false);
      }
    }

    function handleEscape(event) {
      if (event.key === "Escape") {
        setIsMenuOpen(false);
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("keydown", handleEscape);

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleEscape);
    };
  }, []);

  const navLinkClass = ({ isActive }) =>
    `min-h-[42px] px-4 rounded-full inline-flex items-center justify-center gap-1.5 text-[0.9rem] font-extrabold leading-[1.1] whitespace-nowrap transition-all duration-200 hover:text-[#7b3ff2] hover:bg-[rgba(123,63,242,0.10)] ${
      isActive ? "text-[#7b3ff2] bg-[rgba(123,63,242,0.12)]" : "text-[#111827]"
    }`;

  return (
    // <header className="sticky top-[14px] z-50 w-[min(1360px,calc(100%-32px))] mx-auto max-[720px]:top-[10px] max-[720px]:w-[min(calc(100%-18px),560px)]">
    <header className="fixed top-0 left-0 right-0 z-[9999] pt-4">
      <nav
        className="
    w-[min(1360px,calc(100%-32px))]
    mx-auto
    min-h-[74px]
    px-[18px]
    py-3
    rounded-[24px]
    grid
    grid-cols-[auto_minmax(0,1fr)_auto]
    items-center
    gap-[18px]
    bg-[rgba(255,255,255,0.82)]
    border
    border-[rgba(255,255,255,0.9)]
    shadow-[0_24px_70px_rgba(123,63,242,0.13)]
    backdrop-blur-[22px]
    text-base
    max-[1080px]:min-h-[66px]
    max-[1080px]:flex
    max-[1080px]:justify-between
    max-[720px]:w-[min(calc(100%-18px),560px)]
    max-[720px]:px-[10px]
    max-[720px]:rounded-[20px]
  "
      >
        {/* <nav
        className="
              min-h-[74px] px-[18px] py-3 rounded-[24px]
              grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-[18px]
              bg-[rgba(255,255,255,0.72)] border border-[rgba(255,255,255,0.78)]
              shadow-[0_24px_70px_rgba(123,63,242,0.13)] backdrop-blur-[22px]
              text-base
              max-[1080px]:min-h-[66px] max-[1080px]:flex max-[1080px]:justify-between
              max-[720px]:px-[10px] max-[720px]:rounded-[20px]
            "
        aria-label="Primary navigation"
      > */}
        {/* Brand */}
        <Link
          to="/"
          className="flex items-center gap-3 min-w-max justify-self-start max-[720px]:gap-2"
          onClick={() => setIsMenuOpen(false)}
        >
          <img
            src={logo}
            alt="MyFamilyAnchor"
            className="w-14 h-14 object-contain flex-shrink-0 max-[720px]:w-11 max-[720px]:h-11"
          />

          <div className="flex flex-col leading-none">
            <strong className="font-['Cormorant_Garamond',serif] text-[1.75rem] leading-[0.85] text-[#101827] max-[720px]:text-[1.4rem]">
              MyFamily<span className="text-[#7b3ff2]">Anchor</span>
            </strong>
            <small className="text-[#6b7280] text-[0.58rem] font-bold tracking-[0.16em] uppercase mt-[5px] max-[720px]:hidden">
              Care that connects hearts
            </small>
          </div>
        </Link>

        {/* Desktop nav links */}
        <div className="flex items-center justify-center gap-[10px] min-w-0 justify-self-center max-[1080px]:hidden">
          {navItems.map(([item, path]) => (
            <NavLink
              to={path}
              key={item}
              end={path === "/"}
              className={navLinkClass}
            >
              {item}
            </NavLink>
          ))}
        </div>

        {/* Desktop Auth Button */}
        <div className="flex items-center justify-end gap-3 justify-self-end max-[1080px]:hidden">
          {user ? (
            <Link
              to="/dashboard"
              className="min-h-[42px] px-[22px] rounded-[14px] text-[#7b3ff2] bg-[rgba(123,63,242,0.08)] inline-flex items-center justify-center text-[0.92rem] font-black whitespace-nowrap transition-all duration-200 hover:text-[#6d28d9] hover:bg-[rgba(123,63,242,0.14)] hover:-translate-y-0.5"
            >
              Open App
            </Link>
          ) : (
            <Link
              to="/login"
              className="min-h-[42px] px-[22px] rounded-[14px] text-[#7b3ff2] bg-[rgba(123,63,242,0.08)] inline-flex items-center justify-center text-[0.92rem] font-black whitespace-nowrap transition-all duration-200 hover:text-[#6d28d9] hover:bg-[rgba(123,63,242,0.14)] hover:-translate-y-0.5"
            >
              Login
            </Link>
          )}
        </div>

        {/* Hamburger */}
        <div
          className="relative flex-none hidden max-[1080px]:block"
          ref={menuRef}
        >
          <button
            type="button"
            className="
                  w-[42px] h-[42px] border-0 rounded-[13px] grid place-items-center gap-1
                  bg-[linear-gradient(135deg,rgba(255,255,255,0.86),rgba(246,240,255,0.92))]
                  text-[#111827] shadow-[inset_0_0_0_1px_rgba(123,63,242,0.12)]
                  hover:text-[#7b3ff2] hover:outline hover:outline-[3px] hover:outline-[rgba(123,63,242,0.22)] hover:outline-offset-[3px]
                  focus-visible:outline focus-visible:outline-[3px] focus-visible:outline-[rgba(123,63,242,0.22)] focus-visible:outline-offset-[3px]
                  max-[720px]:w-[38px] max-[720px]:h-[38px] max-[720px]:rounded-[12px]
                "
            aria-label={
              isMenuOpen ? "Close navigation menu" : "Open navigation menu"
            }
            aria-controls="nav-dropdown"
            aria-expanded={isMenuOpen}
            onClick={() => setIsMenuOpen((o) => !o)}
          >
            <span
              className={`block w-[19px] h-0.5 rounded-full bg-current transition-transform duration-200 ${isMenuOpen ? "translate-y-[6px] rotate-45" : ""}`}
            />
            <span
              className={`block w-[19px] h-0.5 rounded-full bg-current transition-opacity duration-200 ${isMenuOpen ? "opacity-0" : ""}`}
            />
            <span
              className={`block w-[19px] h-0.5 rounded-full bg-current transition-transform duration-200 ${isMenuOpen ? "-translate-y-[6px] -rotate-45" : ""}`}
            />
          </button>

          {/* Dropdown */}
          <div
            id="nav-dropdown"
            className={`
                  absolute
    top-[calc(100%+14px)]
    right-0
    w-[min(340px,calc(100vw-34px))]
    p-[12px]
    rounded-[24px]
    bg-[rgba(255,255,255,0.98)]
    border
    border-[rgba(123,63,242,0.18)]
    shadow-[0_30px_80px_rgba(17,24,39,0.22)]
    backdrop-blur-[24px]
    grid
    gap-2
    transition-all
    duration-200

                  ${
                    isMenuOpen
                      ? "opacity-100 pointer-events-auto translate-y-0"
                      : "opacity-0 pointer-events-none -translate-y-2"
                  }
                `}
            aria-hidden={!isMenuOpen}
          >
            {navItems.map(([item, path]) => (
              <NavLink
                to={path}
                key={item}
                end={path === "/"}
                className={({ isActive }) =>
                  `min-h-[46px] px-[14px] rounded-[14px] flex items-center text-[0.96rem] font-extrabold hover:text-[#7b3ff2] hover:bg-[rgba(123,63,242,0.08)] focus-visible:outline-none ${
                    isActive
                      ? "text-[#7b3ff2] bg-[rgba(123,63,242,0.08)]"
                      : "text-[#111827]"
                  }`
                }
                tabIndex={isMenuOpen ? 0 : -1}
                onClick={() => setIsMenuOpen(false)}
              >
                {item}
              </NavLink>
            ))}

            <div className="h-px bg-[rgba(123,63,242,0.12)] my-2" />

            {user ? (
              <Link
                to="/dashboard"
                onClick={() => setIsMenuOpen(false)}
                className="
                min-h-[50px]
                px-[18px]
                rounded-[16px]
                flex
                items-center
                justify-center
                font-black
                text-white
                bg-[linear-gradient(135deg,#7b3ff2,#ff5ca8,#ff9b54)]
                shadow-[0_10px_30px_rgba(123,63,242,0.25)]
                hover:scale-[1.02]
                transition-all
                duration-200
                "
              >
                Open App
              </Link>
            ) : (
              <Link
                to="/login"
                onClick={() => setIsMenuOpen(false)}
                className="
                min-h-[50px]
                px-[18px]
                rounded-[16px]
                flex
                items-center
                justify-center
                font-black
                text-white
                bg-[linear-gradient(135deg,#7b3ff2,#ff5ca8,#ff9b54)]
                shadow-[0_10px_30px_rgba(123,63,242,0.25)]
                hover:scale-[1.02]
                transition-all
                duration-200
                "
              >
                Login
              </Link>
            )}
          </div>
        </div>
      </nav>
    </header>
  );
}

export default Navbar;

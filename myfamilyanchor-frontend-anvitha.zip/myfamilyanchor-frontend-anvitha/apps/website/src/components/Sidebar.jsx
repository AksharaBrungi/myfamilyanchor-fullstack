import { NavLink } from "react-router-dom";
import { useAuth } from "@auth/AuthContext";

import {
  FiHome,
  FiClipboard,
  FiList,
  FiMapPin,
  FiSettings,
  FiLogOut,
} from "react-icons/fi";

const NAV_ITEMS = [
  {
    to: "/dashboard",
    label: "Dashboard",
    icon: FiHome,
  },
  {
    to: "/request-service",
    label: "Request Service",
    icon: FiClipboard,
  },
  {
    to: "/services-portal",
    label: "My Requests",
    icon: FiList,
  },
  {
    to: "/tracking",
    label: "Service Tracking",
    icon: FiMapPin,
  },
  {
    to: "/settings",
    label: "Settings",
    icon: FiSettings,
  },
];

function Sidebar({ onLogoutClick }) {
  const { user } = useAuth();

  return (
    <aside
      className="
           w-[280px] shrink-0
           sticky top-0 h-screen overflow-y-auto
           px-5 py-7
           flex flex-col gap-6
           border-r border-[rgba(123,63,242,0.08)]
           bg-gradient-to-b from-[rgba(255,255,255,0.95)] to-[rgba(255,248,252,0.82)]
           shadow-[4px_0_32px_rgba(123,63,242,0.05)]
           backdrop-blur-[18px]
           z-[100]
           scrollbar-thin scrollbar-thumb-[rgba(123,63,242,0.15)] scrollbar-track-transparent
         "
    >
      {/* ── Top: brand + user card ── */}
      <div className="flex flex-col gap-[22px] shrink-0">
        {/* Brand */}
        <div className="flex items-center gap-[14px]">
          <div
            className="
                 w-12 h-12 rounded-2xl
                 grid place-items-center
                 text-white text-[1.2rem] font-bold shrink-0
                 bg-gradient-to-br from-[#7b3ff2] via-[#ff5ca8] to-[#ff9b54]
                 shadow-[0_12px_28px_rgba(123,63,242,0.22)]
               "
          >
            ♡
          </div>
          <div>
            <h2 className="text-[1.05rem] leading-[1.1] mb-1 text-[#111827] font-semibold">
              MyFamilyAnchor
            </h2>
            <p className="text-[0.74rem] text-[#6b7280] m-0">
              Care that connects hearts
            </p>
          </div>
        </div>

        {/* User card */}
        <div
          className="
               px-5 py-[18px] rounded-[22px] shrink-0
               bg-[rgba(255,255,255,0.72)]
               border border-[rgba(255,255,255,0.78)]
               shadow-[0_24px_70px_rgba(123,63,242,0.13)]
               backdrop-blur-[22px]
             "
        >
          <h3
            className="
                 text-base font-semibold mb-1.5 text-[#111827]
                 whitespace-nowrap overflow-hidden text-ellipsis
               "
          >
            {user?.name}
          </h3>
          <span className="text-[0.8rem] text-[#6b7280]">
            {user?.plan || user?.currentPlan || "Active Member"}
          </span>
        </div>
      </div>

      {/* ── Nav ── */}
      <nav className="flex flex-col gap-1 shrink-0">
        {NAV_ITEMS.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              [
                "w-full min-h-[52px] px-[18px] rounded-2xl",
                "border-none bg-transparent font-[inherit]",
                "flex items-center gap-3 relative",
                "text-[0.92rem] font-extrabold no-underline cursor-pointer",
                "transition-[background,color,box-shadow] duration-[220ms] ease-in-out",
                isActive
                  ? "bg-[rgba(123,63,242,0.08)] text-[#7b3ff2] shadow-[0_8px_24px_rgba(123,63,242,0.07)]"
                  : "text-[#374151] hover:bg-[rgba(123,63,242,0.08)] hover:text-[#7b3ff2] hover:shadow-[0_8px_24px_rgba(123,63,242,0.07)]",
              ].join(" ")
            }
          >
            {({ isActive }) => (
              <>
                {isActive && (
                  <span
                    className="
                         absolute left-2 w-1 h-5 rounded-full
                         bg-gradient-to-b from-[#7b3ff2] to-[#ff5ca8]
                       "
                  />
                )}

                <Icon size={18} />

                {label}
              </>
            )}
          </NavLink>
        ))}

        {/* Logout button */}
        <button
          className="
               w-full min-h-[52px] px-[18px] rounded-2xl
               border-none bg-transparent font-[inherit]
               flex items-center gap-3   relative
               text-[0.92rem] font-extrabold cursor-pointer text-left
               text-[#6b7280]
               transition-[background,color,box-shadow] duration-[220ms] ease-in-out
               hover:text-[#dc2626] hover:bg-[rgba(220,38,38,0.07)]
             "
          onClick={onLogoutClick}
          type="button"
        >
          <>
            <FiLogOut size={18} />
            Logout
          </>
        </button>
      </nav>

      {/* ── Bottom: support card ── */}
      <div
        className="
             shrink-0 p-5 rounded-[22px] mt-auto
             bg-[rgba(255,255,255,0.72)]
             border border-[rgba(255,255,255,0.78)]
             shadow-[0_24px_70px_rgba(123,63,242,0.13)]
             backdrop-blur-[22px]
           "
      >
        <h4 className="mb-2.5 text-[0.95rem] font-semibold text-[#111827]">
          Need Assistance?
        </h4>
        <p className="text-[0.88rem] leading-relaxed text-[#6b7280] m-0">
          Our care coordinators are available 24/7.
        </p>
        <NavLink
          to="/contact"
          className="
               flex items-center justify-center
               w-full mt-4 min-h-[48px] rounded-[14px]
               text-white font-black text-[0.9rem] no-underline
               bg-gradient-to-r from-[#7b3ff2] via-[#ff5ca8] to-[#ff9b54]
               shadow-[0_12px_28px_rgba(255,92,168,0.2)]
               transition-[opacity,transform] duration-200 ease-in-out
               hover:opacity-[0.92] hover:-translate-y-0.5
             "
        >
          Contact Support
        </NavLink>
      </div>
    </aside>
  );
}

export default Sidebar;

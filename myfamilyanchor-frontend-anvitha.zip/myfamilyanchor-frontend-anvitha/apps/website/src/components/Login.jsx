import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@auth/AuthContext";
import API from "@api/axios";
import PasswordInput from "@ui/PasswordInput";
import ForgotPasswordModal from "@ui/ForgotPasswordModal";

function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();

  const [formData, setFormData] = useState({ identifier: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [showForgot, setShowForgot] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    try {
      setLoading(true);
      const { data } = await API.post("/auth/login", formData);
      await login(data.token);
      navigate("/dashboard");
    } catch (err) {
      if (err.response?.data?.requiresPayment) {
        const { token } = err.response.data;

        if (token) {
          localStorage.setItem("pendingToken", token);
          localStorage.setItem("pendingUserEmail", formData.identifier);
        }

        const savedPlan = localStorage.getItem("selectedPlan");
        navigate(savedPlan ? "/checkout" : "/pricing");
        // if (savedPlan) {
        //   navigate("/checkout");
        // } else {
        //   navigate("/pricing");
        // }
        return;
      }

      setError(
        err.response?.data?.message || "Login failed. Please try again.",
      );
    } finally {
      setLoading(false);
    }
  };

  const inputCls = `
  w-full min-h-[64px] px-[22px]
  rounded-[18px]
  border border-[rgba(148,163,184,0.18)]
  bg-[rgba(255,255,255,0.76)]
  text-base
  transition-all duration-300
  focus:outline-none
  focus:border-[rgba(123,63,242,0.4)]
  focus:shadow-[0_0_0_5px_rgba(123,63,242,0.08)]
`;

  return (
    <section className="[min-height:calc(100vh_-_160px)] [display:flex] [align-items:center] [justify-content:center] [padding:60px_24px] max-[640px]:[padding:40px_18px]">
      <div
        className="
    [width:100%]
    [max-width:1180px]
    [margin:0_auto]
    [display:flex]
    [justify-content:center]
    [&_.auth-card]:[width:100%]
    [&_.auth-card]:[max-width:640px]
  "
      >
        <form
          className="auth-card [position:relative] [overflow:hidden] [border-radius:32px] [background:rgba(255,_255,_255,_0.72)] [border:1px_solid_rgba(255,_255,_255,_0.9)] [box-shadow:0_30px_80px_rgba(123,_63,_242,_0.08),_inset_0_1px_0_rgba(255,_255,_255,_0.8)] [-webkit-backdrop-filter:blur(20px)] [backdrop-filter:blur(20px)] [padding:56px] [display:flex] [flex-direction:column] [justify-content:center] [&_input]:[width:100%] [&_input]:[min-height:64px] [&_input]:[padding:0_22px] [&_input]:[border-radius:18px] [&_input]:[border:1px_solid_rgba(148,_163,_184,_0.18)] [&_input]:[background:rgba(255,_255,_255,_0.76)] [&_input]:[color:#111827] [&_input]:[font-size:1rem] [&_input]:[transition:0.3s_ease] [&_input::placeholder]:[color:#9ca3af] [&_input:focus]:[outline:none] [&_input:focus]:[border-color:rgba(123,_63,_242,_0.4)] [&_input:focus]:[box-shadow:0_0_0_5px_rgba(123,_63,_242,_0.08)] [&_form]:[gap:16px] [gap:16px] max-[980px]:[min-height:auto] max-[980px]:[order:1] max-[640px]:[padding:34px_24px] max-[640px]:[border-radius:26px] max-[640px]:[&_input]:[min-height:56px] [border:1px_solid_rgba(255,_255,_255,_0.78)] [box-shadow:0_24px_70px_rgba(123,_63,_242,_0.13)] [-webkit-backdrop-filter:blur(22px)] [backdrop-filter:blur(22px)]"
          onSubmit={handleSubmit}
        >
          <div className="[margin-bottom:12px] [&_h1]:[margin:14px_0] [&_h1]:[font-size:clamp(2.8rem,_4vw,_4.2rem)] [&_h1]:[line-height:1] [&_h1]:[color:#111827] [&_p]:[color:rgba(15,_23,_42,_0.7)] [&_p]:[line-height:1.7] [&_p]:[max-width:420px] max-[640px]:[&_h1]:[font-size:2.4rem]">
            <span className="[color:#7b3ff2] [font-size:0.78rem] [font-weight:800] [letter-spacing:0.14em] [text-transform:uppercase] [font-size:0.84rem] [letter-spacing:0.18em]">
              Customer Access
            </span>
            <h1>Welcome Back</h1>
            <p>
              Login to manage your care plans, payments and service requests.
            </p>
          </div>

          {error && (
            <p
              className="[color:#dc2626] [font-weight:600] [font-size:0.9rem] [margin:0] [text-align:center]"
              role="alert"
            >
              {error}
            </p>
          )}

          <input
            type="text"
            placeholder="Email or Phone Number"
            required
            value={formData.identifier}
            onChange={(e) =>
              setFormData({ ...formData, identifier: e.target.value })
            }
          />

          <PasswordInput
            className={inputCls}
            placeholder="Password"
            required
            value={formData.password}
            onChange={(e) =>
              setFormData({ ...formData, password: e.target.value })
            }
          />

          <button
            type="button"
            className="[background:none] [border:none] [padding:0] [font-size:13px] [font-weight:600] [color:#7b3ff2] [cursor:pointer] [text-align:right] [align-self:flex-end] [transition:color_0.2s] [text-decoration:underline] [text-underline-offset:3px] hover:[color:#ff5ca8]"
            onClick={() => setShowForgot(true)}
          >
            Forgot Password?
          </button>

          <button
            type="submit"
            className="[min-height:56px] [padding:0_28px] [border-radius:18px] [display:inline-flex] [align-items:center] [justify-content:center] [gap:12px] [border:1px_solid_transparent] [font-size:0.96rem] [font-weight:900] [line-height:1] [text-align:center] [text-decoration:none] [white-space:nowrap] [cursor:pointer] [transition:transform_0.25s_ease,_box-shadow_0.25s_ease,_border-color_0.25s_ease,_background_0.25s_ease] [color:#fff] [background:linear-gradient(135deg,_#7b3ff2,_#ff5ca8,_#ff9b54)] [box-shadow:0_20px_42px_rgba(255,_92,_168,_0.28)] hover:[transform:translateY(-3px)] hover:[box-shadow:0_26px_54px_rgba(123,_63,_242,_0.3)] focus-visible:[outline:3px_solid_rgba(123,_63,_242,_0.22)] focus-visible:[outline-offset:4px] [width:100%] [min-height:62px] [border:0] [color:white] [font-size:1rem] [font-weight:800] [box-shadow:0_20px_40px_rgba(123,_63,_242,_0.2)] [transition:0.3s_ease] hover:[transform:translateY(-2px)] hover:[box-shadow:0_28px_48px_rgba(123,_63,_242,_0.26)] max-[640px]:[min-height:56px]"
            disabled={loading}
          >
            {loading ? "Logging in..." : "Login"}
          </button>

          <p className="[margin-top:14px] [display:flex] [justify-content:center] [gap:8px] [color:rgba(15,_23,_42,_0.72)] [&_a]:[color:#7b3ff2] [&_a]:[font-weight:700]">
            New here? <Link to="/pricing">Choose a plan</Link>
          </p>
        </form>
      </div>

      {showForgot && (
        <ForgotPasswordModal role="user" onClose={() => setShowForgot(false)} />
      )}
    </section>
  );
}

export default Login;

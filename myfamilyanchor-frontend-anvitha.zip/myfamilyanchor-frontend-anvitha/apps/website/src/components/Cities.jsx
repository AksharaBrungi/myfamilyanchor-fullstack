import { heroLG, gradientText } from "@ui/heroTypography";

const cities = [
  [
    "Hyderabad",
    "120+ Care Experts",
    "30 min response",
    "Telugu · Hindi · English",
  ],
  [
    "Bengaluru",
    "95+ Care Experts",
    "35 min response",
    "Kannada · Hindi · English",
  ],
  ["Chennai", "85+ Care Experts", "35 min response", "Tamil · English"],
  [
    "Mumbai",
    "140+ Care Experts",
    "30 min response",
    "Hindi · Marathi · English",
  ],
  [
    "Delhi NCR",
    "130+ Care Experts",
    "30 min response",
    "Hindi · Punjabi · English",
  ],
  ["Pune", "80+ Care Experts", "40 min response", "Hindi · Marathi · English"],
  ["Ahmedabad", "60+ Care Experts", "45 min response", "Gujarati · Hindi"],
  [
    "Kolkata",
    "70+ Care Experts",
    "45 min response",
    "Bengali · Hindi · English",
  ],
  ["Kochi", "55+ Care Experts", "45 min response", "Malayalam · English"],
  ["Vijayawada", "45+ Care Experts", "50 min response", "Telugu · English"],
];

const services = [
  "Health Monitoring",
  "Emergency Care",
  "Property Care",
  "Companion Visits",
  "Medicine Support",
  "Hospital Assistance",
];

const pinPositions = [
  "[left:44%] [top:52%]",
  "[left:38%] [top:20%]",
  "[left:24%] [top:48%]",
  "[right:18%] [bottom:22%]",
  "[left:38%] [bottom:8%]",
];

function Cities() {
  return (
    <div className="pt-[3px]">
      <section className="[width:min(1440px,_calc(100%_-_36px))] [margin:48px_auto_0] [padding:54px_0_110px] max-[640px]:[width:min(100%_-_20px,_520px)]">
        {/* ── HERO PANEL ── */}
        <div className="[min-height:560px] [padding:56px] [border-radius:36px] [display:grid] [grid-template-columns:0.9fr_1.1fr] [gap:42px] [align-items:center] [background:radial-gradient(_circle_at_12%_18%,_rgba(255,_92,_168,_0.18),_transparent_30%_),_radial-gradient(_circle_at_88%_14%,_rgba(255,_155,_84,_0.2),_transparent_32%_),_rgba(255,_255,_255,_0.62)] [border:1px_solid_rgba(255,_255,_255,_0.86)] [box-shadow:0_32px_90px_rgba(123,_63,_242,_0.12)] max-[980px]:[grid-template-columns:1fr] max-[980px]:[padding:38px_24px]">
          <div>
            {/* eyebrow */}
            <span className="[display:inline-block] [color:#7b3ff2] [font-size:0.78rem] [font-weight:800] [letter-spacing:0.14em] [text-transform:uppercase] [margin-bottom:18px]">
              Cities We Serve
            </span>

            {/* hero heading — heroLG provides margin-bottom:28px automatically */}
            <h1 className={heroLG}>
              Trusted Parent Care <span style={gradientText}>Across India</span>
            </h1>

            {/* body copy — benefits from heading's built-in bottom margin */}
            <p className="[color:#374151] [font-size:1.1rem] [line-height:1.85] [max-width:540px] [margin:0_0_36px]">
              No matter where your parents live in India, verified eldercare,
              emergency help, companionship and property support are always
              nearby.
            </p>

            <div className="flex flex-wrap items-center gap-4">
              <a
                href="/contact"
                className="
                  min-w-[220px]
                  h-16
                  px-8
                  rounded-[18px]
                  inline-flex
                  items-center
                  justify-center
                  text-[1.05rem]
                  font-black
                  text-white
                  bg-gradient-to-r
                  from-[#7b3ff2]
                  via-[#ff5ca8]
                  to-[#ff9b54]
                  shadow-[0_20px_42px_rgba(255,92,168,0.28)]
                  transition-all
                  duration-300
                  hover:-translate-y-1
                "
              >
                Check Availability
              </a>

              <a
                href="/booking"
                className="
                  min-w-[220px]
                  h-16
                  px-8
                  rounded-[18px]
                  inline-flex
                  items-center
                  justify-center
                  text-[1.05rem]
                  font-black
                  text-[#6d28d9]
                  bg-white/70
                  border
                  border-[#7b3ff2]/25
                  backdrop-blur-xl
                  shadow-[0_16px_36px_rgba(123,63,242,0.1)]
                  transition-all
                  duration-300
                  hover:-translate-y-1
                "
              >
                Book Consultation
              </a>
            </div>
          </div>

          {/* India blob map */}
          <div className="[min-height:440px] [border-radius:34px] [padding:28px] [position:relative] [overflow:hidden] [background:rgba(255,_255,_255,_0.72)] [border:1px_solid_rgba(255,_255,_255,_0.78)] [box-shadow:0_24px_70px_rgba(123,_63,_242,_0.13)] [-webkit-backdrop-filter:blur(22px)] [backdrop-filter:blur(22px)]">
            <div className="[position:relative] [width:min(440px,_100%)] [height:390px] [margin:0_auto] [border-radius:48%_42%_54%_38%] [background:radial-gradient(_circle_at_48%_45%,_rgba(255,_255,_255,_0.8),_transparent_34%_),_linear-gradient(_135deg,_rgba(123,_63,_242,_0.18),_rgba(255,_92,_168,_0.15),_rgba(255,_155,_84,_0.14)_)] [border:1px_solid_rgba(123,_63,_242,_0.12)] [box-shadow:inset_0_0_80px_rgba(255,_255,_255,_0.5)]">
              {["Hyderabad", "Delhi", "Mumbai", "Chennai", "Kochi"].map(
                (city, index) => (
                  <span
                    className={`[position:absolute] [display:flex] [align-items:center] [gap:8px] [padding:10px_13px] [border-radius:999px] [color:#111827] [background:rgba(255,_255,_255,_0.82)] [box-shadow:0_18px_38px_rgba(123,_63,_242,_0.16)] [font-size:0.82rem] [font-weight:900] [animation:floatSoft_5s_ease-in-out_infinite] max-[640px]:[font-size:0.72rem] [&_b]:[width:12px] [&_b]:[height:12px] [&_b]:[border-radius:50%] [&_b]:[background:#ff5ca8] [&_b]:[box-shadow:0_0_0_7px_rgba(255,_92,_168,_0.16)] ${pinPositions[index]}`}
                    key={city}
                  >
                    <b />
                    {city}
                  </span>
                ),
              )}
            </div>
          </div>
        </div>

        {/* ── Section heading ── */}
        <div className="[text-align:center] [margin:56px_0_40px]">
          <span className="[color:#7b3ff2] [font-size:0.78rem] [font-weight:800] [letter-spacing:0.14em] [text-transform:uppercase]">
            Nationwide Support
          </span>
          <h2 className="[margin:14px_0_0] [font-family:Cormorant_Garamond_serif] [color:#0b1026] [font-size:clamp(2.6rem,_4vw,_4.4rem)] [line-height:1.05]">
            Local care teams in{" "}
            <span className="bg-gradient-to-br from-[#7b3ff2] via-[#ff5ca8] to-[#ff9b54] bg-clip-text text-transparent">
              major Indian cities
            </span>
          </h2>
        </div>

        {/* ── City cards grid ── */}
        <div className="[display:grid] [grid-template-columns:repeat(5,_1fr)] [gap:18px] [margin:0_0_74px] max-[1180px]:[grid-template-columns:repeat(3,_1fr)] max-[980px]:[grid-template-columns:repeat(2,_1fr)] max-[640px]:[grid-template-columns:1fr]">
          {cities.map(([city, experts, response, languages]) => (
            <article
              className="[min-height:315px] [padding:24px] [border-radius:30px] [transition:0.28s_ease] hover:[transform:translateY(-8px)] [&_h3]:[margin:22px_0_8px] [&_h3]:[color:#111827] [&_h3]:[font-size:1.22rem] [&_h3]:[font-weight:700] [&_p]:[margin:0_0_16px] [&_p]:[color:#7b3ff2] [&_p]:[font-weight:900] [&_ul]:[display:grid] [&_ul]:[gap:9px] [&_ul]:[margin:0_0_18px] [&_ul]:[padding:0] [&_ul]:[list-style:none] [&_li]:[color:#4b5563] [&_li]:[font-size:0.88rem] [&_li]:[line-height:1.45] [&_a]:[color:#7b3ff2] [&_a]:[font-weight:900] [background:rgba(255,_255,_255,_0.72)] [border:1px_solid_rgba(255,_255,_255,_0.78)] [box-shadow:0_24px_70px_rgba(123,_63,_242,_0.13)] [-webkit-backdrop-filter:blur(22px)] [backdrop-filter:blur(22px)]"
              key={city}
            >
              <span className="[width:56px] [height:56px] [border-radius:21px] [display:grid] [place-items:center] [color:white] [background:linear-gradient(135deg,_#7b3ff2,_#ff5ca8)] [box-shadow:0_18px_34px_rgba(123,_63,_242,_0.22)] [font-size:1.3rem]">
                ⌖
              </span>
              <h3>{city}</h3>
              <p>{experts}</p>
              <ul>
                <li>✓ 24/7 Emergency Support</li>
                <li>✓ Property Care Available</li>
                <li>✓ Average Response: {response}</li>
                <li>✓ {languages}</li>
              </ul>
              <a href="/booking">Explore Services →</a>
            </article>
          ))}
        </div>

        {/* ── Available Services ── */}
        <div className="[margin-bottom:74px] [padding:40px] [border-radius:34px] [display:grid] [grid-template-columns:0.85fr_1.15fr] [gap:34px] [align-items:center] [background:rgba(255,_255,_255,_0.72)] [border:1px_solid_rgba(255,_255,_255,_0.78)] [box-shadow:0_24px_70px_rgba(123,_63,_242,_0.13)] [-webkit-backdrop-filter:blur(22px)] [backdrop-filter:blur(22px)] max-[980px]:[grid-template-columns:1fr]">
          <div>
            <span className="[color:#7b3ff2] [font-size:0.78rem] [font-weight:800] [letter-spacing:0.14em] [text-transform:uppercase]">
              Available Services
            </span>
            <h2 className="[margin:12px_0_14px] [font-family:Cormorant_Garamond_serif] [color:#0b1026] [font-size:clamp(2.7rem,_4vw,_4.8rem)] [line-height:1.0]">
              Care support available across cities
            </h2>
            <p className="[color:#4b5563] [line-height:1.8] [margin:0]">
              Our city teams coordinate essential services so families abroad
              can feel informed, close and reassured.
            </p>
          </div>

          <div className="[display:grid] [grid-template-columns:repeat(2,_1fr)] [gap:14px] [&_span]:[padding:18px] [&_span]:[border-radius:22px] [&_span]:[color:#111827] [&_span]:[background:rgba(255,_255,_255,_0.76)] [&_span]:[border:1px_solid_rgba(123,_63,_242,_0.1)] [&_span]:[font-weight:900] [&_span]:[box-shadow:0_16px_38px_rgba(123,_63,_242,_0.08)] max-[640px]:[grid-template-columns:1fr]">
            {services.map((service) => (
              <span key={service}>✓ {service}</span>
            ))}
          </div>
        </div>

        {/* ── Emergency Response ── */}
        <div className="[margin-bottom:74px] [display:grid] [grid-template-columns:0.85fr_1.15fr] [gap:34px] [align-items:center] max-[980px]:[grid-template-columns:1fr]">
          <div>
            <span className="[color:#7b3ff2] [font-size:0.78rem] [font-weight:800] [letter-spacing:0.14em] [text-transform:uppercase]">
              Rapid Response
            </span>
            <h2 className="[margin:12px_0_14px] [font-family:Cormorant_Garamond_serif] [color:#0b1026] [font-size:clamp(2.7rem,_4vw,_4.8rem)] [line-height:1.0]">
              Emergency support when families need it most.
            </h2>
            <p className="[color:#4b5563] [line-height:1.8] [margin:0]">
              We coordinate local response teams, hospital support, ambulance
              help and family alerts through our 24/7 care managers.
            </p>
          </div>

          <div className="[padding:28px] [border-radius:34px] [display:grid] [gap:14px] [&_div]:[padding:18px] [&_div]:[border-radius:24px] [&_div]:[background:rgba(255,_255,_255,_0.76)] [&_div]:[display:flex] [&_div]:[align-items:center] [&_div]:[gap:14px] [&_strong]:[width:46px] [&_strong]:[height:46px] [&_strong]:[border-radius:16px] [&_strong]:[color:white] [&_strong]:[background:linear-gradient(135deg,_#ff5ca8,_#ff9b54)] [&_strong]:[display:grid] [&_strong]:[place-items:center] [&_span]:[color:#111827] [&_span]:[font-weight:900] [background:rgba(255,_255,_255,_0.72)] [border:1px_solid_rgba(255,_255,_255,_0.78)] [box-shadow:0_24px_70px_rgba(123,_63,_242,_0.13)] [-webkit-backdrop-filter:blur(22px)] [backdrop-filter:blur(22px)]">
            <div>
              <strong>01</strong>
              <span>Emergency call received</span>
            </div>
            <div>
              <strong>02</strong>
              <span>Care manager alerted</span>
            </div>
            <div>
              <strong>03</strong>
              <span>Local support dispatched</span>
            </div>
            <div>
              <strong>04</strong>
              <span>Family updated live</span>
            </div>
          </div>
        </div>

        {/* ── Testimonials ── */}
        <div className="[display:grid] [grid-template-columns:repeat(3,_1fr)] [gap:18px] [margin-bottom:74px] max-[980px]:[grid-template-columns:repeat(2,_1fr)] max-[640px]:[grid-template-columns:1fr]">
          {[
            [
              "Canada → Hyderabad",
              "My parents received emergency support within minutes. I felt informed even from Toronto.",
            ],
            [
              "Singapore → Bengaluru",
              "The care manager kept us updated after every doctor visit. It changed everything.",
            ],
            [
              "USA → Chennai",
              "Property care and parent support in one place gave our family real peace of mind.",
            ],
          ].map(([route, story]) => (
            <article
              className="[padding:28px] [border-radius:30px] [&_span]:[color:#f6b800] [&_span]:[letter-spacing:0.12em] [&_h3]:[margin:14px_0_12px] [&_h3]:[color:#111827] [&_h3]:[font-weight:700] [&_p]:[color:#4b5563] [&_p]:[line-height:1.75] [background:rgba(255,_255,_255,_0.72)] [border:1px_solid_rgba(255,_255,_255,_0.78)] [box-shadow:0_24px_70px_rgba(123,_63,_242,_0.13)] [-webkit-backdrop-filter:blur(22px)] [backdrop-filter:blur(22px)]"
              key={route}
            >
              <span>★★★★★</span>
              <h3>{route}</h3>
              <p>{story}</p>
            </article>
          ))}
        </div>

        {/* ── Final CTA ── */}
        <div className="[text-align:center] [padding:80px_24px] [display:flex] [flex-direction:column] [align-items:center] [gap:16px]">
          <h2 className="[font-family:Cormorant_Garamond_serif] [font-size:clamp(2rem,_4vw,_3rem)] [color:#080f2a] [max-width:700px] [line-height:1.2] [margin:0]">
            No Matter Where You Live, We're Close To Your Family.
          </h2>
          <p className="[color:#374151] [font-size:1.05rem] [max-width:500px] [line-height:1.7] [margin:0_0_8px]">
            Check service availability for your parents' city and begin your
            care journey today.
          </p>
          <a
            href="/booking"
            className="[min-height:64px] [padding:0_40px] [border-radius:18px] [display:inline-flex] [align-items:center] [justify-content:center] [gap:12px] [border:1px_solid_transparent] [font-size:1.08rem] [font-weight:900] [line-height:1] [text-align:center] [text-decoration:none] [white-space:nowrap] [cursor:pointer] [transition:transform_0.25s_ease,_box-shadow_0.25s_ease] [color:#fff] [background:linear-gradient(135deg,_#7b3ff2,_#ff5ca8,_#ff9b54)] [box-shadow:0_20px_42px_rgba(255,_92,_168,_0.28)] hover:[transform:translateY(-3px)] hover:[box-shadow:0_26px_54px_rgba(123,_63,_242,_0.3)]"
          >
            Check Your City
          </a>
        </div>
      </section>
    </div>
  );
}

export default Cities;

﻿import { useEffect, useRef, useState } from "react";
import { FiMessageCircle, FiX, FiSend, FiMinus } from "react-icons/fi";
import API from "@api/axios";
import "./AIAssistant.css";

const INITIAL_MESSAGE = {
  role: "assistant",
  text: "Hi! I'm the MyFamilyAnchor assistant. I can help explain our care plans and services. I'm currently running in demo mode, so account access and service requests are not connected.",
};

export default function AIAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState([INITIAL_MESSAGE]);
  const [isSending, setIsSending] = useState(false);
  const [error, setError] = useState("");
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isOpen]);

  useEffect(() => {
    if (isOpen) inputRef.current?.focus();
  }, [isOpen]);

  async function handleSubmit(event) {
    event.preventDefault();

    const text = message.trim();
    if (!text || isSending) return;

    if (text.length > 1000) {
      setError("Please keep your message within 1000 characters.");
      return;
    }

    setError("");
    setMessage("");
    setMessages((current) => [...current, { role: "user", text }]);
    setIsSending(true);

    try {
      const response = await API.post("/ai/chat", { message: text });
      const data = response.data;

      if (typeof data?.reply !== "string" || !data.reply.trim()) {
        throw new Error("The assistant returned an unexpected response.");
      }

      setMessages((current) => [
        ...current,
        {
          role: "assistant",
          text: data.reply,
          label: data.label || "Demo mode - scripted replies",
        },
      ]);
    } catch (requestError) {
      const status = requestError.response?.status;
      const reply =
        status === 503
          ? "The demo assistant is currently unavailable. Please try again later."
          : status === 400
            ? "Please enter a valid message and try again."
            : "I couldn't connect to the assistant. Please check that the backend is running and try again.";

      setMessages((current) => [
        ...current,
        { role: "assistant", text: reply, label: "Connection notice" },
      ]);
    } finally {
      setIsSending(false);
    }
  }

  return (
    <div className="mfa-chat">
      {isOpen && (
        <section
          className="mfa-chat-panel"
          role="dialog"
          aria-label="MyFamilyAnchor assistant"
          aria-modal="false"
        >
          <header className="mfa-chat-header">
            <div className="mfa-chat-brand">
              <span className="mfa-chat-avatar" aria-hidden="true">
                <FiMessageCircle />
              </span>
              <div>
                <h2>MyFamilyAnchor</h2>
                <p>Care & services assistant</p>
              </div>
            </div>

            <div className="mfa-chat-header-actions">
              <button
                type="button"
                className="mfa-chat-icon-button"
                aria-label="Minimize chat"
                onClick={() => setIsOpen(false)}
              >
                <FiMinus />
              </button>
              <button
                type="button"
                className="mfa-chat-icon-button"
                aria-label="Close chat"
                onClick={() => setIsOpen(false)}
              >
                <FiX />
              </button>
            </div>
          </header>

          <div className="mfa-chat-demo-notice">
            Demo mode · Scripted replies · No account access
          </div>

          <div className="mfa-chat-messages" aria-live="polite">
            {messages.map((item, index) => (
              <div
                className={`mfa-chat-message mfa-chat-message-${item.role}`}
                key={`${index}-${item.role}`}
              >
                <div className="mfa-chat-bubble">{item.text}</div>
                {item.label && item.role === "assistant" && index > 0 && (
                  <span className="mfa-chat-message-label">{item.label}</span>
                )}
              </div>
            ))}

            {isSending && (
              <div className="mfa-chat-message mfa-chat-message-assistant">
                <div className="mfa-chat-bubble mfa-chat-typing">
                  Thinking…
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <form className="mfa-chat-form" onSubmit={handleSubmit}>
            <label className="mfa-chat-sr-only" htmlFor="mfa-chat-input">
              Type your message
            </label>
            <textarea
              id="mfa-chat-input"
              ref={inputRef}
              value={message}
              onChange={(event) => {
                setMessage(event.target.value);
                if (error) setError("");
              }}
              onKeyDown={(event) => {
                if (event.key === "Enter" && !event.shiftKey) {
                  event.preventDefault();
                  event.currentTarget.form?.requestSubmit();
                }
              }}
              placeholder="Ask about our care plans…"
              rows={1}
              maxLength={1000}
              disabled={isSending}
            />
            <button
              type="submit"
              className="mfa-chat-send"
              aria-label="Send message"
              disabled={isSending || !message.trim()}
            >
              <FiSend />
            </button>
          </form>

          {error && <p className="mfa-chat-error">{error}</p>}
          <p className="mfa-chat-footnote">
            Please don't share passwords or sensitive personal information.
          </p>
        </section>
      )}

      <button
        type="button"
        className={`mfa-chat-launcher ${isOpen ? "is-open" : ""}`}
        aria-label={isOpen ? "Close assistant" : "Open assistant"}
        aria-expanded={isOpen}
        onClick={() => setIsOpen((current) => !current)}
      >
        {isOpen ? <FiX /> : <FiMessageCircle />}
        {!isOpen && <span>Chat with us</span>}
      </button>
    </div>
  );
}

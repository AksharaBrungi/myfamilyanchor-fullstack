import { useState } from "react";
import toast from "react-hot-toast";
import API from "@api/axios";
import { heroSM, gradientText } from "@ui/heroTypography";

const contactMethods = [
  {
    icon: "☎",
    title: "Call Us",
    detail: "+91 995 115 9777",
    sub: "24/7 care helpline",
  },
  {
    icon: "☘",
    title: "WhatsApp",
    detail: "+91 833 183 7077",
    sub: "Quick response on WhatsApp",
  },
  {
    icon: "✉",
    title: "Email Us",
    detail: "myfamilyanchorofficial@gmail.com",
    sub: "We reply within 24 hours",
  },
  {
    icon: "⌖",
    title: "Office",
    detail: "Hyderabad, Telangana, India",
    sub: "Serving families across India",
  },
];

function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (isSubmitting) return;
    try {
      setIsSubmitting(true);
      const { data } = await API.post("/contact", formData);
      toast.success(data.message || "Message sent successfully");
      setFormData({ name: "", email: "", phone: "", message: "" });
    } catch (error) {
      toast.error(error.response?.data?.message || "Failed to send message");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="pt-[10px]">
      <section className="[width:min(1360px,_calc(100%_-_36px))] [margin:48px_auto_0] [padding:48px_0_96px] max-[640px]:[width:min(100%_-_20px,_520px)] max-[640px]:[padding-left:4px] max-[640px]:[padding-right:4px]">
        <div className="[display:grid] [grid-template-columns:0.9fr_1.1fr] [gap:42px] [align-items:start] max-[980px]:[grid-template-columns:1fr]">
          {/* ── LEFT COPY ── */}
          <div>
            {/* eyebrow */}
            <span className="[display:inline-block] [color:#7b3ff2] [font-size:0.78rem] [font-weight:800] [letter-spacing:0.14em] [text-transform:uppercase] [margin-bottom:18px]">
              Contact Us
            </span>

            {/* hero heading — heroSM provides margin-bottom:28px */}
            <h1 className={heroSM}>
              We're just a <span style={gradientText}>call away</span>
            </h1>

            {/* body copy sits naturally below thanks to heading's mb */}
            <p className="[color:#374151] [font-size:1.08rem] [line-height:1.8] [margin:0_0_32px]">
              Have questions or need help? Our care team is here for you with
              warmth, clarity and fast support.
            </p>

            <div className="[display:grid] [gap:16px]">
              {contactMethods.map(({ icon, title, detail, sub }) => (
                <div
                  key={title}
                  className="[padding:18px] [border-radius:26px] [display:flex] [align-items:center] [gap:16px] [background:rgba(255,_255,_255,_0.72)] [border:1px_solid_rgba(255,_255,_255,_0.78)] [box-shadow:0_24px_70px_rgba(123,_63,_242,_0.13)] [-webkit-backdrop-filter:blur(22px)] [backdrop-filter:blur(22px)]"
                >
                  <span
                    className="[width:52px] [height:52px] [border-radius:18px] [color:white] [display:grid] [place-items:center] [font-weight:900] [flex-shrink:0]"
                    style={{
                      background:
                        "linear-gradient(135deg, #7b3ff2, #ff5ca8, #ff9b54)",
                    }}
                  >
                    {icon}
                  </span>
                  <div>
                    <strong className="[color:#111827]">{title}</strong>
                    <p className="[margin:4px_0] [color:#374151] [font-weight:800]">
                      {detail}
                    </p>
                    <small className="[color:#6b7280]">{sub}</small>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* ── RIGHT FORM ── */}
          <form
            onSubmit={handleSubmit}
            className="[padding:34px] [border-radius:32px] [background:rgba(255,_255,_255,_0.72)] [border:1px_solid_rgba(255,_255,_255,_0.78)] [box-shadow:0_24px_70px_rgba(123,_63,_242,_0.13)] [-webkit-backdrop-filter:blur(22px)] [backdrop-filter:blur(22px)]"
          >
            <h2 className="[margin:0_0_24px] [color:#111827] [font-size:1.6rem] [font-weight:700]">
              Send Us a Message
            </h2>

            {[
              {
                label: "Your Name",
                type: "text",
                key: "name",
                placeholder: "Enter your name",
              },
              {
                label: "Email Address",
                type: "email",
                key: "email",
                placeholder: "Enter your email",
              },
              {
                label: "Phone Number",
                type: "text",
                key: "phone",
                placeholder: "Enter your phone number",
              },
            ].map(({ label, type, key, placeholder }) => (
              <label
                key={key}
                className="[display:grid] [gap:8px] [margin-bottom:16px] [color:#374151] [font-weight:800]"
              >
                {label}
                <input
                  type={type}
                  value={formData[key]}
                  onChange={(e) =>
                    setFormData({ ...formData, [key]: e.target.value })
                  }
                  placeholder={placeholder}
                  className="[width:100%] [border:1px_solid_rgba(123,_63,_242,_0.14)] [border-radius:18px] [padding:16px_18px] [color:#111827] [background:rgba(255,_255,_255,_0.74)] [outline:none] focus:[border-color:rgba(123,_63,_242,_0.5)] focus:[box-shadow:0_0_0_4px_rgba(123,_63,_242,_0.08)]"
                />
              </label>
            ))}

            <label className="[display:grid] [gap:8px] [margin-bottom:16px] [color:#374151] [font-weight:800]">
              Your Message
              <textarea
                value={formData.message}
                onChange={(e) =>
                  setFormData({ ...formData, message: e.target.value })
                }
                placeholder="Tell us how we can help"
                rows="5"
                className="[width:100%] [border:1px_solid_rgba(123,_63,_242,_0.14)] [border-radius:18px] [padding:16px_18px] [color:#111827] [background:rgba(255,_255,_255,_0.74)] [outline:none] focus:[border-color:rgba(123,_63,_242,_0.5)] focus:[box-shadow:0_0_0_4px_rgba(123,_63,_242,_0.08)]"
              />
            </label>

            <button
              type="submit"
              disabled={isSubmitting}
              className="[width:100%] [min-height:56px] [border:0] [border-radius:18px] [color:white] [background:linear-gradient(135deg,_#7b3ff2,_#ff5ca8,_#ff9b54)] [font-weight:900] [box-shadow:0_18px_38px_rgba(123,_63,_242,_0.22)] disabled:[opacity:0.7] disabled:[cursor:not-allowed]"
            >
              {isSubmitting ? "Sending..." : "Send Message"}
            </button>
          </form>
        </div>
      </section>
    </div>
  );
}

export default Contact;

﻿import { Routes, Route, useLocation } from "react-router-dom";

import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import ScrollToTop from "@ui/ScrollToTop";

import HomePage from "./pages/HomePage";
import About from "./components/About";
import Services from "./components/Services";
import HowItWorks from "./components/HowItWorks";
import Pricing from "./components/Pricing";
import Cities from "./components/Cities";
import Booking from "./components/Booking";
import Contact from "./components/Contact";
import AIAssistant from "./components/AIAssistant";

// import Login from "./components/Login";
import Auth from "./pages/Auth";
import Checkout from "./pages/Checkout";
import Success from "./pages/Success";
import NotFound from "./pages/NotFound";

import DashboardLayout from "./layouts/DashboardLayout";
import ProtectedRoute from "./routes/ProtectedRoute";

import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import RequestService from "./pages/RequestService";
import ServicesPortal from "./pages/ServicesPortal";
import Tracking from "./pages/Tracking";
import Settings from "./pages/Settings";

// Whitelist, not blacklist: only these top-level paths render the public
// marketing Navbar + Footer. Every other path â€” auth, dashboard, checkout
// confirmations, and anything unmatched (including a stray /admin/*,
// /staff/*, or /vendor/* URL typed into this app) â€” renders without the
// public layout. That also means the 404 page below never shows a
// half-broken navbar/footer around empty space.
const PUBLIC_LAYOUT_ROUTES = new Set([
  "/",
  "/about",
  "/services",
  "/how-it-works",
  "/pricing",
  "/cities",
  "/booking",
  "/contact",
  "/checkout",
  "/success",
]);

function App() {
  const location = useLocation();
  const showLayout = PUBLIC_LAYOUT_ROUTES.has(location.pathname);

  return (
    <main className="[width:100%] [min-height:100vh] [overflow-x:hidden]">
      <ScrollToTop />

      {showLayout && <Navbar />}

      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/about" element={<About />} />
        <Route path="/services" element={<Services />} />
        <Route path="/how-it-works" element={<HowItWorks />} />
        <Route path="/pricing" element={<Pricing />} />
        <Route path="/cities" element={<Cities />} />
        <Route path="/booking" element={<Booking />} />
        <Route path="/contact" element={<Contact />} />

        <Route path="/login" element={<Login />} />
        <Route path="/auth" element={<Auth />} />
        <Route path="/checkout" element={<Checkout />} />
        <Route path="/success" element={<Success />} />

        <Route element={<ProtectedRoute />}>
          <Route element={<DashboardLayout />}>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/request-service" element={<RequestService />} />
            <Route path="/services-portal" element={<ServicesPortal />} />
            <Route path="/tracking" element={<Tracking />} />
            <Route path="/settings" element={<Settings />} />
          </Route>
        </Route>

        {/* Catch-all: unknown routes, or a foreign app's route (e.g.
            /admin/dashboard, /staff/..., /vendor/...) opened on this app
            by mistake â€” shows a clean 404 instead of a blank page. */}
        <Route path="*" element={<NotFound />} />
      </Routes>

      {showLayout && <Footer />}

      <AIAssistant />
    </main>
  );
}

export default App;


export const PLAN_SERVICES = {
  "Property Guardian": {
    categories: {
      property: [
        "Property Inspection",
        "Plumbing Support",
        "Electrical Repair",
        "Painting Service",
        "Gardening",
        "House Cleaning",
        "Pest Control",
        "Tenant Assistance",
        "Renovation Support",
        "Appliance Repair",
        "Water Tank Cleaning",
        "AC Servicing",
        "Emergency Property Visit",
      ],
    },
  },

  "Family Guardian": {
    categories: {
      family: [
        "Doctor Appointment",
        "Hospital Visit Support",
        "Medicine Delivery",
        "Companionship Visit",
        "Emergency Assistance",
        "Wellness Check",
        "Diagnostic Test Support",
        "Bill Payment Assistance",
        "Grocery Assistance",
        "Teleconsultation Setup",
        "Senior Walk Companion",
        "Festival Visit",
        "Caregiver Assistance",
      ],
    },
  },

  "Guardian Premium": {
    categories: {
      property: [
        "Property Inspection",
        "Plumbing Support",
        "Electrical Repair",
        "Painting Service",
        "Gardening",
        "House Cleaning",
        "Pest Control",
        "Tenant Assistance",
        "Renovation Support",
        "Appliance Repair",
      ],

      family: [
        "Doctor Appointment",
        "Hospital Visit Support",
        "Medicine Delivery",
        "Companionship Visit",
        "Emergency Assistance",
        "Wellness Check",
      ],

      premium: [
        "Dedicated Care Manager",
        "Priority Emergency Response",
        "Airport Pickup",
        "Travel Assistance",
        "VIP Hospital Support",
        "Multi Property Management",
        "Premium Concierge",
        "Luxury Property Inspection",
        "Relationship Manager Call",
        "Special Care Assistance",
        "Event Coordination",
      ],
    },
  },
};

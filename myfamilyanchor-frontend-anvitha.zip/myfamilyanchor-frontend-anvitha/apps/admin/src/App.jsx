import { Routes, Route } from "react-router-dom";

import AdminLayout from "./layouts/AdminLayout";
import AdminLogin from "./pages/AdminLogin";
import AdminDashboard from "./pages/AdminDashboard";
import AdminRequestStatusPage from "./pages/AdminRequestStatusPage";
import AdminProtectedRoute from "./routes/AdminProtectedRoute";
import AdminNotFound from "./pages/AdminNotFound";

function App() {
  return (
    <Routes>
      <Route path="/admin/login" element={<AdminLogin />} />

      <Route element={<AdminProtectedRoute />}>
        <Route element={<AdminLayout />}>
          <Route path="/admin/dashboard" element={<AdminDashboard />} />

          <Route
            path="/admin/requests/:status"
            element={<AdminRequestStatusPage />}
          />
        </Route>
      </Route>

      {/* Catch-all: unknown admin routes, or the website/staff/vendor
          app's routes opened on this app by mistake — shows a clean 404
          instead of a blank page. */}
      <Route path="*" element={<AdminNotFound />} />
    </Routes>
  );
}

export default App;

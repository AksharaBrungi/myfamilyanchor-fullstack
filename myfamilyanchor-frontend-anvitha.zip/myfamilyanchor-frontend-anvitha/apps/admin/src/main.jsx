import { BrowserRouter } from "react-router-dom";
import { createRoot } from "react-dom/client";
import { Toaster } from "react-hot-toast";

import "./index.css";
import App from "./App";

import { AuthProvider } from "@auth/AuthContext";

createRoot(document.getElementById("root")).render(
  <BrowserRouter>
    <AuthProvider>
      <Toaster
        position="top-right"
        gutter={12}
        reverseOrder={false}
        containerStyle={{
          top: 90,
          right: 20,
          zIndex: 99999,
        }}
        toastOptions={{
          duration: 3500,
          style: {
            background: "#fff",
            color: "#1f2937",
            borderRadius: "16px",
            padding: "16px 18px",
            fontSize: "14px",
            fontWeight: 600,
            boxShadow: "0 16px 40px rgba(123,63,242,0.18)",
            border: "1px solid rgba(123,63,242,0.12)",
          },
        }}
      />

      <App />
    </AuthProvider>
  </BrowserRouter>,
);

import { NavLink, useSearchParams } from "react-router-dom";
import {
  FiHome,
  FiUsers,
  FiClipboard,
  FiUserCheck,
  FiBriefcase,
  FiCreditCard,
  FiBarChart2,
  FiMail,
  FiSettings,
  FiLogOut,
} from "react-icons/fi";

const NAV_ITEMS = [
  { tab: "dashboard", label: "Dashboard", icon: FiHome },
  { tab: "users", label: "Users", icon: FiUsers },
  { tab: "requests", label: "Service Requests", icon: FiClipboard },
  { tab: "staff", label: "Staff", icon: FiUserCheck },
  { tab: "vendors", label: "Vendors", icon: FiBriefcase },
  { tab: "payments", label: "Payments", icon: FiCreditCard },
  { tab: "analytics", label: "Analytics", icon: FiBarChart2 },
  { tab: "newsletters", label: "Newsletters", icon: FiMail },
  { tab: "settings", label: "Settings", icon: FiSettings },
];

export default function AdminSidebar({ onLogoutClick }) {
  const admin = (() => {
    try {
      return JSON.parse(localStorage.getItem("adminData")) || {};
    } catch {
      return {};
    }
  })();

  const [searchParams] = useSearchParams();
  const activeTab = searchParams.get("tab") || "dashboard";

  return (
    <aside className="flex h-full w-[280px] shrink-0 flex-col gap-6 overflow-y-auto border-l border-[rgba(123,63,242,0.08)] bg-gradient-to-b from-[rgba(255,255,255,0.98)] to-[rgba(255,248,252,0.90)] px-5 py-7 shadow-[-4px_0_32px_rgba(123,63,242,0.06)] backdrop-blur-xl lg:h-screen lg:border-r lg:border-l-0 lg:shadow-[4px_0_32px_rgba(123,63,242,0.06)]">
      {/* Brand */}
      <div className="flex shrink-0 flex-col gap-[22px]">
        <div className="flex items-center gap-3.5">
          <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-[#7b3ff2] via-[#ff5ca8] to-[#ff9b54] text-lg font-bold text-white shadow-[0_12px_28px_rgba(123,63,242,0.22)]">
            ⚡
          </div>
          <div>
            <h2 className="mb-0.5 text-[1.05rem] font-semibold leading-tight text-[#111827]">
              MyFamilyAnchor
            </h2>
            <p className="text-[0.74rem] text-[#6b7280]">Operations Center</p>
          </div>
        </div>

        {/* Admin user card */}
        <div className="flex shrink-0 items-center gap-3 rounded-[22px] border border-white/80 bg-white/72 px-4 py-4 shadow-[0_8px_28px_rgba(123,63,242,0.10)] backdrop-blur-xl">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-[#7b3ff2] to-[#ff5ca8] text-[1.05rem] font-extrabold text-white">
            {admin?.name?.charAt(0)?.toUpperCase() || "A"}
          </div>
          <div className="min-w-0">
            <h3 className="mb-0.5 overflow-hidden text-ellipsis whitespace-nowrap text-base font-semibold text-[#111827]">
              {admin?.name || "Super Admin"}
            </h3>
            <span className="capitalize text-[0.8rem] text-[#6b7280]">
              {admin?.role || "Administrator"}
            </span>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex shrink-0 flex-col gap-1">
        <p className="mb-1 px-2 text-xs font-bold uppercase tracking-[0.08em] text-slate-400">
          Operations
        </p>

        {NAV_ITEMS.map(({ tab, label, icon: Icon }) => {
          const isActive = activeTab === tab;
          return (
            <NavLink
              key={tab}
              to={`/admin/dashboard?tab=${tab}`}
              className={`relative flex min-h-[52px] w-full cursor-pointer items-center gap-3 rounded-2xl border-none px-[18px] font-[inherit] text-[0.92rem] font-extrabold no-underline transition-[background,color,box-shadow] duration-[220ms] ease-in-out ${
                isActive
                  ? "bg-[rgba(123,63,242,0.08)] text-[#7b3ff2] shadow-[0_8px_24px_rgba(123,63,242,0.07)]"
                  : "bg-transparent text-[#374151] hover:bg-[rgba(123,63,242,0.08)] hover:text-[#7b3ff2]"
              }`}
            >
              {isActive && (
                <span className="absolute left-2 h-5 w-1 rounded-full bg-gradient-to-b from-[#7b3ff2] to-[#ff5ca8]" />
              )}
              <Icon size={18} />
              {label}
            </NavLink>
          );
        })}

        <button
          type="button"
          onClick={onLogoutClick}
          className="flex min-h-[52px] w-full cursor-pointer items-center gap-3 rounded-2xl border-none bg-transparent px-[18px] font-[inherit] text-[0.92rem] font-extrabold text-[#6b7280] transition-[background,color] duration-[220ms] ease-in-out hover:bg-[rgba(220,38,38,0.07)] hover:text-[#dc2626]"
        >
          <FiLogOut size={18} />
          Logout
        </button>
      </nav>
    </aside>
  );
}

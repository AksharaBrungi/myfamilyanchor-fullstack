import { useState, useEffect } from "react";
import API from "@api/axios";
import toast from "react-hot-toast";
import { buildTemplateHTML } from "@utils/buildTemplateHTML";

function AdminNewsletter() {
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [subscribers, setSubscribers] = useState([]);
  const [history, setHistory] = useState([]);
  const [selectedTemplate, setSelectedTemplate] = useState("");
  const [templates, setTemplates] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortOrder, setSortOrder] = useState("latest");
  const [showPreview, setShowPreview] = useState(false);
  const [previewMode, setPreviewMode] = useState("desktop");

  const loadData = async () => {
    try {
      const token = localStorage.getItem("adminToken");

      const [subs, campaigns, templateRes] = await Promise.all([
        API.get("/subscribe/all", {
          headers: { Authorization: `Bearer ${token}` },
        }),
        API.get("/newsletter/history", {
          headers: { Authorization: `Bearer ${token}` },
        }),
        API.get("/newsletter/templates", {
          headers: { Authorization: `Bearer ${token}` },
        }),
      ]);

      setSubscribers(subs.data);
      setHistory(campaigns.data);
      setTemplates(templateRes.data);
    } catch (error) {
      console.error(error);
      toast.error("Failed to load newsletter data");
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const filteredSubscribers = [...subscribers]
    .filter((subscriber) =>
      subscriber.email.toLowerCase().includes(searchTerm.toLowerCase()),
    )
    .sort((a, b) => {
      if (sortOrder === "latest") {
        return new Date(b.subscribedAt) - new Date(a.subscribedAt);
      }
      return new Date(a.subscribedAt) - new Date(b.subscribedAt);
    });

  const previewHTML = buildTemplateHTML(subject, message);

  const handleDeactivate = async (id) => {
    try {
      const token = localStorage.getItem("adminToken");

      await API.put(
        `/subscribe/${id}/deactivate`,
        {},
        { headers: { Authorization: `Bearer ${token}` } },
      );

      toast.success("Subscriber deactivated");
      loadData();
    } catch {
      toast.error("Failed to deactivate");
    }
  };

  const handleActivate = async (id) => {
    try {
      const token = localStorage.getItem("adminToken");

      await API.put(
        `/subscribe/${id}/activate`,
        {},
        { headers: { Authorization: `Bearer ${token}` } },
      );

      toast.success("Subscriber activated");
      loadData();
    } catch {
      toast.error("Failed to activate");
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete subscriber permanently?")) return;

    try {
      const token = localStorage.getItem("adminToken");

      await API.delete(`/subscribe/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      toast.success("Subscriber deleted");
      loadData();
    } catch {
      toast.error("Failed to delete");
    }
  };

  const handleTemplateChange = (templateName) => {
    setSelectedTemplate(templateName);

    const template = templates.find((t) => t.name === templateName);
    if (!template) return;

    setSubject(template.subject);
    setMessage(template.htmlTemplate.replace(/<[^>]*>/g, "").trim());
  };

  const sendNewsletter = async () => {
    if (!subject.trim() || !message.trim()) {
      return toast.error("Subject and message are required");
    }

    try {
      setLoading(true);

      const token = localStorage.getItem("adminToken");

      const { data } = await API.post(
        "/newsletter/send",
        { subject, message },
        { headers: { Authorization: `Bearer ${token}` } },
      );

      toast.success(`Newsletter Sent to ${data.sentTo} subscriber(s)`);
      setSubject("");
      setMessage("");
      await loadData();
    } catch (error) {
      toast.error(error.response?.data?.message || "Failed to send");
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="[display:flex] [flex-direction:column] [gap:24px]">
      {/* ── Header ── */}
      <div className="section-header">
        <h2>Newsletter Manager</h2>
        <p>
          Send updates, offers, announcements and news directly to all
          newsletter subscribers.
        </p>
      </div>

      {/* ── Stats ── */}
      <div className="[display:grid] [grid-template-columns:repeat(auto-fit,_minmax(220px,_1fr))] [gap:20px]">
        <div className="[background:white] [border-radius:22px] [padding:24px] [border:1px_solid_rgba(123,_63,_242,_0.08)] [display:flex] [flex-direction:column] [gap:8px] [&_span]:[font-size:0.85rem] [&_span]:[color:rgba(15,_23,_42,_0.6)] [&_span]:[font-weight:600] [&_span]:[text-transform:uppercase] [&_span]:[letter-spacing:0.05em] [&_strong]:[font-size:2.4rem] [&_strong]:[color:#7b3ff2] [&_strong]:[line-height:1]">
          <span>Total Subscribers</span>
          <strong>{subscribers.length}</strong>
        </div>

        <div className="[background:white] [border-radius:22px] [padding:24px] [border:1px_solid_rgba(123,_63,_242,_0.08)] [display:flex] [flex-direction:column] [gap:8px] [&_span]:[font-size:0.85rem] [&_span]:[color:rgba(15,_23,_42,_0.6)] [&_span]:[font-weight:600] [&_span]:[text-transform:uppercase] [&_span]:[letter-spacing:0.05em] [&_strong]:[font-size:2.4rem] [&_strong]:[color:#7b3ff2] [&_strong]:[line-height:1]">
          <span>Total Campaigns</span>
          <strong>{history.length}</strong>
        </div>
      </div>

      {/* ── Create Newsletter ── */}
      <div className="[background:white] [padding:28px] [border-radius:24px] [border:1px_solid_rgba(123,_63,_242,_0.08)] [display:flex] [flex-direction:column] [gap:16px] [&_h3]:[font-size:1.2rem] [&_h3]:[color:#0f172a] [&_h3]:[margin:0_0_4px] [&_input[type='text']]:[width:100%] [&_input[type='text']]:[padding:14px] [&_input[type='text']]:[border-radius:14px] [&_input[type='text']]:[border:1px_solid_#e5e7eb] [&_input[type='text']]:[font-size:0.95rem] [&_input[type='text']]:[color:#0f172a] [&_input[type='text']]:[outline:none] [&_input[type='text']]:[transition:border-color_0.2s,_box-shadow_0.2s] [&_input[type='text']]:[box-sizing:border-box] [&_textarea]:[width:100%] [&_textarea]:[padding:14px] [&_textarea]:[border-radius:14px] [&_textarea]:[border:1px_solid_#e5e7eb] [&_textarea]:[font-size:0.95rem] [&_textarea]:[color:#0f172a] [&_textarea]:[outline:none] [&_textarea]:[transition:border-color_0.2s,_box-shadow_0.2s] [&_textarea]:[box-sizing:border-box] [&_input[type='text']:focus]:[border-color:#7b3ff2] [&_input[type='text']:focus]:[box-shadow:0_0_0_4px_rgba(123,_63,_242,_0.08)] [&_textarea:focus]:[border-color:#7b3ff2] [&_textarea:focus]:[box-shadow:0_0_0_4px_rgba(123,_63,_242,_0.08)] [&_textarea]:[min-height:180px] [&_textarea]:[resize:vertical] [&_textarea]:[line-height:1.6]">
        <h3>Create Newsletter</h3>

        {/* Template picker lives inside the form */}
        <div className="[display:flex] [flex-direction:column] [gap:8px]">
          <label className="[font-size:0.78rem] [font-weight:700] [color:rgba(15,_23,_42,_0.6)] [text-transform:uppercase] [letter-spacing:0.05em]">Choose Template</label>
          <select
            className="[width:100%] [padding:14px_18px] [border-radius:14px] [border:1px_solid_rgba(123,_63,_242,_0.15)] [background:white] [color:#0f172a] [font-size:0.95rem] [font-weight:500] [outline:none] [cursor:pointer] [transition:border-color_0.2s,_box-shadow_0.2s] hover:[border-color:#7b3ff2] focus:[border-color:#7b3ff2] focus:[box-shadow:0_0_0_4px_rgba(123,_63,_242,_0.1)]"
            value={selectedTemplate}
            onChange={(e) => handleTemplateChange(e.target.value)}
          >
            <option value="">Select Template</option>
            {templates.map((template) => (
              <option key={template._id} value={template.name}>
                {template.name}
              </option>
            ))}
          </select>
        </div>

        <input
          type="text"
          placeholder="Newsletter Subject"
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
        />

        <textarea
          placeholder="Write your newsletter message..."
          value={message}
          onChange={(e) => setMessage(e.target.value)}
        />

        <div className="[display:flex] [gap:12px] [flex-wrap:wrap] [&_.save-meta-btn]:[flex:2] [&_.save-meta-btn]:[min-width:160px] [&_.save-meta-btn]:[padding:13px_20px] [&_.save-meta-btn]:[font-size:0.9rem] max-[640px]:[flex-direction:column] max-[640px]:[&_.save-meta-btn]:[flex:unset] max-[640px]:[&_.save-meta-btn]:[width:100%]">
          <button
            type="button"
            className="[flex:1] [min-width:140px] [padding:13px_20px] [border:1px_solid_rgba(123,_63,_242,_0.3)] [border-radius:14px] [background:white] [color:#7b3ff2] [font-weight:700] [font-size:0.9rem] [cursor:pointer] [transition:background_0.2s,_border-color_0.2s] hover:[background:rgba(123,_63,_242,_0.06)] hover:[border-color:#7b3ff2] max-[640px]:[flex:unset] max-[640px]:[width:100%]"
            onClick={() => setShowPreview(true)}
          >
            Preview Newsletter
          </button>

          <button
            className="save-meta-btn"
            onClick={sendNewsletter}
            disabled={loading}
          >
            {loading ? "Sending Newsletter..." : "Send Newsletter"}
          </button>
        </div>
      </div>

      {/* ── Recent Campaigns ── */}
      <div className="[background:white] [border-radius:24px] [padding:28px] [border:1px_solid_rgba(123,_63,_242,_0.08)] [display:flex] [flex-direction:column] [gap:0] [&_h3]:[font-size:1.2rem] [&_h3]:[color:#0f172a] [&_h3]:[margin:0_0_16px]">
        <h3>Recent Campaigns</h3>

        {history.length === 0 ? (
          <p className="[color:rgba(15,_23,_42,_0.5)] [font-size:0.9rem]">No newsletters sent yet.</p>
        ) : (
          history.map((item) => (
            <div key={item._id} className="[padding:18px] [border-radius:18px] [background:#fafafa] [margin-top:12px] [border:1px_solid_rgba(123,_63,_242,_0.06)] [&_h4]:[margin:0_0_6px] [&_h4]:[color:#0f172a] [&_h4]:[font-size:1rem] [&_p]:[margin:0_0_4px] [&_p]:[font-size:0.9rem] [&_p]:[color:rgba(15,_23,_42,_0.7)] [&_small]:[color:rgba(15,_23,_42,_0.5)] [&_small]:[font-size:0.8rem]">
              <h4>{item.subject}</h4>
              <p>Sent to {item.sentCount} subscriber(s)</p>
              <small>{new Date(item.createdAt).toLocaleString()}</small>
            </div>
          ))
        )}
      </div>

      {/* ── Subscriber Management ── */}
      <div className="[background:white] [border-radius:24px] [padding:28px] [border:1px_solid_rgba(123,_63,_242,_0.08)] [display:flex] [flex-direction:column] [gap:16px] [&_h3]:[font-size:1.2rem] [&_h3]:[color:#0f172a] [&_h3]:[margin:0]">
        <h3>Subscribers</h3>

        {/* Search + Sort toolbar */}
        <div className="[display:flex] [gap:12px] [align-items:center] max-[640px]:[flex-direction:column] max-[640px]:[align-items:stretch]">
          <input
            type="text"
            placeholder="Search subscribers..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="[flex:1] [padding:12px_16px] [border-radius:14px] [border:1px_solid_#e5e7eb] [font-size:0.9rem] [color:#0f172a] [outline:none] [transition:border-color_0.2s,_box-shadow_0.2s] focus:[border-color:#7b3ff2] focus:[box-shadow:0_0_0_4px_rgba(123,_63,_242,_0.08)]"
          />

          <select
            className="[padding:12px_16px] [border-radius:14px] [border:1px_solid_#e5e7eb] [background:white] [font-size:0.9rem] [color:#0f172a] [font-weight:500] [outline:none] [cursor:pointer] [transition:border-color_0.2s] [white-space:nowrap] focus:[border-color:#7b3ff2] max-[640px]:[width:100%]"
            value={sortOrder}
            onChange={(e) => setSortOrder(e.target.value)}
          >
            <option value="latest">Latest First</option>
            <option value="oldest">Oldest First</option>
          </select>
        </div>

        {/* Subscriber list */}
        <div className="[display:flex] [flex-direction:column] [gap:12px]">
          {filteredSubscribers.map((subscriber) => (
            <div key={subscriber._id} className="[display:flex] [justify-content:space-between] [align-items:flex-end] [gap:16px] [padding:20px] [border-radius:18px] [background:#fafafa] [border:1px_solid_rgba(123,_63,_242,_0.06)] [transition:box-shadow_0.2s] hover:[box-shadow:0_4px_18px_rgba(123,_63,_242,_0.08)] max-[640px]:[flex-direction:column] max-[640px]:[align-items:flex-start]">
              {/* Left: info */}
              <div className="[display:flex] [flex-direction:column] [gap:4px] [&_h4]:[margin:0] [&_h4]:[font-size:0.95rem] [&_h4]:[color:#0f172a] [&_h4]:[font-weight:700] [&_p]:[margin:0] [&_p]:[font-size:0.82rem] [&_p]:[color:rgba(15,_23,_42,_0.55)]">
                <h4>{subscriber.email}</h4>
                <p>
                  Joined:{" "}
                  {new Date(subscriber.subscribedAt).toLocaleDateString()}
                </p>
                <span
                  className={
                    subscriber.isActive ? "active-status" : "inactive-status"
                  }
                >
                  {subscriber.isActive ? "Active" : "Inactive"}
                </span>
              </div>

              {/* Right: actions */}
              <div className="[display:flex] [flex-direction:column] [gap:8px] [align-items:flex-end] [flex-shrink:0] max-[640px]:[flex-direction:row] max-[640px]:[align-items:center] max-[640px]:[width:100%]">
                {subscriber.isActive ? (
                  <button
                    className="[border:none] [padding:9px_18px] [border-radius:10px] [font-size:0.85rem] [font-weight:700] [cursor:pointer] [width:110px] [text-align:center] [transition:opacity_0.15s] hover:[opacity:0.85] max-[640px]:[flex:1] [background:#fff7ed] [color:#d97706]"
                    onClick={() => handleDeactivate(subscriber._id)}
                  >
                    Deactivate
                  </button>
                ) : (
                  <button
                    className="[border:none] [padding:9px_18px] [border-radius:10px] [font-size:0.85rem] [font-weight:700] [cursor:pointer] [width:110px] [text-align:center] [transition:opacity_0.15s] hover:[opacity:0.85] max-[640px]:[flex:1] [background:#dcfce7] [color:#16a34a]"
                    onClick={() => handleActivate(subscriber._id)}
                  >
                    Activate
                  </button>
                )}

                <button
                  className="[border:none] [padding:9px_18px] [border-radius:10px] [font-size:0.85rem] [font-weight:700] [cursor:pointer] [width:110px] [text-align:center] [transition:opacity_0.15s] hover:[opacity:0.85] max-[640px]:[flex:1] [background:#fee2e2] [color:#dc2626]"
                  onClick={() => handleDelete(subscriber._id)}
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ── Preview Modal ── */}
      {showPreview && (
        <div className="[position:fixed] [inset:0] [background:rgba(15,_23,_42,_0.6)] [backdrop-filter:blur(6px)] [-webkit-backdrop-filter:blur(6px)] [display:flex] [justify-content:center] [align-items:center] [z-index:9999]">
          <div className="[width:95%] [max-width:1100px] [background:white] [border-radius:24px] [padding:24px] [display:flex] [flex-direction:column] [gap:16px]">
            <div className="[display:flex] [justify-content:space-between] [align-items:center]">
              <div className="[display:flex] [gap:8px] [&_button]:[padding:9px_20px] [&_button]:[border-radius:10px] [&_button]:[border:1px_solid_#e5e7eb] [&_button]:[background:white] [&_button]:[color:rgba(15,_23,_42,_0.65)] [&_button]:[font-weight:600] [&_button]:[font-size:0.88rem] [&_button]:[cursor:pointer] [&_button]:[transition:all_0.2s] [&_button.active]:[background:rgba(123,_63,_242,_0.08)] [&_button.active]:[border-color:rgba(123,_63,_242,_0.3)] [&_button.active]:[color:#7b3ff2]">
                <button
                  type="button"
                  className={previewMode === "desktop" ? "active" : ""}
                  onClick={() => setPreviewMode("desktop")}
                >
                  Desktop
                </button>
                <button
                  type="button"
                  className={previewMode === "mobile" ? "active" : ""}
                  onClick={() => setPreviewMode("mobile")}
                >
                  Mobile
                </button>
              </div>

              <button
                type="button"
                className="[width:40px] [height:40px] [border:none] [border-radius:12px] [background:rgba(123,_63,_242,_0.08)] [color:#7b3ff2] [font-size:1rem] [font-weight:700] [cursor:pointer] [transition:background_0.2s] hover:[background:rgba(123,_63,_242,_0.15)]"
                onClick={() => setShowPreview(false)}
              >
                ✕
              </button>
            </div>

            <iframe
              title="Newsletter Preview"
              srcDoc={previewHTML}
              className={
                previewMode === "mobile" ? "mobile-preview" : "desktop-preview"
              }
            />
          </div>
        </div>
      )}
    </section>
  );
}

export default AdminNewsletter;

import { Link } from "react-router-dom";

function AdminNotFound() {
  return (
    <section className="flex min-h-screen w-full items-center justify-center overflow-hidden bg-gradient-to-br from-[#f4f0ff] via-[#fdf2f8] to-[#fff7ed] px-6 py-16">
      <div className="relative w-full max-w-xl rounded-[32px] border border-white/80 bg-white/70 p-10 text-center shadow-[0_28px_80px_rgba(123,63,242,0.14)] backdrop-blur-xl sm:p-14">
        <span className="text-xs font-extrabold uppercase tracking-[0.18em] text-[#7b3ff2]">
          Operations Center
        </span>

        <h1 className="mt-4 bg-gradient-to-r from-[#7b3ff2] via-[#ff5ca8] to-[#ff9b54] bg-clip-text text-[clamp(4rem,12vw,7rem)] font-black leading-none text-transparent">
          404
        </h1>

        <h2 className="mt-2 text-2xl font-black text-[#111827] sm:text-3xl">
          Console page not found
        </h2>
        <p className="mx-auto mt-4 max-w-sm text-slate-500">
          This admin route doesn't exist, or the link you followed is broken.
          Head back to the operations dashboard to continue.
        </p>

        <div className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <Link
            to="/admin/dashboard"
            className="inline-flex min-h-[52px] w-full items-center justify-center rounded-2xl bg-gradient-to-r from-[#7b3ff2] via-[#ff5ca8] to-[#ff9b54] px-7 text-sm font-extrabold text-white no-underline shadow-[0_16px_32px_rgba(255,92,168,0.25)] transition hover:-translate-y-0.5 hover:shadow-[0_20px_40px_rgba(255,92,168,0.35)] sm:w-auto"
          >
            Back to Dashboard
          </Link>
          <Link
            to="/admin/login"
            className="inline-flex min-h-[52px] w-full items-center justify-center rounded-2xl border border-[#7b3ff2]/20 bg-white px-7 text-sm font-extrabold text-[#7b3ff2] no-underline transition hover:-translate-y-0.5 hover:bg-[#7b3ff2]/5 sm:w-auto"
          >
            Admin Login
          </Link>
        </div>
      </div>
    </section>
  );
}

export default AdminNotFound;

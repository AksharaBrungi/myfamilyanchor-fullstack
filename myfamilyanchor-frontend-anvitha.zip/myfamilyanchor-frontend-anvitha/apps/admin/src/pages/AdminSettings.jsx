import { useEffect, useState } from "react";
import { FiEdit, FiUser, FiLock } from "react-icons/fi";
import toast from "react-hot-toast";
import { useAuth } from "@auth/AuthContext";
import API from "@api/axios";
import PasswordInput from "@ui/PasswordInput";

function AdminSettings() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [currentUser, setCurrentUser] = useState(null);
  const [editingName, setEditingName] = useState(false);
  const [editingEmail, setEditingEmail] = useState(false);
  const [editingPhone, setEditingPhone] = useState(false);

  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [passwordVerified, setPasswordVerified] = useState(false);
  const [verifyingPassword, setVerifyingPassword] = useState(false);

  useEffect(() => {
    fetchProfile();
  }, []);

  useEffect(() => {
    if (!passwordData.currentPassword) {
      setPasswordVerified(false);
      setVerifyingPassword(false);
      return;
    }

    let active = true;

    const verifyTimer = setTimeout(async () => {
      try {
        setVerifyingPassword(true);
        await API.post("/admin/verify-password", {
          currentPassword: passwordData.currentPassword,
        });

        if (active) {
          setPasswordVerified(true);
        }
      } catch {
        if (active) {
          setPasswordVerified(false);
        }
      } finally {
        if (active) {
          setVerifyingPassword(false);
        }
      }
    }, 600);

    return () => {
      active = false;
      clearTimeout(verifyTimer);
    };
  }, [passwordData.currentPassword]);

  const fetchProfile = async () => {
    try {
      const { data } = await API.get("/admin/me");

      setCurrentUser(data);

      setName(data.name || "");
      setEmail(data.email || "");
      setPhone(data.phone || "");
    } catch {
      toast.error("Failed to load profile");
    }
  };

  const updateName = async () => {
    try {
      await API.put("/admin/profile", {
        name,
      });

      await fetchProfile();

      setEditingName(false);

      toast.success("Name updated");
    } catch (error) {
      toast.error(error.response?.data?.message || "Failed to update name");
    }
  };

  const updateEmail = async () => {
    try {
      await API.put("/admin/profile", {
        email,
      });

      await fetchProfile();

      setEditingEmail(false);

      toast.success("Email updated");
    } catch (error) {
      toast.error(error.response?.data?.message || "Failed to update email");
    }
  };

  const updatePhone = async () => {
    try {
      await API.put("/admin/profile", {
        phone,
      });

      await fetchProfile();

      setEditingPhone(false);

      toast.success("Phone updated");
    } catch (error) {
      toast.error(
        error.response?.data?.message || "Failed to update phone number",
      );
    }
  };

  const updatePassword = async () => {
    if (!passwordVerified) {
      return toast.error("Verify your current password first");
    }

    if (passwordData.newPassword !== passwordData.confirmPassword) {
      return toast.error("Passwords do not match");
    }

    try {
      await API.put("/admin/change-password", passwordData);

      toast.success("Password updated");

      setPasswordData({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      });
      setPasswordVerified(false);
    } catch (error) {
      toast.error(error.response?.data?.message || "Failed to update password");
    }
  };

  return (
    <section className="[width:100%] [max-width:1240px] [margin:0_auto] [display:flex] [flex-direction:column] [gap:24px]">
      <div className="workspace-header">
        <div>
          <span className="[color:#7b3ff2] [font-size:0.78rem] [font-weight:800] [letter-spacing:0.14em] [text-transform:uppercase]">Account Settings</span>
          <h1>Profile & Security</h1>
        </div>
      </div>

      <div className="[padding:38px_42px] [border-radius:32px] [background:rgba(255,_255,_255,_0.72)] [border:1px_solid_rgba(255,_255,_255,_0.84)] [box-shadow:0_28px_80px_rgba(123,_63,_242,_0.08)] [-webkit-backdrop-filter:blur(18px)] [backdrop-filter:blur(18px)] [transition:all_0.3s_ease] hover:[transform:translateY(-2px)] hover:[box-shadow:0_34px_90px_rgba(123,_63,_242,_0.12)] [&_input]:[width:100%] [&_input]:[min-height:58px] [&_input]:[padding:0_18px] [&_input]:[border-radius:18px] [&_input]:[border:1px_solid_rgba(148,_163,_184,_0.18)] [&_input]:[background:rgba(255,_255,_255,_0.9)] [&_input]:[font-size:1rem] [&_input]:[transition:all_0.25s_ease] [&_input:focus]:[outline:none] [&_input:focus]:[border-color:rgba(123,_63,_242,_0.45)] [&_input:focus]:[box-shadow:0_0_0_4px_rgba(123,_63,_242,_0.08),_0_12px_30px_rgba(123,_63,_242,_0.08)] [&_input:disabled]:[background:#f8fafc] [&_input:disabled]:[color:#64748b] [&_input:disabled]:[cursor:not-allowed] [&_input:disabled]:[opacity:0.9] max-[768px]:[padding:24px]">
        <div className="[display:flex] [align-items:center] [gap:14px] [margin-bottom:24px] [&_h2]:[margin:0] [&_h2]:[font-size:2rem] [&_h2]:[color:#111827]">
          <div className="[&_svg]:[width:26px] [&_svg]:[height:26px] [width:56px] [height:56px] [border-radius:18px] [display:flex] [align-items:center] [justify-content:center] [background:linear-gradient(_135deg,_rgba(123,_63,_242,_0.12),_rgba(255,_92,_168,_0.12)_)] [color:#7b3ff2] [font-size:1.5rem]">
            <FiUser />
            {/* <i className="ti ti-user-circle"></i> */}
          </div>

          <h2>Personal Information</h2>
        </div>

        <div className="[display:flex] [align-items:flex-end] [gap:16px] [margin-bottom:24px] max-[768px]:[flex-direction:column] max-[768px]:[align-items:stretch]">
          <div className="[flex:1] [&_label]:[display:block] [&_label]:[margin-bottom:10px] [&_label]:[font-weight:700] [&_label]:[color:#475569]">
            <label>Full Name</label>

            <input
              type="text"
              disabled={!editingName}
              placeholder="Enter your full name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          <button
            type="button"
            className="[width:58px] [height:58px] [border:none] [border-radius:18px] [display:flex] [align-items:center] [justify-content:center] [cursor:pointer] [color:#7b3ff2] [font-size:1.25rem] [background:rgba(123,_63,_242,_0.08)] [transition:all_0.25s_ease] hover:[background:rgba(123,_63,_242,_0.15)] hover:[transform:translateY(-2px)] [&_svg]:[width:22px] [&_svg]:[height:22px]"
            onClick={() => setEditingName(!editingName)}
          >
            <FiEdit />
          </button>

          <button
            className="[height:58px] [min-width:140px] [padding:0_24px] [border:none] [border-radius:18px] [color:white] [font-weight:800] [background:linear-gradient(135deg,_#7b3ff2,_#ff5ca8)] [box-shadow:0_12px_24px_rgba(123,_63,_242,_0.15)] [transition:all_0.25s_ease] hover:[transform:translateY(-2px)] hover:[box-shadow:0_18px_32px_rgba(123,_63,_242,_0.22)] disabled:[opacity:0.5] disabled:[cursor:not-allowed] disabled:[transform:none] disabled:[box-shadow:none] max-[768px]:[width:100%]"
            disabled={!editingName}
            onClick={updateName}
          >
            Update
          </button>
        </div>

        <div className="[display:flex] [align-items:flex-end] [gap:16px] [margin-bottom:24px] max-[768px]:[flex-direction:column] max-[768px]:[align-items:stretch]">
          <div className="[flex:1] [&_label]:[display:block] [&_label]:[margin-bottom:10px] [&_label]:[font-weight:700] [&_label]:[color:#475569]">
            <label>Email Address</label>

            <input
              type="email"
              disabled={!editingEmail}
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>

          <button
            type="button"
            className="[width:58px] [height:58px] [border:none] [border-radius:18px] [display:flex] [align-items:center] [justify-content:center] [cursor:pointer] [color:#7b3ff2] [font-size:1.25rem] [background:rgba(123,_63,_242,_0.08)] [transition:all_0.25s_ease] hover:[background:rgba(123,_63,_242,_0.15)] hover:[transform:translateY(-2px)] [&_svg]:[width:22px] [&_svg]:[height:22px]"
            onClick={() => setEditingEmail(!editingEmail)}
          >
            <FiEdit />
          </button>

          <button
            className="[height:58px] [min-width:140px] [padding:0_24px] [border:none] [border-radius:18px] [color:white] [font-weight:800] [background:linear-gradient(135deg,_#7b3ff2,_#ff5ca8)] [box-shadow:0_12px_24px_rgba(123,_63,_242,_0.15)] [transition:all_0.25s_ease] hover:[transform:translateY(-2px)] hover:[box-shadow:0_18px_32px_rgba(123,_63,_242,_0.22)] disabled:[opacity:0.5] disabled:[cursor:not-allowed] disabled:[transform:none] disabled:[box-shadow:none] max-[768px]:[width:100%]"
            disabled={!editingEmail}
            onClick={updateEmail}
          >
            Update
          </button>
        </div>

        <div className="[display:flex] [align-items:flex-end] [gap:16px] [margin-bottom:24px] max-[768px]:[flex-direction:column] max-[768px]:[align-items:stretch]">
          <div className="[flex:1] [&_label]:[display:block] [&_label]:[margin-bottom:10px] [&_label]:[font-weight:700] [&_label]:[color:#475569]">
            <label>Phone Number</label>

            <input
              type="text"
              disabled={!editingPhone}
              placeholder="Enter your number"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
            />
          </div>

          <button
            type="button"
            className="[width:58px] [height:58px] [border:none] [border-radius:18px] [display:flex] [align-items:center] [justify-content:center] [cursor:pointer] [color:#7b3ff2] [font-size:1.25rem] [background:rgba(123,_63,_242,_0.08)] [transition:all_0.25s_ease] hover:[background:rgba(123,_63,_242,_0.15)] hover:[transform:translateY(-2px)] [&_svg]:[width:22px] [&_svg]:[height:22px]"
            onClick={() => setEditingPhone(!editingPhone)}
          >
            <FiEdit />
          </button>

          <button
            className="[height:58px] [min-width:140px] [padding:0_24px] [border:none] [border-radius:18px] [color:white] [font-weight:800] [background:linear-gradient(135deg,_#7b3ff2,_#ff5ca8)] [box-shadow:0_12px_24px_rgba(123,_63,_242,_0.15)] [transition:all_0.25s_ease] hover:[transform:translateY(-2px)] hover:[box-shadow:0_18px_32px_rgba(123,_63,_242,_0.22)] disabled:[opacity:0.5] disabled:[cursor:not-allowed] disabled:[transform:none] disabled:[box-shadow:none] max-[768px]:[width:100%]"
            disabled={!editingPhone}
            onClick={updatePhone}
          >
            Update
          </button>
        </div>
      </div>

      <div className="[padding:38px_42px] [border-radius:32px] [background:rgba(255,_255,_255,_0.72)] [border:1px_solid_rgba(255,_255,_255,_0.84)] [box-shadow:0_28px_80px_rgba(123,_63,_242,_0.08)] [-webkit-backdrop-filter:blur(18px)] [backdrop-filter:blur(18px)] [transition:all_0.3s_ease] hover:[transform:translateY(-2px)] hover:[box-shadow:0_34px_90px_rgba(123,_63,_242,_0.12)] [&_input]:[width:100%] [&_input]:[min-height:58px] [&_input]:[padding:0_18px] [&_input]:[border-radius:18px] [&_input]:[border:1px_solid_rgba(148,_163,_184,_0.18)] [&_input]:[background:rgba(255,_255,_255,_0.9)] [&_input]:[font-size:1rem] [&_input]:[transition:all_0.25s_ease] [&_input:focus]:[outline:none] [&_input:focus]:[border-color:rgba(123,_63,_242,_0.45)] [&_input:focus]:[box-shadow:0_0_0_4px_rgba(123,_63,_242,_0.08),_0_12px_30px_rgba(123,_63,_242,_0.08)] [&_input:disabled]:[background:#f8fafc] [&_input:disabled]:[color:#64748b] [&_input:disabled]:[cursor:not-allowed] [&_input:disabled]:[opacity:0.9] max-[768px]:[padding:24px]">
        <div className="[display:flex] [align-items:center] [gap:14px] [margin-bottom:24px] [&_h2]:[margin:0] [&_h2]:[font-size:2rem] [&_h2]:[color:#111827]">
          <div className="[&_svg]:[width:26px] [&_svg]:[height:26px] [width:56px] [height:56px] [border-radius:18px] [display:flex] [align-items:center] [justify-content:center] [background:linear-gradient(_135deg,_rgba(123,_63,_242,_0.12),_rgba(255,_92,_168,_0.12)_)] [color:#7b3ff2] [font-size:1.5rem]">
            <FiLock />
          </div>

          <h2>Change Password</h2>
        </div>

        <div className="[display:flex] [flex-direction:column] [gap:18px]">
          <PasswordInput
            placeholder="Current Password"
            value={passwordData.currentPassword}
            onChange={(e) => {
              setPasswordVerified(false);
              setPasswordData({
                ...passwordData,
                currentPassword: e.target.value,
                newPassword: "",
                confirmPassword: "",
              });
            }}
          />

          <PasswordInput
            disabled={!passwordVerified || verifyingPassword}
            placeholder="New Password"
            value={passwordData.newPassword}
            onChange={(e) =>
              setPasswordData({
                ...passwordData,
                newPassword: e.target.value,
              })
            }
          />

          <PasswordInput
            disabled={!passwordVerified || verifyingPassword}
            placeholder="Confirm Password"
            value={passwordData.confirmPassword}
            onChange={(e) =>
              setPasswordData({
                ...passwordData,
                confirmPassword: e.target.value,
              })
            }
          />

          <button
            className="[width:100%] [min-height:60px] [margin-top:12px] [border:none] [border-radius:18px] [font-size:1rem] [font-weight:800] [color:white] [cursor:pointer] [transition:all_0.3s_ease] [background:linear-gradient(135deg,_#7b3ff2,_#ff5ca8,_#ff9b54)] [box-shadow:0_20px_36px_rgba(255,_92,_168,_0.2)] hover:[transform:translateY(-2px)] hover:[box-shadow:0_24px_42px_rgba(255,_92,_168,_0.28)] active:[transform:translateY(0)] disabled:[opacity:0.58] disabled:[cursor:not-allowed] disabled:[transform:none] disabled:[box-shadow:none]"
            disabled={!passwordVerified || verifyingPassword}
            onClick={updatePassword}
          >
            Update Password
          </button>
        </div>
      </div>
    </section>
  );
}

export default AdminSettings;

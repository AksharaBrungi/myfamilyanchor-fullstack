import { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import toast from "react-hot-toast";
import API from "@api/axios";
import EvidenceViewerModal from "@ui/EvidenceViewerModal";
import LoadingPage from "@ui/Loadingpage";

const STATUS_CONFIG = {
  pending: {
    label: "Pending Requests",
    shortLabel: "Pending",
    status: "pending",
    tone: "pending",
    description: "Requests waiting for staff and vendor assignment.",
    countCls: "[background:#fff7e6] [color:#d97706]",
  },
  "in-progress": {
    label: "In Progress Requests",
    shortLabel: "In Progress",
    status: "in-progress",
    tone: "progress",
    description: "Requests currently being handled by care teams.",
    countCls: "[background:#e0f2fe] [color:#0284c7]",
  },
  completed: {
    label: "Completed Requests",
    shortLabel: "Completed",
    status: "completed",
    tone: "completed",
    description: "Resolved requests ready for review, evidence and audit.",
    countCls: "[background:#dcfce7] [color:#16a34a]",
  },
};

const SLA_HOURS = 24;

function getSlaData(createdAt, status) {
  if (status === "completed" || status === "cancelled")
    return { label: "Resolved", cls: "[background:#dcfce7] [color:#15803d]" };
  const hoursPassed =
    (Date.now() - new Date(createdAt).getTime()) / (1000 * 60 * 60);
  const remaining = SLA_HOURS - hoursPassed;
  if (remaining <= 0)
    return {
      label: `Breached ${Math.abs(Math.floor(remaining))}h`,
      cls: "[background:#fee2e2] [color:#dc2626]",
    };
  if (remaining <= 6)
    return {
      label: `${Math.floor(remaining)}h left`,
      cls: "[background:#fef3c7] [color:#d97706]",
    };
  return {
    label: `${Math.floor(remaining)}h left`,
    cls: "[background:#dcfce7] [color:#15803d]",
  };
}

function isDateToday(dateString) {
  if (!dateString) return false;
  return (
    new Date().toISOString().slice(0, 10) ===
    new Date(dateString).toISOString().slice(0, 10)
  );
}

function isDateOverdue(dateString, status) {
  if (!dateString || status === "completed" || status === "cancelled")
    return false;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const target = new Date(dateString);
  target.setHours(0, 0, 0, 0);
  return target.getTime() < today.getTime();
}

// ── Shared class strings ────────────────────────────────────
const GLASS =
  "[background:rgba(255,255,255,0.72)] [border:1px_solid_rgba(255,255,255,0.78)] [box-shadow:0_24px_70px_rgba(123,63,242,0.13)] [backdrop-filter:blur(22px)] [-webkit-backdrop-filter:blur(22px)]";
const FIELD_CLS = "[display:flex] [flex-direction:column] [gap:8px]";
const LABEL_CLS =
  "[font-size:0.78rem] [font-weight:700] [color:rgba(15,23,42,0.6)] [text-transform:uppercase] [letter-spacing:0.05em]";
const INPUT_CLS =
  "[padding:9px_12px] [border-radius:10px] [border:1px_solid_#ddd] [background:white] [font-size:0.9rem] [font-family:inherit] [outline:none]";
const ACTION_BTN =
  "[border:none] [padding:10px_16px] [border-radius:12px] [cursor:pointer] [background:#f4f4f4] [color:#374151] [font-family:inherit] [font-size:0.9rem] [font-weight:600] [transition:background_0.2s]";
const SAVE_BTN =
  "[width:100%] [border:none] [padding:10px] [border-radius:12px] [cursor:pointer] [font-weight:700] [font-size:0.9rem] [color:white] [background:linear-gradient(135deg,#7b3ff2,#f97316)]";

function PriorityBadge({ priority }) {
  const map = {
    emergency: {
      cls: "[background:#fee2e2] [color:#dc2626] [border:1px_solid_rgba(220,38,38,0.25)]",
      label: "🚨 Emergency",
    },
    high: {
      cls: "[background:#ffedd5] [color:#ea580c] [border:1px_solid_rgba(234,88,12,0.2)]",
      label: "🔥 High",
    },
    normal: {
      cls: "[background:#dbeafe] [color:#2563eb] [border:1px_solid_rgba(37,99,235,0.15)]",
      label: "⚡ Normal",
    },
    low: {
      cls: "[background:#f3f4f6] [color:#4b5563] [border:1px_solid_rgba(75,85,99,0.15)]",
      label: "🌱 Low",
    },
  };
  const { cls, label } = map[priority] || map.normal;
  return (
    <span
      className={`[padding:6px_12px] [border-radius:999px] [font-size:0.78rem] [font-weight:800] [display:inline-flex] [align-items:center] [gap:4px] ${cls}`}
    >
      {label}
    </span>
  );
}

function StatusPill({ status }) {
  const map = {
    pending: "[background:#fff7e6] [color:#d97706]",
    "in-progress": "[background:#e0f2fe] [color:#0284c7]",
    completed: "[background:#dcfce7] [color:#16a34a]",
    cancelled: "[background:#fee2e2] [color:#dc2626]",
  };
  return (
    <span
      className={`[padding:6px_14px] [border-radius:999px] [font-size:0.82rem] [font-weight:700] [text-transform:capitalize] ${map[status] || map.pending}`}
    >
      {status}
    </span>
  );
}

function AdminRequestStatusPage() {
  const { status } = useParams();
  const navigate = useNavigate();
  const config = STATUS_CONFIG[status] || STATUS_CONFIG.pending;
  const [requests, setRequests] = useState([]);
  const [staff, setStaff] = useState([]);
  const [vendors, setVendors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [dateFilter, setDateFilter] = useState("all");
  const [customDate, setCustomDate] = useState("");
  const [commentInputs, setCommentInputs] = useState({});
  const [selectedPhotos, setSelectedPhotos] = useState([]);
  const [showEvidenceModal, setShowEvidenceModal] = useState(false);
  const [drawerRequest, setDrawerRequest] = useState(null);
  const [drawerMode, setDrawerMode] = useState("view");
  const [expandedCards, setExpandedCards] = useState({});

  const toggleExpand = (id) =>
    setExpandedCards((prev) => ({ ...prev, [id]: !prev[id] }));

  const fetchRequests = useCallback(async () => {
    const { data } = await API.get("/services/all");
    setRequests(data || []);
  }, []);

  useEffect(() => {
    async function loadPageData() {
      try {
        setLoading(true);
        const [r, s, v] = await Promise.all([
          API.get("/services/all"),
          API.get("/staff"),
          API.get("/vendors"),
        ]);
        setRequests(r.data || []);
        setStaff(s.data || []);
        setVendors(v.data || []);
      } catch {
        toast.error("Failed to load requests");
      } finally {
        setLoading(false);
      }
    }
    loadPageData();
  }, []);

  const filteredRequests = useMemo(() => {
    const query = search.trim().toLowerCase();
    let list = requests.filter((r) => r.status === config.status);
    if (query)
      list = list.filter((r) =>
        [
          r.serviceType,
          r.description,
          r.user?.name,
          r.user?.email,
          r.assignedTo,
          r.assignedVendor,
        ]
          .filter(Boolean)
          .some((v) => v.toLowerCase().includes(query)),
      );
    if (priorityFilter !== "all")
      list = list.filter((r) => r.priority === priorityFilter);
    if (dateFilter !== "all") {
      const todayStr = new Date().toISOString().slice(0, 10);
      const tom = new Date();
      tom.setDate(tom.getDate() + 1);
      const tomorrowStr = tom.toISOString().slice(0, 10);
      list = list.filter((r) => {
        if (!r.preferredDate) return false;
        const d = new Date(r.preferredDate).toISOString().slice(0, 10);
        if (dateFilter === "today") return d === todayStr;
        if (dateFilter === "tomorrow") return d === tomorrowStr;
        if (dateFilter === "custom" && customDate) return d === customDate;
        return false;
      });
    }
    const w = (p) =>
      p === "emergency" ? 4 : p === "high" ? 3 : p === "low" ? 1 : 2;
    return list.sort((a, b) => {
      const dw = w(b.priority) - w(a.priority);
      if (dw !== 0) return dw;
      const da = a.preferredDate ? new Date(a.preferredDate).getTime() : 0;
      const db = b.preferredDate ? new Date(b.preferredDate).getTime() : 0;
      if (da !== db) return da - db;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }, [config.status, requests, search, priorityFilter, dateFilter, customDate]);

  const updateRequestLocally = (id, patch) =>
    setRequests((prev) =>
      prev.map((r) => (r._id === id ? { ...r, ...patch } : r)),
    );

  const updateMeta = async (request) => {
    try {
      await API.put(`/services/meta/${request._id}`, {
        assignedTo: request.assignedStaffId,
        assignedVendor: request.assignedVendorId,
        adminNotes: request.adminNotes,
      });
      toast.success("Request updated");
      await fetchRequests();
    } catch {
      toast.error("Failed to save request");
    }
  };

  const updateStatus = async (request, nextStatus) => {
    if (
      nextStatus === "in-progress" &&
      (!request.assignedStaffId || !request.assignedVendorId)
    ) {
      toast.error("Assign Staff and Vendor before moving to In Progress");
      return;
    }
    if (nextStatus === "completed") {
      toast.error("Use Approve Completion to mark a request as completed");
      return;
    }
    try {
      await updateMeta(request);
      await API.put(`/services/update/${request._id}`, { status: nextStatus });
      toast.success("Status updated");
      await fetchRequests();
    } catch {
      toast.error("Failed to update status");
    }
  };

  const addComment = async (requestId) => {
    const message = commentInputs[requestId];
    if (!message?.trim()) {
      toast.error("Enter comment");
      return;
    }
    try {
      await API.put(`/services/comment/${requestId}`, { message });
      setCommentInputs((prev) => ({ ...prev, [requestId]: "" }));
      toast.success("Comment added");
      await fetchRequests();
    } catch {
      toast.error("Failed to add comment");
    }
  };

  const approveCompletion = async (requestId) => {
    try {
      const { data } = await API.put(`/admin/requests/${requestId}/approve`);
      updateRequestLocally(requestId, data);
      setDrawerRequest(data);
      setDrawerMode("view");
      toast.success("Completion approved");
      await fetchRequests();
    } catch {
      toast.error("Failed to approve completion");
    }
  };

  const rejectCompletion = async (requestId) => {
    try {
      const { data } = await API.put(`/admin/requests/${requestId}/reject`);
      updateRequestLocally(requestId, data);
      setDrawerRequest(data);
      setDrawerMode("view");
      toast.success("Completion rejected — sent back to vendor");
      await fetchRequests();
    } catch {
      toast.error("Failed to reject completion");
    }
  };

  if (loading) return <LoadingPage />;

  const reviewRequests =
    config.status === "in-progress"
      ? filteredRequests.filter(
          (r) => r.verificationStatus === "staff-approved",
        )
      : [];
  const regularRequests =
    config.status === "in-progress"
      ? filteredRequests.filter(
          (r) => r.verificationStatus !== "staff-approved",
        )
      : filteredRequests;

  const renderCard = (request) => {
    const sla = getSlaData(request.createdAt, request.status);
    const isExpanded = !!expandedCards[request._id];

    return (
      <article
        key={request._id}
        className={`[padding:18px_20px] [border-radius:22px] [display:flex] [flex-direction:column] [gap:10px] ${GLASS}`}
      >
        {/* Top row */}
        <div className="[display:flex] [justify-content:space-between] [align-items:flex-start] [gap:8px]">
          <div>
            <span className="[color:#7b3ff2] [font-size:0.74rem] [font-weight:900] [letter-spacing:0.08em] [text-transform:uppercase]">
              Service Request
            </span>
            <h3 className="[margin:4px_0_0] [color:#111827] [font-size:1.1rem] [line-height:1.2]">
              {request.serviceType}
            </h3>
          </div>
          <div className="[display:flex] [gap:8px] [align-items:center] [flex-shrink:0] [flex-wrap:wrap] [justify-content:flex-end]">
            <PriorityBadge priority={request.priority || "normal"} />
            <StatusPill status={request.status} />
          </div>
        </div>

        {/* Customer */}
        <div className="[display:flex] [flex-direction:column] [gap:4px] [color:rgba(15,23,42,0.7)]">
          <strong>{request.user?.name || "Customer"}</strong>
          <span className="[font-size:0.88rem]">
            {request.user?.email || "No email available"}
          </span>
        </div>

        {/* Meta row */}
        <div className="[display:flex] [justify-content:space-between] [align-items:center] [gap:12px] [margin-top:10px] [flex-wrap:wrap]">
          <div className="[display:flex] [flex-direction:column] [gap:4px]">
            <span className="[font-size:0.75rem] [color:rgba(15,23,42,0.6)]">
              Created
            </span>
            <strong className="[font-size:0.9rem]">
              {request.createdAt
                ? new Date(request.createdAt).toLocaleDateString()
                : "-"}
            </strong>
          </div>
          <div className="[display:flex] [flex-direction:column] [gap:4px]">
            <span className="[font-size:0.75rem] [color:rgba(15,23,42,0.6)]">
              Preferred Date
            </span>
            <strong className="[font-size:0.9rem] [display:flex] [align-items:center] [gap:6px]">
              {request.preferredDate
                ? new Date(request.preferredDate).toLocaleDateString("en-IN")
                : "-"}
              {request.preferredDate && isDateToday(request.preferredDate) && (
                <span className="[background:#fef3c7] [color:#d97706] [font-size:0.65rem] [font-weight:800] [padding:2px_6px] [border-radius:4px] [text-transform:uppercase]">
                  Today
                </span>
              )}
              {request.preferredDate &&
                isDateOverdue(request.preferredDate, request.status) && (
                  <span className="[background:#fee2e2] [color:#dc2626] [font-size:0.65rem] [font-weight:800] [padding:2px_6px] [border-radius:4px] [text-transform:uppercase]">
                    Overdue
                  </span>
                )}
            </strong>
          </div>
          <div className="[display:flex] [flex-direction:column] [gap:4px]">
            <span className="[font-size:0.75rem] [color:rgba(15,23,42,0.6)]">
              SLA
            </span>
            <strong className="[font-size:0.9rem]">24 Hours</strong>
          </div>
          <span
            className={`[padding:6px_12px] [border-radius:999px] [font-size:0.8rem] [font-weight:700] ${sla.cls}`}
          >
            {sla.label}
          </span>
        </div>

        {/* Assignment strip */}
        {(request.assignedTo || request.assignedVendor) && (
          <div className="[display:flex] [gap:16px] [padding:10px_12px] [border-radius:12px] [background:rgba(246,240,255,0.72)] [color:rgba(15,23,42,0.72)] [font-size:0.85rem] [font-weight:700]">
            <span>👤 {request.assignedTo || "No staff"}</span>
            <span>🏢 {request.assignedVendor || "No vendor"}</span>
          </div>
        )}

        {/* Description */}
        <p className="[margin:0] [padding:10px_14px] [border-radius:12px] [background:rgba(123,63,242,0.04)] [line-height:1.6] [font-size:0.9rem]">
          {request.description}
        </p>

        {/* Actions */}
        {config.status === "completed" ? (
          <div className="[display:flex] [flex-wrap:wrap] [gap:8px] [margin-top:10px]">
            <button
              type="button"
              className={`${SAVE_BTN} [flex:1]`}
              onClick={() => {
                setDrawerRequest(request);
                setDrawerMode("view");
              }}
            >
              View Details
            </button>
            <button
              type="button"
              className={ACTION_BTN}
              onClick={() => {
                setDrawerRequest(request);
                setDrawerMode("view");
              }}
            >
              Audit Trail
            </button>
            {request.jobPhotos?.length > 0 && (
              <button
                type="button"
                className={ACTION_BTN}
                onClick={() => {
                  setSelectedPhotos(request.jobPhotos);
                  setShowEvidenceModal(true);
                }}
              >
                Evidence
              </button>
            )}
          </div>
        ) : (
          <>
            {request.verificationStatus === "staff-approved" && (
              <div className="[background:#fff7ed] [color:#ea580c] [padding:12px] [border-radius:12px] [font-weight:600]">
                ✅ Staff verified this job. Review and approve or reject
                completion.
              </div>
            )}
            <div className="[display:flex] [gap:10px] [flex-wrap:wrap] [align-items:center]">
              <button
                type="button"
                className={ACTION_BTN}
                onClick={() => {
                  setDrawerRequest(request);
                  setDrawerMode("view");
                }}
              >
                View Details
              </button>
              {request.jobPhotos?.length > 0 && (
                <button
                  type="button"
                  className={ACTION_BTN}
                  onClick={() => {
                    setSelectedPhotos(request.jobPhotos);
                    setShowEvidenceModal(true);
                  }}
                >
                  Evidence
                </button>
              )}
              {request.verificationStatus === "staff-approved" && (
                <button
                  type="button"
                  className="[background:linear-gradient(135deg,#16a34a,#15803d)] [color:white] [font-weight:700] [padding:9px_16px] [border-radius:12px] [font-size:0.85rem] [border:none] [cursor:pointer] [white-space:nowrap]"
                  onClick={() => {
                    setDrawerRequest(request);
                    setDrawerMode("review");
                  }}
                >
                  Review Completion
                </button>
              )}
              <button
                type="button"
                className={`${ACTION_BTN} [margin-left:auto] ${isExpanded ? "[background:rgba(123,63,242,0.18)] [color:#7b3ff2]" : "[background:rgba(123,63,242,0.08)] [color:#7b3ff2] [font-weight:700]"}`}
                onClick={() => toggleExpand(request._id)}
              >
                {isExpanded ? "✕ Close" : "⚙ Manage"}
              </button>
            </div>

            {isExpanded && (
              <div className="[margin-top:12px] [padding:14px] [border-radius:16px] [background:rgba(246,240,255,0.5)] [border:1px_solid_rgba(123,63,242,0.1)] [display:flex] [flex-direction:column] [gap:10px]">
                <div className="[display:grid] [grid-template-columns:repeat(2,minmax(160px,1fr))] [gap:10px] max-[640px]:[grid-template-columns:1fr]">
                  {config.status === "pending" && (
                    <>
                      <div className={FIELD_CLS}>
                        <label className={LABEL_CLS}>Assign Staff</label>
                        <select
                          className={INPUT_CLS}
                          value={request.assignedStaffId || ""}
                          onChange={(e) =>
                            updateRequestLocally(request._id, {
                              assignedStaffId: e.target.value,
                            })
                          }
                        >
                          <option value="">Select Staff</option>
                          {staff.map((m) => (
                            <option key={m._id} value={m._id}>
                              {m.name}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className={FIELD_CLS}>
                        <label className={LABEL_CLS}>Assign Vendor</label>
                        <select
                          className={INPUT_CLS}
                          value={request.assignedVendorId || ""}
                          onChange={(e) =>
                            updateRequestLocally(request._id, {
                              assignedVendorId: e.target.value,
                            })
                          }
                        >
                          <option value="">Select Vendor</option>
                          {vendors.map((v) => (
                            <option key={v._id} value={v._id}>
                              {v.businessName}
                            </option>
                          ))}
                        </select>
                      </div>
                    </>
                  )}
                  <div className={FIELD_CLS}>
                    <label className={LABEL_CLS}>Status</label>
                    <select
                      className={INPUT_CLS}
                      value={request.status}
                      onChange={(e) => updateStatus(request, e.target.value)}
                    >
                      <option value="pending">Pending</option>
                      <option value="in-progress">In Progress</option>
                      <option value="cancelled">Cancelled</option>
                    </select>
                  </div>
                </div>
                <div className={FIELD_CLS}>
                  <label className={LABEL_CLS}>Admin Notes</label>
                  <textarea
                    className={`${INPUT_CLS} [resize:vertical]`}
                    rows="2"
                    value={request.adminNotes || ""}
                    onChange={(e) =>
                      updateRequestLocally(request._id, {
                        adminNotes: e.target.value,
                      })
                    }
                  />
                </div>
                <button
                  type="button"
                  className={SAVE_BTN}
                  onClick={() => updateMeta(request)}
                >
                  Save Changes
                </button>
                <div className="[display:flex] [gap:10px]">
                  <input
                    className={`${INPUT_CLS} [flex:1]`}
                    placeholder="Add internal comment..."
                    value={commentInputs[request._id] || ""}
                    onChange={(e) =>
                      setCommentInputs((prev) => ({
                        ...prev,
                        [request._id]: e.target.value,
                      }))
                    }
                  />
                  <button
                    type="button"
                    className="[padding:9px_18px] [border:none] [border-radius:12px] [cursor:pointer] [background:#7b3ff2] [color:white] [font-weight:700]"
                    onClick={() => addComment(request._id)}
                  >
                    Add
                  </button>
                </div>
              </div>
            )}
          </>
        )}
      </article>
    );
  };

  // Filter pill helper
  const filterPillCls = (active, colorCls = "") =>
    `[padding:8px_14px] [border:1px_solid_rgba(123,63,242,0.1)] [border-radius:99px] [font-size:0.85rem] [font-weight:700] [cursor:pointer] [transition:all_0.2s_ease] ${
      active
        ? colorCls ||
          "[background:#7b3ff2] [color:white] [border-color:#7b3ff2] [box-shadow:0_8px_20px_rgba(123,63,242,0.25)]"
        : "[background:rgba(255,255,255,0.65)] [color:#4b5563] hover:[background:rgba(255,255,255,0.9)] hover:[border-color:rgba(123,63,242,0.25)]"
    }`;

  return (
    <section className="[min-height:100vh] [padding:34px] [background:radial-gradient(circle_at_12%_2%,rgba(255,92,168,0.13),transparent_26%),radial-gradient(circle_at_88%_3%,rgba(255,155,84,0.14),transparent_26%),linear-gradient(135deg,#fff8fc_0%,#f6f0ff_46%,#fff_100%)] max-[640px]:[padding:18px]">
      {/* Header */}
      <div
        className={`[padding:20px_24px] [border-radius:24px] [margin-bottom:16px] ${GLASS}`}
      >
        <div className="[display:flex] [align-items:center] [justify-content:space-between] [margin-bottom:8px]">
          <span className="[color:#7b3ff2] [font-size:0.78rem] [font-weight:800] [letter-spacing:0.14em] [text-transform:uppercase]">
            Service Operations
          </span>
          <button
            type="button"
            className="[min-height:34px] [padding:0_16px] [border:0] [border-radius:999px] [color:#7b3ff2] [background:rgba(123,63,242,0.08)] [font-size:0.85rem] [font-weight:900] [cursor:pointer] [display:inline-flex] [align-items:center] [gap:6px] hover:[background:rgba(123,63,242,0.16)] [transition:background_0.2s]"
            onClick={() => navigate("/admin/dashboard?tab=requests")}
          >
            ← Back to requests
          </button>
        </div>
        <div className="[display:flex] [align-items:center] [justify-content:space-between] [gap:24px] max-[640px]:[flex-direction:column] max-[640px]:[align-items:flex-start]">
          <div>
            <h1 className="[margin:6px_0] [color:#111827] [font-size:clamp(1.6rem,3vw,2.4rem)] [line-height:1.1]">
              {config.label}
            </h1>
            <p className="[max-width:680px] [margin:0] [color:rgba(15,23,42,0.64)] [font-size:0.95rem] [line-height:1.6]">
              {config.description}
            </p>
          </div>
          <div
            className={`[display:flex] [flex-direction:column] [align-items:center] [justify-content:center] [min-width:90px] [padding:16px_20px] [border-radius:20px] [text-align:center] [flex-shrink:0] ${config.countCls}`}
          >
            <strong className="[display:block] [font-size:2.2rem] [line-height:1] [font-weight:900]">
              {filteredRequests.length}
            </strong>
            <span className="[display:block] [font-size:0.78rem] [font-weight:700] [text-transform:uppercase] [letter-spacing:0.05em] [margin-top:6px]">
              {config.shortLabel}
            </span>
          </div>
        </div>
      </div>

      {/* Search + Filters */}
      <div
        className={`[padding:10px_14px] [border-radius:18px] [margin-bottom:20px] ${GLASS}`}
      >
        <div className="[display:flex] [width:100%]">
          <input
            type="search"
            className="[width:100%] [min-height:40px] [padding:0_14px] [border:1px_solid_rgba(123,63,242,0.12)] [border-radius:12px] [background:rgba(255,255,255,0.82)] [color:#111827] [font-size:0.93rem] [outline:none] [font-family:inherit]"
            placeholder="Search by service, customer, email or team..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div className="[display:flex] [flex-wrap:wrap] [gap:20px] [align-items:center] [border-top:1px_solid_rgba(123,63,242,0.08)] [padding-top:16px] [width:100%] [margin-top:12px]">
          {/* Priority filter */}
          <div className="[display:flex] [align-items:center] [gap:12px] [flex-wrap:wrap]">
            <span className="[font-size:0.82rem] [font-weight:800] [text-transform:uppercase] [color:rgba(15,23,42,0.5)] [letter-spacing:0.05em]">
              Priority:
            </span>
            <div className="[display:flex] [gap:8px] [flex-wrap:wrap]">
              {[
                { value: "all", label: "All Priorities", colorCls: "" },
                {
                  value: "emergency",
                  label: "🚨 Emergency",
                  colorCls:
                    "[background:#ef4444] [color:white] [border-color:#ef4444] [box-shadow:0_8px_20px_rgba(239,68,68,0.25)]",
                },
                {
                  value: "high",
                  label: "🔥 High",
                  colorCls:
                    "[background:#f97316] [color:white] [border-color:#f97316] [box-shadow:0_8px_20px_rgba(249,115,22,0.25)]",
                },
                {
                  value: "normal",
                  label: "⚡ Normal",
                  colorCls:
                    "[background:#3b82f6] [color:white] [border-color:#3b82f6] [box-shadow:0_8px_20px_rgba(59,130,246,0.25)]",
                },
                {
                  value: "low",
                  label: "🌱 Low",
                  colorCls:
                    "[background:#6b7280] [color:white] [border-color:#6b7280] [box-shadow:0_8px_20px_rgba(107,114,128,0.25)]",
                },
              ].map((p) => (
                <button
                  type="button"
                  key={p.value}
                  className={filterPillCls(
                    priorityFilter === p.value,
                    p.colorCls,
                  )}
                  onClick={() => setPriorityFilter(p.value)}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Date filter */}
          <div className="[display:flex] [align-items:center] [gap:12px] [flex-wrap:wrap]">
            <span className="[font-size:0.82rem] [font-weight:800] [text-transform:uppercase] [color:rgba(15,23,42,0.5)] [letter-spacing:0.05em]">
              Scheduled Date:
            </span>
            <div className="[display:flex] [gap:8px] [flex-wrap:wrap] [align-items:center]">
              {[
                { value: "all", label: "All Dates" },
                { value: "today", label: "📅 Today" },
                { value: "tomorrow", label: "📅 Tomorrow" },
                { value: "custom", label: "📅 Pick Date..." },
              ].map((d) => (
                <button
                  type="button"
                  key={d.value}
                  className={filterPillCls(dateFilter === d.value)}
                  onClick={() => {
                    setDateFilter(d.value);
                    if (d.value !== "custom") setCustomDate("");
                  }}
                >
                  {d.label}
                </button>
              ))}
              {dateFilter === "custom" && (
                <input
                  type="date"
                  className="[padding:6px_12px] [border-radius:99px] [border:1px_solid_rgba(123,63,242,0.15)] [outline:none] [font-size:0.85rem] [font-weight:700] [color:#1f2937] [background:rgba(255,255,255,0.85)]"
                  value={customDate}
                  onChange={(e) => setCustomDate(e.target.value)}
                />
              )}
            </div>
          </div>

          {(priorityFilter !== "all" || dateFilter !== "all" || search) && (
            <button
              type="button"
              className="[padding:8px_14px] [border:none] [border-radius:99px] [background:rgba(239,68,68,0.08)] [color:#ef4444] [font-size:0.85rem] [font-weight:800] [cursor:pointer] [margin-left:auto] hover:[background:rgba(239,68,68,0.16)]"
              onClick={() => {
                setPriorityFilter("all");
                setDateFilter("all");
                setCustomDate("");
                setSearch("");
              }}
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* Cards */}
      {filteredRequests.length === 0 ? (
        <div
          className={`[min-height:360px] [padding:50px] [border:1px_dashed_rgba(123,63,242,0.24)] [border-radius:32px] [display:grid] [place-items:center] [text-align:center] ${GLASS}`}
        >
          <div>
            <div className="[font-size:3rem] [margin-bottom:16px]">📭</div>
            <h3 className="[margin:12px_0_8px] [color:#111827] [font-size:1.6rem]">
              No {config.shortLabel.toLowerCase()} requests
            </h3>
            <p className="[margin:0] [color:rgba(15,23,42,0.62)]">
              This page will update when requests move into this status.
            </p>
          </div>
        </div>
      ) : config.status === "in-progress" ? (
        <>
          {reviewRequests.length > 0 && (
            <div className="[margin-bottom:28px]">
              <h2 className="[display:flex] [align-items:center] [gap:10px] [margin:0_0_16px] [font-size:1.1rem] [font-weight:800] [color:#111827]">
                🔔 Awaiting Your Review
                <span className="[display:inline-flex] [align-items:center] [justify-content:center] [min-width:28px] [height:24px] [padding:0_8px] [border-radius:999px] [background:rgba(123,63,242,0.12)] [color:#7b3ff2] [font-size:0.8rem] [font-weight:900]">
                  {reviewRequests.length}
                </span>
              </h2>
              <div className="[display:grid] [grid-template-columns:repeat(2,minmax(280px,1fr))] [gap:22px] [align-items:start] max-[1200px]:[grid-template-columns:1fr]">
                {reviewRequests.map(renderCard)}
              </div>
            </div>
          )}
          {regularRequests.length > 0 && (
            <div className="[margin-bottom:28px]">
              <h2 className="[display:flex] [align-items:center] [gap:10px] [margin:0_0_16px] [font-size:1.1rem] [font-weight:800] [color:#111827]">
                In Progress
                <span className="[display:inline-flex] [align-items:center] [justify-content:center] [min-width:28px] [height:24px] [padding:0_8px] [border-radius:999px] [background:rgba(123,63,242,0.12)] [color:#7b3ff2] [font-size:0.8rem] [font-weight:900]">
                  {regularRequests.length}
                </span>
              </h2>
              <div className="[display:grid] [grid-template-columns:repeat(2,minmax(280px,1fr))] [gap:22px] [align-items:start] max-[1200px]:[grid-template-columns:1fr]">
                {regularRequests.map(renderCard)}
              </div>
            </div>
          )}
        </>
      ) : (
        <div className="[display:grid] [grid-template-columns:repeat(2,minmax(280px,1fr))] [gap:22px] [align-items:start] max-[1200px]:[grid-template-columns:1fr]">
          {filteredRequests.map(renderCard)}
        </div>
      )}

      {/* Drawer */}
      {drawerRequest && (
        <div
          className="[position:fixed] [inset:0] [z-index:100] [background:rgba(17,24,39,0.28)] [backdrop-filter:blur(6px)] [-webkit-backdrop-filter:blur(6px)] [display:flex] [justify-content:flex-end]"
          onClick={() => setDrawerRequest(null)}
        >
          <aside
            className="[width:min(560px,100%)] [height:100vh] [overflow-y:auto] [padding:32px] [background:radial-gradient(circle_at_12%_0%,rgba(255,92,168,0.12),transparent_28%),radial-gradient(circle_at_92%_12%,rgba(255,155,84,0.12),transparent_30%),rgba(255,255,255,0.96)] [border-left:1px_solid_rgba(123,63,242,0.12)] [box-shadow:-28px_0_90px_rgba(17,24,39,0.18)] max-[640px]:[padding:24px_18px]"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Drawer header */}
            <div className="[display:flex] [align-items:flex-start] [justify-content:space-between] [gap:24px] [margin-bottom:24px]">
              <div>
                <span className="[color:#7b3ff2] [font-size:0.78rem] [font-weight:800] [letter-spacing:0.14em] [text-transform:uppercase]">
                  {drawerRequest.status === "completed"
                    ? "Completed Request"
                    : drawerMode === "review"
                      ? "Review Completion"
                      : "Request Details"}
                </span>
                <h3 className="[margin:10px_0_6px] [color:#111827] [font-size:1.8rem] [line-height:1.1]">
                  {drawerRequest.serviceType}
                </h3>
                <p className="[margin:0] [color:rgba(15,23,42,0.62)]">
                  {drawerRequest.user?.email}
                </p>
              </div>
              <button
                type="button"
                className="[width:42px] [height:42px] [border:0] [border-radius:15px] [color:#7b3ff2] [background:rgba(123,63,242,0.08)] [font-size:1.5rem] [line-height:1] [cursor:pointer] [flex-shrink:0]"
                onClick={() => setDrawerRequest(null)}
              >
                ✕
              </button>
            </div>

            {/* Status badges */}
            <div className="[display:flex] [gap:12px] [flex-wrap:wrap] [margin-bottom:22px]">
              <StatusPill status={drawerRequest.status} />
              {drawerRequest.verificationStatus &&
                (() => {
                  const vs = drawerRequest.verificationStatus;
                  const cls =
                    vs === "approved"
                      ? "[background:#dcfce7] [color:#15803d]"
                      : vs === "staff-approved" || vs === "submitted"
                        ? "[background:#fef3c7] [color:#d97706]"
                        : vs === "rejected"
                          ? "[background:#fee2e2] [color:#dc2626]"
                          : "[background:#dcfce7] [color:#15803d]";
                  const lbl =
                    vs === "approved"
                      ? "Approved"
                      : vs === "staff-approved"
                        ? "Awaiting Admin Review"
                        : vs === "submitted"
                          ? "Awaiting Staff"
                          : vs === "rejected"
                            ? "Rejected"
                            : "Resolved";
                  return (
                    <span
                      className={`[padding:6px_12px] [border-radius:999px] [font-size:0.8rem] [font-weight:700] ${cls}`}
                    >
                      {lbl}
                    </span>
                  );
                })()}
            </div>

            {/* Detail grid */}
            <div className="[display:grid] [grid-template-columns:repeat(2,1fr)] [gap:14px] [margin-bottom:22px] max-[640px]:[grid-template-columns:1fr]">
              {[
                ["Customer", drawerRequest.user?.name || "Customer"],
                [
                  "Created",
                  drawerRequest.createdAt
                    ? new Date(drawerRequest.createdAt).toLocaleDateString()
                    : "-",
                ],
                [
                  "Preferred Date",
                  drawerRequest.preferredDate
                    ? new Date(drawerRequest.preferredDate).toLocaleDateString(
                        "en-IN",
                      )
                    : "-",
                ],
                [
                  "Priority",
                  drawerRequest.priority === "emergency"
                    ? "🚨 Emergency"
                    : drawerRequest.priority === "high"
                      ? "🔥 High"
                      : drawerRequest.priority === "low"
                        ? "🌱 Low"
                        : "⚡ Normal",
                ],
                ["Assigned Staff", drawerRequest.assignedTo || "Not assigned"],
                [
                  "Assigned Vendor",
                  drawerRequest.assignedVendor || "Not assigned",
                ],
              ].map(([label, value]) => (
                <div
                  key={label}
                  className="[padding:18px] [border-radius:22px] [background:rgba(255,255,255,0.74)] [border:1px_solid_rgba(123,63,242,0.08)] [box-shadow:0_16px_38px_rgba(123,63,242,0.07)]"
                >
                  <span className="[display:block] [margin-bottom:7px] [color:rgba(15,23,42,0.56)] [font-size:0.78rem] [font-weight:800] [text-transform:uppercase] [letter-spacing:0.06em]">
                    {label}
                  </span>
                  <strong className="[color:#111827] [line-height:1.35]">
                    {value}
                  </strong>
                </div>
              ))}
            </div>

            {/* Description */}
            <div className="[padding:18px] [border-radius:22px] [background:rgba(255,255,255,0.74)] [border:1px_solid_rgba(123,63,242,0.08)] [box-shadow:0_16px_38px_rgba(123,63,242,0.07)] [margin-bottom:16px]">
              <h4 className="[margin:0_0_12px] [color:#111827]">
                Request Details
              </h4>
              <p className="[margin:0] [color:rgba(15,23,42,0.72)] [line-height:1.7]">
                {drawerRequest.description || "No description added."}
              </p>
            </div>

            {/* Evidence button */}
            {drawerRequest.jobPhotos?.length > 0 && (
              <button
                type="button"
                className={`${SAVE_BTN} [margin-bottom:16px]`}
                onClick={() => {
                  setSelectedPhotos(drawerRequest.jobPhotos);
                  setShowEvidenceModal(true);
                }}
              >
                View Evidence
              </button>
            )}

            {/* Admin Notes */}
            <div className="[padding:18px] [border-radius:22px] [background:rgba(255,255,255,0.74)] [border:1px_solid_rgba(123,63,242,0.08)] [box-shadow:0_16px_38px_rgba(123,63,242,0.07)] [margin-bottom:16px]">
              <h4 className="[margin:0_0_12px] [color:#111827]">Admin Notes</h4>
              <p className="[margin:0] [color:rgba(15,23,42,0.72)] [line-height:1.7]">
                {drawerRequest.adminNotes || "No admin notes added."}
              </p>
            </div>

            {/* Comments */}
            <div className="[padding:18px] [border-radius:22px] [background:rgba(255,255,255,0.74)] [border:1px_solid_rgba(123,63,242,0.08)] [box-shadow:0_16px_38px_rgba(123,63,242,0.07)] [margin-bottom:16px]">
              <h4 className="[margin:0_0_12px] [color:#111827]">
                Internal Comments
              </h4>
              {drawerRequest.comments?.length ? (
                drawerRequest.comments.map((c, i) => (
                  <div
                    key={i}
                    className="[background:#fafafa] [padding:12px] [border-radius:12px] [margin-bottom:10px]"
                  >
                    <p className="[margin:0]">{c.message}</p>
                    <small className="[color:rgba(15,23,42,0.55)]">
                      {new Date(c.createdAt).toLocaleString()}
                    </small>
                  </div>
                ))
              ) : (
                <p className="[margin:0] [color:rgba(15,23,42,0.6)]">
                  No internal comments yet.
                </p>
              )}
            </div>

            {/* Audit Trail */}
            <div className="[padding:18px] [border-radius:22px] [background:rgba(255,255,255,0.74)] [border:1px_solid_rgba(123,63,242,0.08)] [box-shadow:0_16px_38px_rgba(123,63,242,0.07)] [margin-bottom:16px] [max-height:360px] [overflow-y:auto]">
              <h4 className="[margin:0_0_12px] [color:#111827]">Audit Trail</h4>
              {drawerRequest.auditLogs?.length ? (
                drawerRequest.auditLogs
                  .slice()
                  .reverse()
                  .map((log, i) => (
                    <div
                      key={i}
                      className="[display:flex] [gap:12px] [margin-bottom:12px]"
                    >
                      <div className="[width:10px] [height:10px] [border-radius:50%] [margin-top:6px] [background:#7b3ff2] [flex-shrink:0]" />
                      <div>
                        <p className="[margin:0] [font-size:0.9rem]">
                          {log.action}
                        </p>
                        <small className="[color:rgba(15,23,42,0.55)]">
                          {new Date(log.createdAt).toLocaleString()}
                        </small>
                      </div>
                    </div>
                  ))
              ) : (
                <small className="[color:rgba(15,23,42,0.55)]">
                  No audit history yet
                </small>
              )}
            </div>

            {/* Approve / Reject */}
            {drawerMode === "review" &&
              drawerRequest.verificationStatus === "staff-approved" && (
                <div className="[padding:18px] [border-radius:22px] [background:rgba(246,240,255,0.72)] [margin-bottom:16px]">
                  <h4 className="[margin:0_0_12px] [color:#111827]">
                    Completion Verification
                  </h4>
                  <p className="[margin-bottom:16px] [color:rgba(15,23,42,0.65)] [font-size:0.9rem]">
                    Staff has physically verified this job. Approve to mark it
                    completed, or reject to send it back to the vendor.
                  </p>
                  <div className="[display:flex] [gap:12px]">
                    <button
                      type="button"
                      className="[flex:2] [padding:13px_20px] [border:none] [border-radius:14px] [background:linear-gradient(135deg,#16a34a,#15803d)] [color:white] [font-weight:700] [font-size:0.92rem] [cursor:pointer] hover:[opacity:0.88] [transition:opacity_0.2s]"
                      onClick={() => approveCompletion(drawerRequest._id)}
                    >
                      ✓ Approve Completion
                    </button>
                    <button
                      type="button"
                      className="[flex:1] [padding:13px_20px] [border:1px_solid_rgba(220,38,38,0.3)] [border-radius:14px] [background:#fee2e2] [color:#dc2626] [font-weight:700] [font-size:0.92rem] [cursor:pointer] hover:[background:#fecaca] [transition:background_0.2s]"
                      onClick={() => rejectCompletion(drawerRequest._id)}
                    >
                      ✕ Reject
                    </button>
                  </div>
                </div>
              )}
          </aside>
        </div>
      )}

      <EvidenceViewerModal
        open={showEvidenceModal}
        photos={selectedPhotos}
        onClose={() => setShowEvidenceModal(false)}
      />
    </section>
  );
}

export default AdminRequestStatusPage;

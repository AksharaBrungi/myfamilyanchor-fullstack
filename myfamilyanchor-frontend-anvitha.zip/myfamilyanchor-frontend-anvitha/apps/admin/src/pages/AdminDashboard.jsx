import { useEffect, useState, useCallback, useMemo } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import toast from "react-hot-toast";
import API from "@api/axios";
import socket from "@api/socket";
import LoadingPage from "@ui/Loadingpage";
import AdminSettings from "./AdminSettings";
import EvidenceViewerModal from "@ui/EvidenceViewerModal";
import AdminNewsletter from "../components/AdminNewsletter";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";

// ── Shared Tailwind class strings ────────────────────────────
const FIELD_CLS = "[display:flex] [flex-direction:column] [gap:8px]";
const LABEL_CLS =
  "[font-size:0.78rem] [font-weight:700] [color:rgba(15,23,42,0.6)] [text-transform:uppercase] [letter-spacing:0.05em]";
const INPUT_CLS =
  "[padding:9px_12px] [border-radius:10px] [border:1px_solid_#ddd] [background:white] [font-size:0.9rem] [font-family:inherit] [outline:none]";
const SECTION_H2 = "[font-size:2rem] [margin:0_0_6px] [color:#111827]";
const SECTION_P = "[margin:0] [color:rgba(15,23,42,0.65)]";
const GLASS_CARD =
  "[background:rgba(255,255,255,0.72)] [border:1px_solid_rgba(255,255,255,0.78)] [box-shadow:0_24px_70px_rgba(123,63,242,0.13)] [backdrop-filter:blur(22px)] [-webkit-backdrop-filter:blur(22px)]";
const OPS_CARD =
  "bg-white [border-radius:22px] [padding:24px] [display:flex] [flex-direction:column] [gap:12px]";
const TABLE_CLS = "[width:100%] [border-collapse:collapse] [background:white]";
const TH_CLS =
  "[padding:14px_16px] [text-align:left] [border-bottom:1px_solid_#eee] [font-weight:700] [color:#7b3ff2] [font-size:0.78rem] [text-transform:uppercase] [letter-spacing:0.06em]";
const TD_CLS =
  "[padding:14px_16px] [text-align:left] [border-bottom:1px_solid_#eee] [font-size:0.92rem] [color:#1f2937]";
const FORM_CARD = `[padding:24px] [border-radius:22px] [margin-bottom:28px] ${GLASS_CARD}`;
const METRIC_ROW =
  "[display:flex] [justify-content:space-between] [align-items:center] [padding:16px] [border-radius:16px] [background:#fafafa]";

// ── Dashboard summary helpers ────────────────────────────────
function ViewAllLink({ onClick, label = "View All" }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="[display:inline-flex] [align-items:center] [gap:6px] [border:none] [background:none] [padding:0] [color:#7b3ff2] [font-weight:800] [font-size:0.85rem] [cursor:pointer] [white-space:nowrap] hover:[text-decoration:underline]"
    >
      {label} →
    </button>
  );
}

function DashboardSection({
  title,
  subtitle,
  onViewAll,
  viewAllLabel = "View All",
  children,
}) {
  return (
    <div className="[margin-top:40px]">
      <div className="[display:flex] [justify-content:space-between] [align-items:flex-end] [gap:16px] [flex-wrap:wrap] [margin-bottom:22px]">
        <div>
          <h2 className={SECTION_H2}>{title}</h2>
          {subtitle && <p className={SECTION_P}>{subtitle}</p>}
        </div>
        {onViewAll && <ViewAllLink onClick={onViewAll} label={viewAllLabel} />}
      </div>
      {children}
    </div>
  );
}

function EmptyState({ text }) {
  return (
    <div className="[text-align:center] [padding:48px_20px] [color:rgba(15,23,42,0.5)] [background:white] [border-radius:18px] [border:1px_dashed_rgba(123,63,242,0.18)]">
      {text}
    </div>
  );
}

// Status pill helper
function StatusPill({ status }) {
  const styles = {
    pending: "[background:#fff7e6] [color:#d97706]",
    "in-progress": "[background:#e0f2fe] [color:#0284c7]",
    completed: "[background:#dcfce7] [color:#16a34a]",
    cancelled: "[background:#fee2e2] [color:#dc2626]",
    active: "[background:#dcfce7] [color:#16a34a]",
    inactive: "[background:#f1f5f9] [color:#64748b]",
  };
  return (
    <span
      className={`[padding:6px_14px] [border-radius:999px] [font-size:0.82rem] [font-weight:700] [text-transform:capitalize] [display:inline-flex] [align-items:center] ${styles[status] || styles.inactive}`}
    >
      {status}
    </span>
  );
}

function AdminDashboard() {
  const [dashboard, setDashboard] = useState(null);
  const [requests, setRequests] = useState([]);
  const [error, setError] = useState("");
  const [staff, setStaff] = useState([]);
  const [staffForm, setStaffForm] = useState({
    name: "",
    email: "",
    phone: "",
    designation: "",
    city: "",
  });
  const [vendors, setVendors] = useState([]);
  const [categories, setCategories] = useState([]);
  const [vendorForm, setVendorForm] = useState({
    ownerName: "",
    businessName: "",
    email: "",
    phone: "",
    category: "",
    city: "",
  });
  const [activities, setActivities] = useState([]);
  const [commentInputs, setCommentInputs] = useState({});
  const [userSearch, setUserSearch] = useState("");
  const [selectedPhotos, setSelectedPhotos] = useState([]);
  const [showEvidenceModal, setShowEvidenceModal] = useState(false);
  const [selectedCompletedRequest, setSelectedCompletedRequest] =
    useState(null);
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();

  const tab = searchParams.get("tab") || "dashboard";
  const goToTab = (nextTab) => setSearchParams({ tab: nextTab });
  const SLA_HOURS = 24;

  const getSlaData = (createdAt, status) => {
    if (status === "completed" || status === "cancelled")
      return { label: "Resolved", cls: "[background:#dcfce7] [color:#15803d]" };
    const hoursPassed =
      (Date.now() - new Date(createdAt).getTime()) / (1000 * 60 * 60);
    const remaining = SLA_HOURS - hoursPassed;
    if (remaining <= 0)
      return {
        label: `Breached ${Math.abs(Math.floor(remaining))}h`,
        cls: "[background:#fee2e2] [color:#dc2626]",
      };
    if (remaining <= 6)
      return {
        label: `${Math.floor(remaining)}h left`,
        cls: "[background:#fef3c7] [color:#d97706]",
      };
    return {
      label: `${Math.floor(remaining)}h left`,
      cls: "[background:#dcfce7] [color:#15803d]",
    };
  };

  const filteredUsers = useMemo(() => {
    if (!dashboard?.users) return [];
    return dashboard.users.filter(
      (u) =>
        u.name?.toLowerCase().includes(userSearch.toLowerCase()) ||
        u.email?.toLowerCase().includes(userSearch.toLowerCase()),
    );
  }, [dashboard, userSearch]);

  const recentRequests = useMemo(
    () =>
      [...requests]
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
        .slice(0, 5),
    [requests],
  );

  const recentUsers = useMemo(
    () =>
      [...(dashboard?.users || [])]
        .sort(
          (a, b) =>
            new Date(b.createdAt || b.subscriptionExpiresAt || 0) -
            new Date(a.createdAt || a.subscriptionExpiresAt || 0),
        )
        .slice(0, 5),
    [dashboard],
  );

  const updateStatus = async (id, status) => {
    try {
      await API.put(`/services/update/${id}`, { status });
      setRequests((prev) =>
        prev.map((r) => (r._id === id ? { ...r, status } : r)),
      );
      toast.success("Request updated");
    } catch {
      toast.error("Failed to update request");
    }
  };

  const approveCompletion = async (id) => {
    try {
      const { data } = await API.put(`/admin/requests/${id}/approve`);
      setRequests((prev) => prev.map((r) => (r._id === id ? data : r)));
      toast.success("Approved");
    } catch {
      toast.error("Failed");
    }
  };

  const rejectCompletion = async (id) => {
    try {
      const { data } = await API.put(`/admin/requests/${id}/reject`);
      setRequests((prev) => prev.map((r) => (r._id === id ? data : r)));
      toast.success("Rejected");
    } catch {
      toast.error("Failed");
    }
  };

  const updateMeta = async (request) => {
    try {
      await API.put(`/services/meta/${request._id}`, {
        assignedTo: request.assignedStaffId,
        assignedVendor: request.assignedVendorId,
        adminNotes: request.adminNotes,
      });
      toast.success("Request updated");
    } catch {
      toast.error("Failed to save");
    }
  };

  const addComment = async (requestId) => {
    const message = commentInputs[requestId];
    if (!message?.trim()) return toast.error("Enter comment");
    try {
      const { data } = await API.put(`/services/comment/${requestId}`, {
        message,
      });
      setRequests((prev) => prev.map((r) => (r._id === requestId ? data : r)));
      setCommentInputs((prev) => ({ ...prev, [requestId]: "" }));
      toast.success("Comment added");
    } catch {
      toast.error("Failed to add comment");
    }
  };

  const createStaff = async () => {
    try {
      const { data } = await API.post("/staff", staffForm);
      setStaff((prev) => [data, ...prev]);
      setStaffForm({
        name: "",
        email: "",
        phone: "",
        designation: "",
        city: "",
      });
      toast.success("Staff added");
    } catch (e) {
      toast.error(e.response?.data?.message || "Failed to add staff");
    }
  };

  const deleteStaff = async (id) => {
    try {
      await API.delete(`/staff/${id}`);
      setStaff((prev) => prev.filter((m) => m._id !== id));
      toast.success("Staff removed");
    } catch (e) {
      toast.error(e.response?.data?.message || "Delete failed");
    }
  };

  const createVendor = async () => {
    try {
      const { data } = await API.post("/vendors", vendorForm);
      setVendors((prev) => [data, ...prev]);
      setVendorForm({
        ownerName: "",
        businessName: "",
        email: "",
        phone: "",
        category: "",
        city: "",
      });
      toast.success("Vendor added");
    } catch (e) {
      toast.error(e.response?.data?.message || "Failed to add vendor");
    }
  };

  const deleteVendor = async (id) => {
    try {
      await API.delete(`/vendors/${id}`);
      setVendors((prev) => prev.filter((v) => v._id !== id));
      toast.success("Vendor removed");
    } catch (e) {
      toast.error(e.response?.data?.message || "Delete failed");
    }
  };

  const analyticsRevenueData = useMemo(
    () => [
      { month: "Jan", revenue: 12000 },
      { month: "Feb", revenue: 18000 },
      { month: "Mar", revenue: 22000 },
      { month: "Apr", revenue: 26000 },
      { month: "May", revenue: dashboard?.revenue ?? 0 },
    ],
    [dashboard],
  );

  const requestStatusData = [
    {
      name: "Pending",
      value: requests.filter((r) => r.status === "pending").length,
    },
    {
      name: "In Progress",
      value: requests.filter((r) => r.status === "in-progress").length,
    },
    {
      name: "Completed",
      value: requests.filter((r) => r.status === "completed").length,
    },
    {
      name: "Cancelled",
      value: requests.filter((r) => r.status === "cancelled").length,
    },
  ].filter((item) => item.value > 0);

  const pieColors = ["#f59e0b", "#3b82f6", "#22c55e", "#ef4444"];

  const serviceCounts = {};
  requests.forEach((r) => {
    serviceCounts[r.serviceType] = (serviceCounts[r.serviceType] || 0) + 1;
  });
  const topServices = Object.entries(serviceCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  const handleAuthError = useCallback(
    (err) => {
      if (err.response?.status === 401) {
        localStorage.removeItem("adminToken");
        localStorage.removeItem("adminData");
        navigate("/admin/login");
      } else {
        setError("Failed to load data. Please refresh.");
      }
    },
    [navigate],
  );

  const fetchRequests = useCallback(async () => {
    try {
      const { data } = await API.get("/services/all", {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("adminToken")}`,
        },
      });
      setRequests(data);
    } catch (err) {
      handleAuthError(err);
    }
  }, [handleAuthError]);

  useEffect(() => {
    socket.on("new-service-request", (request) => {
      setRequests((prev) => [request, ...prev]);
      setActivities((prev) => [
        {
          id: Date.now(),
          message: `New request: ${request.serviceType}`,
          time: new Date().toLocaleTimeString(),
        },
        ...prev,
      ]);
      toast.success(`New Request: ${request.serviceType}`);
    });
    socket.on("activity-feed", (activity) =>
      setActivities((prev) => [activity, ...prev]),
    );
    return () => {
      socket.off("new-service-request");
      socket.off("activity-feed");
    };
  }, []);

  useEffect(() => {
    const handleRealtimeUpdate = () => fetchRequests();
    socket.on("request-updated", handleRealtimeUpdate);
    return () => socket.off("request-updated", handleRealtimeUpdate);
  }, [fetchRequests]);

  useEffect(() => {
    const fetchDashboard = async () => {
      try {
        const { data } = await API.get("/admin/dashboard");
        setDashboard(data);
        setActivities([
          { id: 1, message: `${data.totalUsers} total users`, time: "System" },
          {
            id: 2,
            message: `${data.totalPayments} payments received`,
            time: "System",
          },
          { id: 3, message: `Revenue ₹${data.revenue}`, time: "System" },
        ]);
      } catch (err) {
        handleAuthError(err);
      }
    };
    const fetchStaff = async () => {
      try {
        const { data } = await API.get("/staff");
        setStaff(data);
      } catch (err) {
        handleAuthError(err);
      }
    };
    const fetchVendors = async () => {
      try {
        const { data } = await API.get("/vendors");
        setVendors(data);
      } catch (err) {
        handleAuthError(err);
      }
    };
    const fetchCategories = async () => {
      try {
        const { data } = await API.get("/vendors/categories/list");
        setCategories(data);
      } catch (err) {
        handleAuthError(err);
      }
    };
    fetchDashboard();
    fetchRequests();
    fetchStaff();
    fetchVendors();
    fetchCategories();
  }, [handleAuthError, fetchRequests]);

  if (error) {
    return (
      <section className="[padding:34px] [display:flex] [flex-direction:column] [gap:40px] [min-height:100vh]">
        <p className="[color:#dc2626]">{error}</p>
      </section>
    );
  }

  if (!dashboard) {
    return (
      <section className="[padding:34px] [display:flex] [flex-direction:column] [gap:40px] [min-height:100vh]">
        <LoadingPage
          title="Loading Operations Center..."
          subtitle="Fetching users, revenue and requests"
        />
      </section>
    );
  }

  // ── Request status card backgrounds ──
  const statusCardGlob = {
    pending: {
      before: "[background:#ff9b54]",
      label: "[color:#d97706] [background:#fff7e6]",
    },
    progress: {
      before: "[background:#38bdf8]",
      label: "[color:#0284c7] [background:#e0f2fe]",
    },
    completed: {
      before: "[background:#22c55e]",
      label: "[color:#16a34a] [background:#dcfce7]",
    },
  };

  return (
    <section className="[padding:34px] [display:flex] [flex-direction:column] [gap:40px] [min-height:100vh] max-[640px]:[padding:18px]">
      <div className={`[padding:30px] [border-radius:24px] ${GLASS_CARD}`}>
        {/* ══ DASHBOARD TAB ══ */}
        {tab === "dashboard" && (
          <>
            {/* Quick Navigation */}
            <div className="[display:flex] [flex-wrap:wrap] [gap:10px] [margin-bottom:30px]">
              {[
                { label: "Service Requests", value: "requests" },
                { label: "Users", value: "users" },
                { label: "Staff", value: "staff" },
                { label: "Vendors", value: "vendors" },
                { label: "Payments", value: "payments" },
                { label: "Analytics", value: "analytics" },
                { label: "Newsletters", value: "newsletters" },
                { label: "Settings", value: "settings" },
              ].map((item) => (
                <button
                  key={item.value}
                  type="button"
                  onClick={() => goToTab(item.value)}
                  className="[padding:9px_18px] [border-radius:999px] [border:1px_solid_rgba(123,63,242,0.16)] [background:white] [color:#7b3ff2] [font-weight:700] [font-size:0.82rem] [cursor:pointer] [transition:all_0.2s_ease] hover:[background:rgba(123,63,242,0.08)] hover:[transform:translateY(-1px)]"
                >
                  {item.label}
                </button>
              ))}
            </div>

            {/* KPI cards */}
            <div className="[display:grid] [grid-template-columns:repeat(auto-fit,minmax(180px,1fr))] [gap:20px] [margin-bottom:30px]">
              {[
                { label: "Pending", value: dashboard.requestMetrics?.pending },
                {
                  label: "In Progress",
                  value: dashboard.requestMetrics?.inProgress,
                },
                {
                  label: "Completed",
                  value: dashboard.requestMetrics?.completed,
                },
                { label: "Revenue", value: `₹${dashboard.revenue}` },
                { label: "SLA Target", value: "24h" },
              ].map(({ label, value }) => (
                <div key={label} className={OPS_CARD}>
                  <span className="[color:rgba(15,23,42,0.6)]">{label}</span>
                  <strong className="[font-size:2.2rem] [color:#7b3ff2]">
                    {value}
                  </strong>
                </div>
              ))}
            </div>

            {/* Service Requests Snapshot */}
            <DashboardSection
              title="Service Requests"
              subtitle="Most recently submitted requests across the platform."
              onViewAll={() => goToTab("requests")}
              viewAllLabel="View All Requests"
            >
              <div className="[display:flex] [flex-direction:column] [gap:12px]">
                {recentRequests.length ? (
                  recentRequests.map((r) => {
                    const sla = getSlaData(r.createdAt, r.status);
                    return (
                      <div
                        key={r._id}
                        className="[display:flex] [align-items:center] [justify-content:space-between] [gap:16px] [flex-wrap:wrap] [background:white] [padding:16px_20px] [border-radius:16px] [border:1px_solid_rgba(123,63,242,0.08)]"
                      >
                        <div className="[min-width:0]">
                          <p className="[margin:0] [font-weight:700] [color:#111827]">
                            {r.serviceType}
                          </p>
                          <small className="[color:rgba(15,23,42,0.55)]">
                            {r.user?.name || "Customer"} ·{" "}
                            {new Date(r.createdAt).toLocaleDateString()}
                          </small>
                        </div>
                        <div className="[display:flex] [align-items:center] [gap:10px] [flex-wrap:wrap]">
                          <span
                            className={`[padding:5px_12px] [border-radius:999px] [font-size:0.76rem] [font-weight:700] ${sla.cls}`}
                          >
                            {sla.label}
                          </span>
                          <StatusPill status={r.status} />
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <EmptyState text="No service requests yet." />
                )}
              </div>
            </DashboardSection>

            {/* Team Performance */}
            <DashboardSection
              title="Team Performance"
              subtitle="Staff workload and request completion."
              onViewAll={() => goToTab("staff")}
              viewAllLabel="View All Staff"
            >
              <div className="[display:grid] [grid-template-columns:repeat(auto-fit,minmax(280px,1fr))] [gap:20px]">
                {dashboard.teamMetrics?.length ? (
                  dashboard.teamMetrics.slice(0, 3).map((member) => (
                    <div
                      key={member._id}
                      className="bg-white [border-radius:24px] [padding:24px] [border:1px_solid_rgba(123,63,242,0.08)]"
                    >
                      <h3 className="[margin-bottom:18px] [color:#7b3ff2]">
                        {member._id}
                      </h3>
                      <div className="[display:flex] [justify-content:space-between] [margin-bottom:20px]">
                        {[
                          ["Assigned", member.assigned],
                          ["Completed", member.completed],
                          ["Pending", member.pending],
                        ].map(([lbl, val]) => (
                          <div key={lbl}>
                            <span className="[display:block] [font-size:0.8rem] [color:rgba(15,23,42,0.6)]">
                              {lbl}
                            </span>
                            <strong className="[font-size:1.4rem]">
                              {val}
                            </strong>
                          </div>
                        ))}
                      </div>
                      <div className="[height:10px] [border-radius:999px] [background:#edf2f7] [overflow:hidden]">
                        <div
                          className="[height:100%] [border-radius:999px] [background:linear-gradient(135deg,#7b3ff2,#f97316)]"
                          style={{
                            width: `${member.assigned ? ((member.completed / member.assigned) * 100).toFixed(0) : 0}%`,
                          }}
                        />
                      </div>
                    </div>
                  ))
                ) : (
                  <EmptyState text="No staff assignments yet." />
                )}
              </div>
            </DashboardSection>

            {/* Vendor Performance */}
            <DashboardSection
              title="Vendor Performance"
              subtitle="Top performing service partners."
              onViewAll={() => goToTab("vendors")}
              viewAllLabel="View All Vendors"
            >
              <div className="[display:grid] [grid-template-columns:repeat(auto-fit,minmax(280px,1fr))] [gap:20px]">
                {dashboard.vendorMetrics?.length ? (
                  dashboard.vendorMetrics.slice(0, 3).map((vendor) => {
                    const pct =
                      vendor.assigned > 0
                        ? Math.round((vendor.completed / vendor.assigned) * 100)
                        : 0;
                    return (
                      <div
                        key={vendor._id}
                        className="bg-white [border-radius:24px] [padding:24px] [border:1px_solid_rgba(123,63,242,0.08)]"
                      >
                        <div className="[display:inline-flex] [align-items:center] [justify-content:center] [width:40px] [height:40px] [border-radius:12px] [background:rgba(123,63,242,0.08)] [font-size:1.2rem] [margin-bottom:12px]">
                          🏢
                        </div>
                        <h3 className="[margin-bottom:18px] [color:#7b3ff2]">
                          {vendor._id}
                        </h3>
                        <div className="[display:flex] [justify-content:space-between] [margin-bottom:20px]">
                          {[
                            ["Assigned", vendor.assigned],
                            ["Completed", vendor.completed],
                          ].map(([lbl, val]) => (
                            <div key={lbl}>
                              <span className="[display:block] [font-size:0.8rem] [color:rgba(15,23,42,0.6)]">
                                {lbl}
                              </span>
                              <strong className="[font-size:1.4rem]">
                                {val}
                              </strong>
                            </div>
                          ))}
                        </div>
                        <div className="[height:10px] [border-radius:999px] [background:#edf2f7] [overflow:hidden]">
                          <div
                            className="[height:100%] [border-radius:999px] [background:linear-gradient(135deg,#7b3ff2,#f97316)]"
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <EmptyState text="No vendor activity yet." />
                )}
              </div>
            </DashboardSection>

            {/* Recent Users */}
            <DashboardSection
              title="Recent Users"
              subtitle="Latest subscribers on the platform."
              onViewAll={() => goToTab("users")}
              viewAllLabel="View All Users"
            >
              <div className="[display:flex] [flex-direction:column] [gap:12px]">
                {recentUsers.length ? (
                  recentUsers.map((user) => (
                    <div
                      key={user._id}
                      className="[display:flex] [align-items:center] [justify-content:space-between] [gap:16px] [flex-wrap:wrap] [background:white] [padding:16px_20px] [border-radius:16px] [border:1px_solid_rgba(123,63,242,0.08)]"
                    >
                      <div className="[min-width:0]">
                        <p className="[margin:0] [font-weight:700] [color:#111827]">
                          {user.name}
                        </p>
                        <small className="[color:rgba(15,23,42,0.55)]">
                          {user.email}
                        </small>
                      </div>
                      <div className="[display:flex] [align-items:center] [gap:10px] [flex-wrap:wrap]">
                        <span className="[color:#7b3ff2] [font-weight:700] [font-size:0.85rem]">
                          {user.currentPlan || "No Plan"}
                        </span>
                        <StatusPill
                          status={
                            user.subscriptionStatus === "active"
                              ? "active"
                              : "inactive"
                          }
                        />
                      </div>
                    </div>
                  ))
                ) : (
                  <EmptyState text="No users yet." />
                )}
              </div>
            </DashboardSection>

            {/* Recent Payments */}
            <DashboardSection
              title="Recent Payments"
              subtitle="Latest subscription transactions."
              onViewAll={() => goToTab("payments")}
              viewAllLabel="View All Payments"
            >
              <div className="[display:flex] [flex-direction:column] [gap:12px]">
                {dashboard.payments?.length ? (
                  dashboard.payments.slice(0, 5).map((payment) => (
                    <div
                      key={payment._id}
                      className="[display:flex] [justify-content:space-between] [align-items:center] [gap:16px] [flex-wrap:wrap] [background:white] [padding:16px_20px] [border-radius:16px] [border:1px_solid_rgba(123,63,242,0.06)]"
                    >
                      <div>
                        <h4 className="[margin:0_0_4px] [color:#111827] [font-size:0.98rem]">
                          {payment.planName}
                        </h4>
                        <small className="[color:rgba(15,23,42,0.55)]">
                          {new Date(payment.createdAt).toLocaleDateString()}
                        </small>
                      </div>
                      <div className="[display:flex] [align-items:center] [gap:12px]">
                        <strong className="[color:#111827]">
                          ₹{payment.amount}
                        </strong>
                        <StatusPill status={payment.status} />
                      </div>
                    </div>
                  ))
                ) : (
                  <EmptyState text="No payments yet." />
                )}
              </div>
            </DashboardSection>

            {/* Analytics Snapshot */}
            <DashboardSection
              title="Analytics Snapshot"
              subtitle="Platform revenue and operations overview."
              onViewAll={() => goToTab("analytics")}
              viewAllLabel="View Full Analytics"
            >
              <div className="[display:grid] [grid-template-columns:repeat(auto-fit,minmax(180px,1fr))] [gap:20px]">
                {[
                  { label: "Revenue", value: `₹${dashboard.revenue}` },
                  { label: "Users", value: dashboard.totalUsers },
                  {
                    label: "Subscriptions",
                    value: dashboard.activeSubscriptions,
                  },
                  { label: "Requests", value: requests.length },
                ].map(({ label, value }) => (
                  <div key={label} className={OPS_CARD}>
                    <span className="[color:rgba(15,23,42,0.6)] [font-size:0.9rem]">
                      {label}
                    </span>
                    <strong className="[font-size:2.2rem] [color:#7b3ff2]">
                      {value}
                    </strong>
                  </div>
                ))}
              </div>
            </DashboardSection>

            {/* Live Feed */}
            <DashboardSection
              title="Live Operations Feed"
              subtitle="Real-time activity across requests and payments."
            >
              <div className="[display:flex] [flex-direction:column] [gap:14px]">
                {activities.length ? (
                  activities.slice(0, 5).map((activity) => (
                    <div
                      key={activity.id}
                      className="[display:flex] [align-items:center] [gap:16px] [background:white] [padding:18px] [border-radius:18px] [border:1px_solid_rgba(123,63,242,0.08)]"
                    >
                      <div className="[width:14px] [height:14px] [flex-shrink:0] [border-radius:50%] [background:linear-gradient(135deg,#7b3ff2,#f97316)]" />
                      <div>
                        <p className="[margin:0]">{activity.message}</p>
                        <small className="[color:rgba(15,23,42,0.55)]">
                          {activity.time}
                        </small>
                      </div>
                    </div>
                  ))
                ) : (
                  <EmptyState text="No activity yet." />
                )}
              </div>
            </DashboardSection>
          </>
        )}

        {/* ══ USERS TAB ══ */}
        {tab === "users" && (
          <>
            <div className="[margin-bottom:24px]">
              <h2 className={SECTION_H2}>Users</h2>
              <p className={SECTION_P}>Search and manage subscribed users.</p>
            </div>
            <input
              type="text"
              className="[width:100%] [margin-bottom:20px] [padding:14px_18px] [border-radius:14px] [border:1px_solid_#ddd] [font-size:0.95rem] [font-family:inherit] [outline:none]"
              placeholder="Search users..."
              value={userSearch}
              onChange={(e) => setUserSearch(e.target.value)}
            />
            <div className="[border-radius:20px] [overflow:hidden] [border:1px_solid_rgba(123,63,242,0.08)]">
              <table className={TABLE_CLS}>
                <thead className="[background:rgba(123,63,242,0.05)]">
                  <tr>
                    {["Name", "Email", "Plan", "Status", "Expiry"].map((h) => (
                      <th key={h} className={TH_CLS}>
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filteredUsers.map((user) => (
                    <tr
                      key={user._id}
                      className="hover:[background:rgba(123,63,242,0.04)]"
                    >
                      <td className={TD_CLS}>{user.name}</td>
                      <td className={TD_CLS}>{user.email}</td>
                      <td className={TD_CLS}>{user.currentPlan || "-"}</td>
                      <td className={TD_CLS}>
                        <StatusPill
                          status={
                            user.subscriptionStatus === "active"
                              ? "active"
                              : "inactive"
                          }
                        />
                      </td>
                      <td className={TD_CLS}>
                        {user.subscriptionExpiresAt
                          ? new Date(
                              user.subscriptionExpiresAt,
                            ).toLocaleDateString()
                          : "-"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}

        {/* ══ REQUESTS TAB ══ */}
        {tab === "requests" && (
          <>
            <div className="[margin-bottom:24px]">
              <span className="[color:#7b3ff2] [font-size:0.78rem] [font-weight:800] [letter-spacing:0.14em] [text-transform:uppercase] [display:block] [margin-bottom:6px]">
                Service Operations
              </span>
              <h2 className={SECTION_H2}>Service Requests</h2>
              <p className={SECTION_P}>
                Choose one workflow to review requests with a cleaner, focused
                admin view.
              </p>
            </div>

            <div className="[display:grid] [grid-template-columns:repeat(3,minmax(220px,1fr))] [gap:24px] max-[1200px]:[grid-template-columns:1fr]">
              {[
                {
                  title: "Pending",
                  status: "pending",
                  kind: "pending",
                  desc: "Requests waiting for assignment.",
                  path: "/admin/requests/pending",
                  labelCls: "[color:#d97706] [background:#fff7e6]",
                  blobCls: "after:[background:#ff9b54]",
                },
                {
                  title: "In Progress",
                  status: "in-progress",
                  kind: "progress",
                  desc: "Requests currently being handled.",
                  path: "/admin/requests/in-progress",
                  labelCls: "[color:#0284c7] [background:#e0f2fe]",
                  blobCls: "after:[background:#38bdf8]",
                },
                {
                  title: "Completed",
                  status: "completed",
                  kind: "completed",
                  desc: "Resolved requests, evidence and audit.",
                  path: "/admin/requests/completed",
                  labelCls: "[color:#16a34a] [background:#dcfce7]",
                  blobCls: "after:[background:#22c55e]",
                },
              ].map((card) => {
                const count = requests.filter(
                  (r) => r.status === card.status,
                ).length;
                return (
                  <button
                    type="button"
                    key={card.status}
                    onClick={() => navigate(card.path)}
                    className={`[position:relative] [min-height:230px] [padding:28px] [border:1px_solid_rgba(123,63,242,0.1)] [border-radius:30px] [text-align:left] [cursor:pointer] [overflow:hidden] [transition:transform_0.25s_ease,box-shadow_0.25s_ease,border-color_0.25s_ease] hover:[transform:translateY(-8px)] hover:[border-color:rgba(123,63,242,0.24)] hover:[box-shadow:0_26px_70px_rgba(123,63,242,0.16)] ${GLASS_CARD} after:[content:''] after:[position:absolute] after:[inset:auto_-36px_-58px_auto] after:[width:160px] after:[height:160px] after:[border-radius:50%] after:[opacity:0.24] after:[filter:blur(2px)] ${card.blobCls}`}
                  >
                    <div>
                      <span
                        className={`[display:inline-flex] [align-items:center] [margin-bottom:18px] [padding:9px_14px] [border-radius:999px] [font-size:0.78rem] [font-weight:900] [letter-spacing:0.08em] [text-transform:uppercase] ${card.labelCls}`}
                      >
                        {card.title}
                      </span>
                      <h3 className="[margin:0_0_8px] [color:#111827] [font-size:clamp(3rem,5vw,5rem)] [line-height:0.9]">
                        {count}
                      </h3>
                      <p className="[width:min(260px,100%)] [margin:0] [color:rgba(15,23,42,0.64)] [font-size:1rem] [line-height:1.55]">
                        {card.desc}
                      </p>
                    </div>
                    <span className="[position:absolute] [right:24px] [bottom:22px] [color:#7b3ff2] [font-weight:900]">
                      View Requests →
                    </span>
                  </button>
                );
              })}
            </div>
          </>
        )}

        {/* ══ STAFF TAB ══ */}
        {tab === "staff" && (
          <>
            <div className="[margin-bottom:24px]">
              <h2 className={SECTION_H2}>Staff Management</h2>
              <p className={SECTION_P}>
                Manage field executives and care coordinators.
              </p>
            </div>

            {/* Add Staff form */}
            <div className={`${FORM_CARD}`}>
              <h3 className="[margin:0_0_18px] [font-size:1.05rem] [font-weight:800] [color:#111827]">
                Add New Staff
              </h3>
              <div className="[display:grid] [grid-template-columns:repeat(auto-fit,minmax(180px,1fr))] [gap:14px] [margin-bottom:18px]">
                {[
                  { label: "Name", key: "name", placeholder: "Full name" },
                  {
                    label: "Email",
                    key: "email",
                    placeholder: "email@example.com",
                  },
                  { label: "Phone", key: "phone", placeholder: "Phone number" },
                  {
                    label: "Designation",
                    key: "designation",
                    placeholder: "e.g. Care Coordinator",
                  },
                  { label: "City", key: "city", placeholder: "City" },
                ].map(({ label, key, placeholder }) => (
                  <div key={key} className={FIELD_CLS}>
                    <label className={LABEL_CLS}>{label}</label>
                    <input
                      className={INPUT_CLS}
                      placeholder={placeholder}
                      value={staffForm[key]}
                      onChange={(e) =>
                        setStaffForm({ ...staffForm, [key]: e.target.value })
                      }
                    />
                  </div>
                ))}
              </div>
              <div className="[display:flex] [justify-content:flex-end]">
                <button
                  className="[border:none] [padding:12px_32px] [border-radius:12px] [cursor:pointer] [font-weight:700] [font-size:0.9rem] [color:white] [background:linear-gradient(135deg,#7b3ff2,#f97316)] hover:[opacity:0.92] [transition:opacity_0.2s]"
                  onClick={createStaff}
                >
                  + Add Staff
                </button>
              </div>
            </div>

            {/* Staff table */}
            <div className="[border-radius:20px] [overflow:hidden] [border:1px_solid_rgba(123,63,242,0.08)]">
              <table className={TABLE_CLS}>
                <thead className="[background:rgba(123,63,242,0.05)]">
                  <tr>
                    {[
                      "Name",
                      "Email",
                      "Phone",
                      "Designation",
                      "City",
                      "Status",
                      "Actions",
                    ].map((h) => (
                      <th key={h} className={TH_CLS}>
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {staff.length === 0 ? (
                    <tr>
                      <td
                        colSpan={7}
                        className="[text-align:center] [padding:32px] [color:rgba(15,23,42,0.5)]"
                      >
                        No staff members added yet.
                      </td>
                    </tr>
                  ) : (
                    staff.map((member) => (
                      <tr
                        key={member._id}
                        className="hover:[background:rgba(123,63,242,0.04)]"
                      >
                        <td className={TD_CLS}>{member.name}</td>
                        <td className={TD_CLS}>{member.email}</td>
                        <td className={TD_CLS}>{member.phone}</td>
                        <td className={TD_CLS}>{member.designation}</td>
                        <td className={TD_CLS}>{member.city}</td>
                        <td className={TD_CLS}>
                          <StatusPill status={member.status || "active"} />
                        </td>
                        <td className={TD_CLS}>
                          <button
                            className="[border:none] [padding:8px_16px] [border-radius:10px] [background:#fee2e2] [color:#dc2626] [font-weight:700] [font-size:0.82rem] [cursor:pointer] hover:[background:#fecaca] [transition:background_0.2s]"
                            onClick={() => deleteStaff(member._id)}
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </>
        )}

        {/* ══ VENDORS TAB ══ */}
        {tab === "vendors" && (
          <>
            <div className="[margin-bottom:24px]">
              <h2 className={SECTION_H2}>Vendor Management</h2>
              <p className={SECTION_P}>
                Manage service providers and contractors.
              </p>
            </div>

            {/* Add Vendor form */}
            <div className={`${FORM_CARD}`}>
              <h3 className="[margin:0_0_18px] [font-size:1.05rem] [font-weight:800] [color:#111827]">
                Add New Vendor
              </h3>
              <div className="[display:grid] [grid-template-columns:repeat(auto-fit,minmax(180px,1fr))] [gap:14px] [margin-bottom:18px]">
                {[
                  {
                    label: "Owner Name",
                    key: "ownerName",
                    placeholder: "Owner name",
                  },
                  {
                    label: "Business Name",
                    key: "businessName",
                    placeholder: "Business name",
                  },
                  {
                    label: "Email",
                    key: "email",
                    placeholder: "email@example.com",
                  },
                  { label: "Phone", key: "phone", placeholder: "Phone number" },
                ].map(({ label, key, placeholder }) => (
                  <div key={key} className={FIELD_CLS}>
                    <label className={LABEL_CLS}>{label}</label>
                    <input
                      className={INPUT_CLS}
                      placeholder={placeholder}
                      value={vendorForm[key]}
                      onChange={(e) =>
                        setVendorForm({ ...vendorForm, [key]: e.target.value })
                      }
                    />
                  </div>
                ))}
                <div className={FIELD_CLS}>
                  <label className={LABEL_CLS}>Category</label>
                  <select
                    className={INPUT_CLS}
                    value={vendorForm.category}
                    onChange={(e) =>
                      setVendorForm({ ...vendorForm, category: e.target.value })
                    }
                  >
                    <option value="">Select Category</option>
                    {categories.map((cat) => (
                      <option key={cat._id} value={cat.name}>
                        {cat.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div className={FIELD_CLS}>
                  <label className={LABEL_CLS}>City</label>
                  <input
                    className={INPUT_CLS}
                    placeholder="City"
                    value={vendorForm.city}
                    onChange={(e) =>
                      setVendorForm({ ...vendorForm, city: e.target.value })
                    }
                  />
                </div>
              </div>
              <div className="[display:flex] [justify-content:flex-end]">
                <button
                  className="[border:none] [padding:12px_32px] [border-radius:12px] [cursor:pointer] [font-weight:700] [font-size:0.9rem] [color:white] [background:linear-gradient(135deg,#7b3ff2,#f97316)] hover:[opacity:0.92] [transition:opacity_0.2s]"
                  onClick={createVendor}
                >
                  + Add Vendor
                </button>
              </div>
            </div>

            {/* Vendor table */}
            <div className="[border-radius:20px] [overflow:hidden] [border:1px_solid_rgba(123,63,242,0.08)]">
              <table className={TABLE_CLS}>
                <thead className="[background:rgba(123,63,242,0.05)]">
                  <tr>
                    {[
                      "Business",
                      "Owner",
                      "Category",
                      "Phone",
                      "City",
                      "Status",
                      "Jobs",
                      "Actions",
                    ].map((h) => (
                      <th key={h} className={TH_CLS}>
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {vendors.length === 0 ? (
                    <tr>
                      <td
                        colSpan={8}
                        className="[text-align:center] [padding:32px] [color:rgba(15,23,42,0.5)]"
                      >
                        No vendors added yet.
                      </td>
                    </tr>
                  ) : (
                    vendors.map((vendor) => (
                      <tr
                        key={vendor._id}
                        className="hover:[background:rgba(123,63,242,0.04)]"
                      >
                        <td className={TD_CLS}>{vendor.businessName}</td>
                        <td className={TD_CLS}>{vendor.ownerName}</td>
                        <td className={TD_CLS}>{vendor.category}</td>
                        <td className={TD_CLS}>{vendor.phone}</td>
                        <td className={TD_CLS}>{vendor.city}</td>
                        <td className={TD_CLS}>
                          <StatusPill status={vendor.status || "active"} />
                        </td>
                        <td className={TD_CLS}>
                          <span className="[display:inline-flex] [align-items:center] [padding:6px_12px] [border-radius:999px] [background:rgba(123,63,242,0.08)] [color:#7b3ff2] [font-weight:700] [font-size:0.82rem]">
                            {vendor.completedJobs}/{vendor.totalJobs}
                          </span>
                        </td>
                        <td className={TD_CLS}>
                          <button
                            className="[border:none] [padding:8px_16px] [border-radius:10px] [background:#fee2e2] [color:#dc2626] [font-weight:700] [font-size:0.82rem] [cursor:pointer] hover:[background:#fecaca] [transition:background_0.2s]"
                            onClick={() => deleteVendor(vendor._id)}
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Vendor Performance */}
            <div className="[margin:40px_0]">
              <div className="[margin-bottom:24px]">
                <h2 className={SECTION_H2}>Vendor Performance</h2>
              </div>
              <div className="[display:grid] [grid-template-columns:repeat(auto-fit,minmax(280px,1fr))] [gap:20px]">
                {dashboard.vendorMetrics?.map((vendor) => {
                  const pct =
                    vendor.assigned > 0
                      ? Math.round((vendor.completed / vendor.assigned) * 100)
                      : 0;
                  return (
                    <div
                      key={vendor._id}
                      className="bg-white [border-radius:24px] [padding:24px] [border:1px_solid_rgba(123,63,242,0.08)]"
                    >
                      <div className="[display:inline-flex] [align-items:center] [justify-content:center] [width:40px] [height:40px] [border-radius:12px] [background:rgba(123,63,242,0.08)] [font-size:1.2rem] [margin-bottom:12px]">
                        🏢
                      </div>
                      <h3 className="[margin-bottom:18px] [color:#7b3ff2]">
                        {vendor._id}
                      </h3>
                      <div className="[display:flex] [justify-content:space-between] [margin-bottom:20px]">
                        {[
                          ["Assigned", vendor.assigned],
                          ["Completed", vendor.completed],
                        ].map(([lbl, val]) => (
                          <div key={lbl}>
                            <span className="[display:block] [font-size:0.8rem] [color:rgba(15,23,42,0.6)]">
                              {lbl}
                            </span>
                            <strong className="[font-size:1.4rem]">
                              {val}
                            </strong>
                          </div>
                        ))}
                      </div>
                      <div className="[height:10px] [border-radius:999px] [background:#edf2f7] [overflow:hidden]">
                        <div
                          className="[height:100%] [border-radius:999px] [background:linear-gradient(135deg,#7b3ff2,#f97316)]"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </>
        )}

        {/* ══ PAYMENTS TAB ══ */}
        {tab === "payments" && (
          <>
            <div className="[margin-bottom:24px]">
              <h2 className={SECTION_H2}>Recent Payments</h2>
              <p className={SECTION_P}>Latest subscription transactions.</p>
            </div>
            <div className="[display:flex] [flex-direction:column] [gap:16px]">
              {dashboard.payments?.map((payment) => (
                <div
                  key={payment._id}
                  className="[display:flex] [justify-content:space-between] [align-items:center] [background:white] [padding:20px] [border-radius:18px] [border:1px_solid_rgba(123,63,242,0.06)]"
                >
                  <div>
                    <h4 className="[margin:0_0_4px] [color:#111827]">
                      {payment.planName}
                    </h4>
                    <small className="[color:rgba(15,23,42,0.55)]">
                      {new Date(payment.createdAt).toLocaleDateString()}
                    </small>
                  </div>
                  <div className="[display:flex] [align-items:center] [gap:12px]">
                    <strong className="[color:#111827]">
                      ₹{payment.amount}
                    </strong>
                    <StatusPill status={payment.status} />
                  </div>
                </div>
              ))}
            </div>
          </>
        )}

        {/* ══ ANALYTICS TAB ══ */}
        {tab === "analytics" && (
          <>
            <div className="[margin-bottom:24px]">
              <h2 className={SECTION_H2}>Revenue Analytics</h2>
              <p className={SECTION_P}>
                Platform revenue and operations overview.
              </p>
            </div>

            {/* KPI */}
            <div className="[display:grid] [grid-template-columns:repeat(4,1fr)] [gap:20px] [margin-bottom:24px] max-[1000px]:[grid-template-columns:repeat(2,1fr)]">
              {[
                { label: "Revenue", value: `₹${dashboard.revenue}` },
                { label: "Users", value: dashboard.totalUsers },
                {
                  label: "Subscriptions",
                  value: dashboard.activeSubscriptions,
                },
                { label: "Requests", value: requests.length },
              ].map(({ label, value }) => (
                <div key={label} className={OPS_CARD}>
                  <span className="[color:rgba(15,23,42,0.6)] [font-size:0.9rem]">
                    {label}
                  </span>
                  <strong className="[font-size:2.2rem] [color:#7b3ff2]">
                    {value}
                  </strong>
                </div>
              ))}
            </div>

            {/* Revenue Trend */}
            <div className="bg-white [padding:24px] [border-radius:24px] [min-height:420px] [overflow:visible]">
              <h3 className="[margin:0_0_20px] [color:#111827]">
                Revenue Trend
              </h3>
              <AreaChart width={1000} height={350} data={analyticsRevenueData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Area
                  type="monotone"
                  dataKey="revenue"
                  stroke="#7b3ff2"
                  fill="#7b3ff2"
                  fillOpacity={0.2}
                />
              </AreaChart>
            </div>

            {/* Pie + Metrics */}
            <div className="[display:grid] [grid-template-columns:1fr_1fr] [gap:24px] [margin-top:24px] max-[1000px]:[grid-template-columns:1fr]">
              <div className="bg-white [padding:24px] [border-radius:24px] [min-height:420px] [overflow:visible]">
                <h3 className="[margin:0_0_20px] [color:#111827]">
                  Request Status
                </h3>
                <ResponsiveContainer width="100%" height={350}>
                  <PieChart>
                    <Pie
                      data={requestStatusData}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={120}
                      paddingAngle={3}
                      label
                    >
                      {requestStatusData.map((_, index) => (
                        <Cell
                          key={index}
                          fill={pieColors[index % pieColors.length]}
                        />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="bg-white [padding:24px] [border-radius:24px] [min-height:420px]">
                <h3 className="[margin:0_0_20px] [color:#111827]">
                  Request Metrics
                </h3>
                <div className="[display:flex] [flex-direction:column] [gap:16px] [margin-top:20px]">
                  {[
                    { label: "Pending", value: requestStatusData[0]?.value },
                    {
                      label: "In Progress",
                      value: requestStatusData[1]?.value,
                    },
                    { label: "Completed", value: requestStatusData[2]?.value },
                    { label: "Cancelled", value: requestStatusData[3]?.value },
                  ].map(({ label, value }) => (
                    <div key={label} className={METRIC_ROW}>
                      <span className="[color:rgba(15,23,42,0.7)]">
                        {label}
                      </span>
                      <strong className="[color:#7b3ff2] [font-size:1.1rem]">
                        {value}
                      </strong>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Top Services + Growth */}
            <div className="[display:grid] [grid-template-columns:1fr_1fr] [gap:24px] [margin-top:24px] max-[1000px]:[grid-template-columns:1fr]">
              <div className="bg-white [padding:24px] [border-radius:24px] [min-height:420px]">
                <h3 className="[margin:0_0_20px] [color:#111827]">
                  Top Services
                </h3>
                <div className="[display:flex] [flex-direction:column] [gap:16px]">
                  {topServices.map(([service, count]) => (
                    <div key={service} className={METRIC_ROW}>
                      <span className="[color:rgba(15,23,42,0.7)]">
                        {service}
                      </span>
                      <strong className="[color:#7b3ff2] [font-size:1.1rem]">
                        {count}
                      </strong>
                    </div>
                  ))}
                </div>
              </div>
              <div className="bg-white [padding:24px] [border-radius:24px] [min-height:420px]">
                <h3 className="[margin:0_0_20px] [color:#111827]">
                  Monthly Growth
                </h3>
                <div className="[display:flex] [flex-direction:column] [gap:16px]">
                  {[
                    ["Revenue Growth", "+18%"],
                    ["User Growth", "+12%"],
                    ["Subscriptions", "+9%"],
                  ].map(([label, value]) => (
                    <div key={label} className={METRIC_ROW}>
                      <span className="[color:rgba(15,23,42,0.7)]">
                        {label}
                      </span>
                      <strong className="[color:#7b3ff2] [font-size:1.1rem]">
                        {value}
                      </strong>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </>
        )}

        {tab === "newsletters" && <AdminNewsletter />}
        {tab === "settings" && <AdminSettings />}
      </div>

      <EvidenceViewerModal
        open={showEvidenceModal}
        photos={selectedPhotos}
        onClose={() => setShowEvidenceModal(false)}
      />
    </section>
  );
}

export default AdminDashboard;

import { useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "@api/axios";
import PasswordInput from "@ui/PasswordInput";
import ForgotPasswordModal from "@ui/ForgotPasswordModal";

function AdminLogin() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    identifier: "",
    password: "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [showForgot, setShowForgot] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    try {
      setLoading(true);

      const { data } = await API.post("/admin/login", formData);

      localStorage.setItem("adminToken", data.token);
      localStorage.setItem("adminData", JSON.stringify(data.admin));

      navigate("/admin/dashboard");
    } catch (err) {
      setError(
        err.response?.data?.message || "Login failed. Check your credentials.",
      );
    } finally {
      setLoading(false);
    }
  };

  const inputCls = `
w-full
h-[64px]
px-6
pr-[74px]
rounded-[18px]
border
border-[rgba(148,163,184,0.18)]
bg-[rgba(255,255,255,0.82)]
text-[16px]
text-slate-900
placeholder:text-slate-400
transition-all
duration-300
focus:outline-none
focus:border-[#7b3ff2]
focus:ring-4
focus:ring-[rgba(123,63,242,0.08)]
`;

  return (
    <section className="[min-height:calc(100vh_-_160px)] [display:flex] [align-items:center] [justify-content:center] [padding:60px_24px] max-[640px]:[padding:40px_18px]">
      <form
        className="
          relative
          overflow-hidden
          w-full
          max-w-[560px]
          rounded-[30px]
          border
        border-white/80
        bg-white/75
          backdrop-blur-2xl
          shadow-[0_30px_80px_rgba(123,63,242,0.12)]
          px-12
          py-11
          flex
          flex-col
          gap-5

          before:absolute
          before:-right-24
          before:-top-24
          before:h-72
          before:w-72
          before:rounded-full
          before:bg-[radial-gradient(circle,rgba(123,63,242,0.14),transparent_70%)]
          before:pointer-events-none

          max-md:px-7
          max-md:py-8
          max-md:rounded-[24px]
        "
        onSubmit={handleSubmit}
      >
        <div className="relative z-10 mb-2">
          <span className="text-[13px] font-extrabold uppercase tracking-[0.24em] text-[#7b3ff2]">
            Operations Center
          </span>

          <h1 className="mt-3 text-[56px] leading-[1.02] font-semibold tracking-[-0.03em] text-slate-900">
            Admin Login
          </h1>

          <p className="mt-4 text-[16px] leading-7 text-slate-500 max-w-[420px]">
            Securely access the MyFamilyAnchor administration console to manage
            customers, staff, vendors and platform operations.
          </p>
        </div>

        {/* inline error message */}
        {error && (
          <p
            className="
              rounded-2xl
              border
            border-red-200
            bg-red-50
              text-sm
              font-medium
            text-red-700
              py-1
              [text-align:center]"
            role="alert"
          >
            {error}
          </p>
        )}

        <input
          className={inputCls}
          type="text"
          placeholder="Email or Phone Number"
          required
          value={formData.identifier}
          onChange={(e) =>
            setFormData({ ...formData, identifier: e.target.value })
          }
        />

        <PasswordInput
          className={inputCls}
          placeholder="Password"
          required
          value={formData.password}
          onChange={(e) =>
            setFormData({ ...formData, password: e.target.value })
          }
        />

        <button
          type="button"
          className="
            self-end
            text-[14px]
            font-semibold
          text-[#7b3ff2]
            transition-all
            duration-300
          hover:text-[#ff5ca8]
            hover:underline
            underline-offset-4
"
          onClick={() => setShowForgot(true)}
        >
          Forgot Password?
        </button>

        <button
          type="submit"
          className="
            h-[64px]
            w-full
            rounded-[18px]
            font-bold
            text-lg
          text-white
            bg-[linear-gradient(135deg,#7b3ff2,#ff5ca8,#ff9b54)]
            shadow-[0_22px_45px_rgba(123,63,242,0.25)]
            transition-all
            duration-300
            hover:-translate-y-[2px]
            hover:shadow-[0_28px_55px_rgba(123,63,242,0.35)]
            active:translate-y-0
          "
          disabled={loading}
        >
          {loading ? "Logging in..." : "Login"}
        </button>
      </form>

      {showForgot && (
        <ForgotPasswordModal
          role="admin"
          onClose={() => setShowForgot(false)}
        />
      )}
    </section>
  );
}

export default AdminLogin;

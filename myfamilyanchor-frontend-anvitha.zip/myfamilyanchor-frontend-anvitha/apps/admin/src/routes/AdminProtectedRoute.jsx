import { Navigate, Outlet } from "react-router-dom";

function AdminProtectedRoute() {
  const adminToken = localStorage.getItem("adminToken");
  const adminData = localStorage.getItem("adminData");

  if (!adminToken || !adminData) {
    // Clean up any partial state
    localStorage.removeItem("adminToken");
    localStorage.removeItem("adminData");
    return <Navigate to="/admin/login" replace />;
  }

  // Validate that adminData is parseable JSON — if corrupted it would
  try {
    JSON.parse(adminData);
  } catch {
    localStorage.removeItem("adminToken");
    localStorage.removeItem("adminData");
    return <Navigate to="/admin/login" replace />;
  }

  return <Outlet />;
}

export default AdminProtectedRoute;

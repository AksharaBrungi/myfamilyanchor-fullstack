/* Version 2 */
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";
import { fileURLToPath } from "url";

// __dirname is not available in ES modules — derive it manually
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default defineConfig({
  plugins: [react()],

  resolve: {
    alias: {
      // Root packages (monorepo: apps/website/  →  ../../packages/)
      "@packages": path.resolve(__dirname, "../../packages"),
      "@ui": path.resolve(__dirname, "../../packages/ui"),
      "@api": path.resolve(__dirname, "../../packages/api"),
      "@auth": path.resolve(__dirname, "../../packages/auth"),
      "@utils": path.resolve(__dirname, "../../packages/utils"),
      "@assets": path.resolve(__dirname, "../../packages/assets"),
    },
  },
  build: {
    outDir: "dist",
    emptyOutDir: true,
  },
});

import { Navigate, Outlet } from "react-router-dom";
import { useStaffAuth } from "@auth/StaffAuthContext";

const StaffProtectedRoute = () => {
  const { staff, loading } = useStaffAuth();

  if (loading) {
    return <div>Loading...</div>;
  }

  return staff ? <Outlet /> : <Navigate to="/staff/login" replace />;
};

export default StaffProtectedRoute;

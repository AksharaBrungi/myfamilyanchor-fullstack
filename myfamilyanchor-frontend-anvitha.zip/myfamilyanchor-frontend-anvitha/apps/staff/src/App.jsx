import { Routes, Route } from "react-router-dom";

import StaffLayout from "./layouts/StaffLayout";
import StaffLogin from "./pages/StaffLogin";
import StaffDashboard from "./pages/StaffDashboard";
import StaffProtectedRoute from "./routes/StaffProtectedRoute";
import StaffNotFound from "./pages/StaffNotFound";

function App() {
  return (
    <Routes>
      <Route path="/staff/login" element={<StaffLogin />} />

      <Route element={<StaffProtectedRoute />}>
        <Route element={<StaffLayout />}>
          <Route path="/staff/dashboard" element={<StaffDashboard />} />
        </Route>
      </Route>

      {/* Catch-all: unknown staff routes, or the website/staff/vendor
          app's routes opened on this app by mistake — shows a clean 404
          instead of a blank page. */}
      <Route path="*" element={<StaffNotFound />} />
    </Routes>
  );
}

export default App;

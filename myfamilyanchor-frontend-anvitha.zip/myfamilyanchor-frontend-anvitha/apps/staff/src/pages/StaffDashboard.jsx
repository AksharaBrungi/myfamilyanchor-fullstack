import { useEffect, useState, useCallback, useRef } from "react";
import { useOutletContext } from "react-router-dom";
import toast from "react-hot-toast";
import API from "@api/axios";
import socket from "@api/socket";
import { useStaffAuth } from "@auth/StaffAuthContext";

const GLASS = {
  background: "rgba(255,255,255,0.72)",
  border: "1px solid rgba(255,255,255,0.78)",
  boxShadow: "0 24px 70px rgba(123,63,242,0.13)",
  backdropFilter: "blur(22px)",
  WebkitBackdropFilter: "blur(22px)",
};

const CARD = {
  background: "white",
  borderRadius: "22px",
  padding: "20px",
  border: "1px solid rgba(123,63,242,0.09)",
  boxShadow: "0 4px 20px rgba(123,63,242,0.06)",
  display: "flex",
  flexDirection: "column",
  gap: "12px",
  transition: "border-color 0.25s, box-shadow 0.25s, transform 0.2s",
};

const INPUT_STYLE = {
  padding: "9px 12px",
  borderRadius: "10px",
  border: "1px solid #ddd",
  background: "white",
  fontSize: "0.9rem",
  fontFamily: "inherit",
  outline: "none",
  width: "100%",
  boxSizing: "border-box",
};

const SAVE_BTN_STYLE = {
  width: "100%",
  border: "none",
  padding: "11px",
  borderRadius: "12px",
  cursor: "pointer",
  fontWeight: 700,
  fontSize: "0.92rem",
  color: "white",
  background: "linear-gradient(135deg,#7b3ff2,#f97316)",
  transition: "opacity 0.2s",
};

function StatusPill({ status }) {
  const map = {
    "in-progress": { bg: "rgba(123,63,242,0.1)", color: "#7b3ff2" },
    completed: { bg: "rgba(22,163,74,0.1)", color: "#16a34a" },
    pending: { bg: "rgba(156,163,175,0.15)", color: "#6b7280" },
  };
  const s = map[status] || map.pending;
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        padding: "4px 12px",
        borderRadius: "999px",
        fontSize: "0.78rem",
        fontWeight: 700,
        background: s.bg,
        color: s.color,
        textTransform: "capitalize",
        whiteSpace: "nowrap",
      }}
    >
      {status}
    </span>
  );
}

function MetaStrip({
  vendor,
  // verification,
  awaitingReview,
  sentToAdmin,
  isApproved,
}) {
  const verColor = awaitingReview
    ? "#d97706"
    : sentToAdmin
      ? "#0284c7"
      : isApproved
        ? "#16a34a"
        : "#0f172a";
  const verLabel = awaitingReview
    ? "Needs Review"
    : sentToAdmin
      ? "Awaiting Admin"
      : isApproved
        ? "Approved"
        : "Pending";

  return (
    <div
      style={{
        display: "flex",
        borderRadius: "14px",
        background: "rgba(245,240,255,0.6)",
        overflow: "hidden",
      }}
    >
      {[
        { label: "Vendor", value: vendor || "—", color: null },
        { label: "Verification", value: verLabel, color: verColor },
      ].map(({ label, value, color }, idx, arr) => (
        <div
          key={label}
          style={{
            flex: 1,
            padding: "10px 14px",
            display: "flex",
            flexDirection: "column",
            gap: "3px",
            borderRight:
              idx < arr.length - 1 ? "1px solid rgba(123,63,242,0.12)" : "none",
          }}
        >
          <span
            style={{
              fontSize: "0.68rem",
              fontWeight: 700,
              color: "rgba(15,23,42,0.5)",
              textTransform: "uppercase",
              letterSpacing: "0.06em",
            }}
          >
            {label}
          </span>
          <strong style={{ fontSize: "0.87rem", color: color || "#0f172a" }}>
            {value}
          </strong>
        </div>
      ))}
    </div>
  );
}

/* Photo thumbnail strip */
function PhotoStrip({ label, photos }) {
  if (!photos?.length) return null;
  return (
    <div>
      <p
        style={{
          margin: "0 0 8px",
          fontSize: "0.72rem",
          fontWeight: 700,
          textTransform: "uppercase",
          letterSpacing: "0.06em",
          color: "rgba(15,23,42,0.5)",
        }}
      >
        {label}
      </p>
      <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
        {photos.map((photo, i) => (
          <img
            key={i}
            src={photo.url}
            alt={label}
            style={{
              width: "80px",
              height: "80px",
              objectFit: "cover",
              borderRadius: "12px",
              border: "1px solid rgba(123,63,242,0.1)",
              transition: "transform 0.2s",
              cursor: "zoom-in",
            }}
            onMouseEnter={(e) =>
              (e.currentTarget.style.transform = "scale(1.06)")
            }
            onMouseLeave={(e) => (e.currentTarget.style.transform = "none")}
          />
        ))}
      </div>
    </div>
  );
}

/* MANAGE PANEL */
function ManagePanel({
  request,
  onUploadPhoto,
  onAddNote,
  noteInputs,
  setNoteInputs,
  onVerify,
}) {
  const [uploading, setUploading] = useState(false);
  const beforeRef = useRef();
  const afterRef = useRef();

  const beforePhotos =
    request.jobPhotos?.filter((p) => p.photoType === "before") || [];
  const afterPhotos =
    request.jobPhotos?.filter((p) => p.photoType === "after") || [];

  const awaitingReview = request.verificationStatus === "submitted";
  const sentToAdmin = request.verificationStatus === "staff-approved";
  const isApproved = request.verificationStatus === "approved";

  const handleUpload = async (files, photoType) => {
    if (!files?.length) return;
    setUploading(true);
    try {
      const formData = new FormData();
      Array.from(files).forEach((f) => formData.append("photos", f));
      formData.append("photoType", photoType);
      await onUploadPhoto(request._id, formData);
      toast.success(
        `${photoType === "before" ? "Before" : "After"} photo uploaded`,
      );
    } catch {
      toast.error("Upload failed");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div
      style={{
        marginTop: "4px",
        padding: "18px",
        borderRadius: "18px",
        background: "rgba(246,240,255,0.5)",
        border: "1px solid rgba(123,63,242,0.12)",
        display: "flex",
        flexDirection: "column",
        gap: "16px",
      }}
    >
      {/* ── Photo upload ── */}
      <div>
        <p
          style={{
            margin: "0 0 10px",
            fontSize: "0.75rem",
            fontWeight: 800,
            textTransform: "uppercase",
            letterSpacing: "0.08em",
            color: "#7b3ff2",
          }}
        >
          Upload Job Photos
        </p>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: "10px",
          }}
        >
          {/* Before */}
          <div>
            <input
              ref={beforeRef}
              type="file"
              accept="image/*"
              multiple
              style={{ display: "none" }}
              onChange={(e) => handleUpload(e.target.files, "before")}
            />
            <button
              onClick={() => beforeRef.current?.click()}
              disabled={uploading}
              style={{
                width: "100%",
                padding: "10px 0",
                border: "1.5px dashed rgba(123,63,242,0.35)",
                borderRadius: "12px",
                background: "rgba(255,255,255,0.72)",
                color: "#7b3ff2",
                fontWeight: 700,
                fontSize: "0.85rem",
                cursor: uploading ? "not-allowed" : "pointer",
                transition: "background 0.2s",
              }}
              onMouseEnter={(e) =>
                (e.currentTarget.style.background = "rgba(123,63,242,0.06)")
              }
              onMouseLeave={(e) =>
                (e.currentTarget.style.background = "rgba(255,255,255,0.72)")
              }
            >
              📷 Before Photos
            </button>
            {beforePhotos.length > 0 && (
              <p
                style={{
                  margin: "6px 0 0",
                  fontSize: "0.75rem",
                  color: "#7b3ff2",
                  fontWeight: 600,
                }}
              >
                {beforePhotos.length} uploaded
              </p>
            )}
          </div>
          {/* After */}
          <div>
            <input
              ref={afterRef}
              type="file"
              accept="image/*"
              multiple
              style={{ display: "none" }}
              onChange={(e) => handleUpload(e.target.files, "after")}
            />
            <button
              onClick={() => afterRef.current?.click()}
              disabled={uploading}
              style={{
                width: "100%",
                padding: "10px 0",
                border: "1.5px dashed rgba(22,163,74,0.35)",
                borderRadius: "12px",
                background: "rgba(255,255,255,0.72)",
                color: "#16a34a",
                fontWeight: 700,
                fontSize: "0.85rem",
                cursor: uploading ? "not-allowed" : "pointer",
                transition: "background 0.2s",
              }}
              onMouseEnter={(e) =>
                (e.currentTarget.style.background = "rgba(22,163,74,0.05)")
              }
              onMouseLeave={(e) =>
                (e.currentTarget.style.background = "rgba(255,255,255,0.72)")
              }
            >
              ✅ After Photos
            </button>
            {afterPhotos.length > 0 && (
              <p
                style={{
                  margin: "6px 0 0",
                  fontSize: "0.75rem",
                  color: "#16a34a",
                  fontWeight: 600,
                }}
              >
                {afterPhotos.length} uploaded
              </p>
            )}
          </div>
        </div>

        {/* Photo thumbnails */}
        {(beforePhotos.length > 0 || afterPhotos.length > 0) && (
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              gap: "12px",
              marginTop: "14px",
            }}
          >
            <PhotoStrip label="Before Photos" photos={beforePhotos} />
            <PhotoStrip label="After Photos" photos={afterPhotos} />
          </div>
        )}
      </div>

      {/* ── Divider ── */}
      <div style={{ height: "1px", background: "rgba(123,63,242,0.1)" }} />

      {/* ── Add note ── */}
      <div>
        <p
          style={{
            margin: "0 0 8px",
            fontSize: "0.75rem",
            fontWeight: 800,
            textTransform: "uppercase",
            letterSpacing: "0.08em",
            color: "#7b3ff2",
          }}
        >
          Add Staff Note
        </p>
        <div
          style={{
            overflow: "hidden",
            borderRadius: "12px",
            border: "1px solid #e5e7eb",
            background: "white",
            display: "flex",
          }}
        >
          <input
            placeholder="Add a note..."
            value={noteInputs[request._id] || ""}
            onChange={(e) =>
              setNoteInputs((prev) => ({
                ...prev,
                [request._id]: e.target.value,
              }))
            }
            onKeyDown={(e) => e.key === "Enter" && onAddNote(request._id)}
            style={{
              flex: 1,
              border: "none",
              padding: "11px 14px",
              fontSize: "0.88rem",
              color: "#0f172a",
              outline: "none",
              background: "transparent",
              minWidth: 0,
            }}
          />
          <button
            onClick={() => onAddNote(request._id)}
            style={{
              flexShrink: 0,
              padding: "11px 16px",
              border: "none",
              borderLeft: "1px solid #e5e7eb",
              background: "rgba(123,63,242,0.08)",
              color: "#7b3ff2",
              fontWeight: 700,
              fontSize: "0.85rem",
              cursor: "pointer",
              transition: "background 0.2s",
            }}
            onMouseEnter={(e) =>
              (e.currentTarget.style.background = "rgba(123,63,242,0.16)")
            }
            onMouseLeave={(e) =>
              (e.currentTarget.style.background = "rgba(123,63,242,0.08)")
            }
          >
            Add Note
          </button>
        </div>

        {/* Existing staff notes */}
        {request.staffNotes?.length > 0 && (
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              gap: "7px",
              marginTop: "10px",
            }}
          >
            {request.staffNotes.map((note, i) => (
              <div
                key={i}
                style={{
                  display: "flex",
                  gap: "10px",
                  padding: "10px 13px",
                  borderRadius: "11px",
                  background: "#f8fafc",
                  border: "1px solid rgba(123,63,242,0.07)",
                }}
              >
                <span
                  style={{
                    fontSize: "0.68rem",
                    fontWeight: 900,
                    textTransform: "uppercase",
                    letterSpacing: "0.06em",
                    color: "#7b3ff2",
                    whiteSpace: "nowrap",
                    paddingTop: "2px",
                  }}
                >
                  Staff
                </span>
                <p
                  style={{
                    margin: 0,
                    fontSize: "0.87rem",
                    color: "rgba(15,23,42,0.75)",
                    lineHeight: 1.55,
                  }}
                >
                  {note.note}
                </p>
              </div>
            ))}
          </div>
        )}

        {/* Vendor notes (read-only) */}
        {request.vendorNotes?.length > 0 && (
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              gap: "7px",
              marginTop: "10px",
            }}
          >
            <p
              style={{
                margin: "0 0 4px",
                fontSize: "0.68rem",
                fontWeight: 800,
                textTransform: "uppercase",
                letterSpacing: "0.06em",
                color: "rgba(15,23,42,0.45)",
              }}
            >
              Vendor Notes
            </p>
            {request.vendorNotes.map((note, i) => (
              <div
                key={i}
                style={{
                  display: "flex",
                  gap: "10px",
                  padding: "10px 13px",
                  borderRadius: "11px",
                  background: "rgba(245,240,255,0.5)",
                  border: "1px solid rgba(123,63,242,0.07)",
                }}
              >
                <span
                  style={{
                    fontSize: "0.68rem",
                    fontWeight: 900,
                    textTransform: "uppercase",
                    letterSpacing: "0.06em",
                    color: "#7b3ff2",
                    whiteSpace: "nowrap",
                    paddingTop: "2px",
                  }}
                >
                  Vendor
                </span>
                <p
                  style={{
                    margin: 0,
                    fontSize: "0.87rem",
                    color: "rgba(15,23,42,0.75)",
                    lineHeight: 1.55,
                  }}
                >
                  {note.note}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ── Verify button (shows when vendor submitted work) ── */}
      {awaitingReview && (
        <>
          <div style={{ height: "1px", background: "rgba(123,63,242,0.1)" }} />
          <div
            style={{
              padding: "12px 14px",
              borderRadius: "13px",
              background: "#fff7ed",
              color: "#c2410c",
              fontSize: "0.87rem",
              fontWeight: 600,
              lineHeight: 1.5,
              border: "1px solid rgba(234,88,12,0.18)",
            }}
          >
            ⚠️ Vendor has requested completion. Verify the work physically
            before escalating.
          </div>
          <button
            onClick={() => onVerify(request._id)}
            style={{
              ...SAVE_BTN_STYLE,
              background: "linear-gradient(135deg,#16a34a,#15803d)",
              boxShadow: "0 6px 18px rgba(22,163,74,0.25)",
            }}
            onMouseEnter={(e) => (e.currentTarget.style.opacity = "0.88")}
            onMouseLeave={(e) => (e.currentTarget.style.opacity = "1")}
          >
            ✓ Verify Work & Send to Admin
          </button>
        </>
      )}

      {sentToAdmin && (
        <div
          style={{
            padding: "11px 14px",
            borderRadius: "13px",
            fontSize: "0.87rem",
            fontWeight: 600,
            background: "#e0f2fe",
            color: "#0369a1",
            border: "1px solid rgba(2,132,199,0.18)",
          }}
        >
          📤 Sent to admin for final approval
        </div>
      )}

      {isApproved && (
        <div
          style={{
            padding: "11px 14px",
            borderRadius: "13px",
            fontSize: "0.87rem",
            fontWeight: 600,
            background: "#dcfce7",
            color: "#15803d",
            border: "1px solid rgba(22,163,74,0.18)",
          }}
        >
          ✅ Admin approved — job completed
        </div>
      )}
    </div>
  );
}

/* REQUEST CARD */
function RequestCard({
  request,
  onVerify,
  onUploadPhoto,
  onAddNote,
  noteInputs,
  setNoteInputs,
}) {
  const [expanded, setExpanded] = useState(false);

  const beforePhotos =
    request.jobPhotos?.filter((p) => p.photoType === "before") || [];
  const afterPhotos =
    request.jobPhotos?.filter((p) => p.photoType === "after") || [];
  const awaitingReview = request.verificationStatus === "submitted";
  const sentToAdmin = request.verificationStatus === "staff-approved";
  const isApproved = request.verificationStatus === "approved";

  const cardBg = isApproved
    ? "radial-gradient(circle at 95% 5%, rgba(22,163,74,0.06), transparent 30%), white"
    : awaitingReview
      ? "radial-gradient(circle at 95% 5%, rgba(234,88,12,0.06), transparent 30%), white"
      : "white";

  return (
    <article
      style={{
        ...CARD,
        background: cardBg,
        border: awaitingReview
          ? "1px solid rgba(234,88,12,0.28)"
          : expanded
            ? "1px solid rgba(123,63,242,0.35)"
            : "1px solid rgba(123,63,242,0.09)",
        boxShadow: expanded
          ? "0 0 0 3px rgba(123,63,242,0.1), 0 8px 28px rgba(123,63,242,0.14)"
          : "0 4px 20px rgba(123,63,242,0.06)",
      }}
      onMouseEnter={(e) => {
        if (!expanded) {
          e.currentTarget.style.borderColor = "#7b3ff2";
          e.currentTarget.style.boxShadow =
            "0 0 0 3px rgba(123,63,242,0.14), 0 8px 26px rgba(123,63,242,0.12)";
          e.currentTarget.style.transform = "translateY(-2px)";
        }
      }}
      onMouseLeave={(e) => {
        if (!expanded) {
          e.currentTarget.style.borderColor = awaitingReview
            ? "rgba(234,88,12,0.28)"
            : "rgba(123,63,242,0.09)";
          e.currentTarget.style.boxShadow = "0 4px 20px rgba(123,63,242,0.06)";
          e.currentTarget.style.transform = "none";
        }
      }}
    >
      {/* ── Header row ── */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          gap: "10px",
        }}
      >
        <div>
          <span
            style={{
              display: "block",
              fontSize: "0.68rem",
              fontWeight: 900,
              letterSpacing: "0.1em",
              color: "#7b3ff2",
              marginBottom: "4px",
            }}
          >
            {request.category?.toUpperCase() || "SERVICE REQUEST"}
          </span>
          <h4
            style={{
              margin: 0,
              fontSize: "1.06rem",
              color: "#0f172a",
              lineHeight: 1.3,
              fontWeight: 700,
            }}
          >
            {request.serviceType}
          </h4>
        </div>
        <StatusPill status={request.status} />
      </div>

      {/* ── Customer ── */}
      <div style={{ display: "flex", flexDirection: "column", gap: "2px" }}>
        <strong style={{ fontSize: "0.95rem", color: "#111827" }}>
          {request.user?.name || request.assignedTo || "Customer"}
        </strong>
        <span style={{ fontSize: "0.83rem", color: "rgba(15,23,42,0.6)" }}>
          {request.user?.email || ""}
        </span>
      </div>

      {/* ── Description snippet ── */}
      {request.description && (
        <p
          style={{
            margin: 0,
            padding: "10px 13px",
            borderRadius: "12px",
            background: "rgba(123,63,242,0.04)",
            lineHeight: 1.6,
            fontSize: "0.88rem",
            color: "rgba(15,23,42,0.72)",
          }}
        >
          {request.description}
        </p>
      )}

      {/* ── Meta strip (Vendor + Verification) ── */}
      <MetaStrip
        vendor={request.assignedVendor}
        awaitingReview={awaitingReview}
        sentToAdmin={sentToAdmin}
        isApproved={isApproved}
      />

      {/* ── Photo count chips ── */}
      {(beforePhotos.length > 0 || afterPhotos.length > 0) && (
        <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
          {beforePhotos.length > 0 && (
            <span
              style={{
                padding: "4px 10px",
                borderRadius: "999px",
                fontSize: "0.76rem",
                fontWeight: 700,
                background: "rgba(123,63,242,0.09)",
                color: "#7b3ff2",
              }}
            >
              📷 {beforePhotos.length} before
            </span>
          )}
          {afterPhotos.length > 0 && (
            <span
              style={{
                padding: "4px 10px",
                borderRadius: "999px",
                fontSize: "0.76rem",
                fontWeight: 700,
                background: "rgba(22,163,74,0.1)",
                color: "#16a34a",
              }}
            >
              ✅ {afterPhotos.length} after
            </span>
          )}
        </div>
      )}

      {/* ── Status banners (non-expanded) ── */}
      {!expanded && sentToAdmin && (
        <div
          style={{
            padding: "10px 14px",
            borderRadius: "12px",
            fontSize: "0.85rem",
            fontWeight: 600,
            background: "#e0f2fe",
            color: "#0369a1",
            border: "1px solid rgba(2,132,199,0.18)",
          }}
        >
          📤 Sent to admin for final approval
        </div>
      )}
      {!expanded && isApproved && (
        <div
          style={{
            padding: "10px 14px",
            borderRadius: "12px",
            fontSize: "0.85rem",
            fontWeight: 600,
            background: "#dcfce7",
            color: "#15803d",
            border: "1px solid rgba(22,163,74,0.18)",
          }}
        >
          ✅ Admin approved — job completed
        </div>
      )}
      {!expanded && awaitingReview && (
        <div
          style={{
            padding: "10px 14px",
            borderRadius: "12px",
            fontSize: "0.85rem",
            fontWeight: 600,
            background: "#fff7ed",
            color: "#c2410c",
            border: "1px solid rgba(234,88,12,0.18)",
          }}
        >
          ⚠️ Vendor submitted work — verify before escalating
        </div>
      )}

      {/* ── Action row ── */}
      <div
        style={{
          display: "flex",
          gap: "8px",
          alignItems: "center",
          flexWrap: "wrap",
        }}
      >
        {/* Manage / Close toggle */}
        <button
          onClick={() => setExpanded((v) => !v)}
          style={{
            marginLeft: "auto",
            padding: "9px 16px",
            border: "none",
            borderRadius: "12px",
            cursor: "pointer",
            fontWeight: 700,
            fontSize: "0.88rem",
            background: expanded
              ? "rgba(123,63,242,0.18)"
              : "rgba(123,63,242,0.09)",
            color: "#7b3ff2",
            display: "inline-flex",
            alignItems: "center",
            gap: "6px",
            transition: "background 0.2s",
          }}
          onMouseEnter={(e) =>
            (e.currentTarget.style.background = "rgba(123,63,242,0.22)")
          }
          onMouseLeave={(e) =>
            (e.currentTarget.style.background = expanded
              ? "rgba(123,63,242,0.18)"
              : "rgba(123,63,242,0.09)")
          }
        >
          {expanded ? "✕ Close" : "⚙ Manage"}
        </button>
      </div>

      {/* ── Manage Panel (inline expand) ── */}
      {expanded && (
        <ManagePanel
          request={request}
          onUploadPhoto={onUploadPhoto}
          onAddNote={onAddNote}
          noteInputs={noteInputs}
          setNoteInputs={setNoteInputs}
          onVerify={onVerify}
        />
      )}
    </article>
  );
}

/* STAFF DASHBOARD */
function StaffDashboard() {
  const { activeTab, setRequests: setLayoutRequests } = useOutletContext();

  const [requests, setRequests] = useState([]);
  const [noteInputs, setNoteInputs] = useState({});
  const { staff } = useStaffAuth();

  const fetchRequests = useCallback(async () => {
    try {
      const token = localStorage.getItem("staffToken");
      const { data } = await API.get("/staff/requests", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setRequests(data);
      setLayoutRequests(data);
    } catch {
      toast.error("Failed to load requests");
    }
  }, [setLayoutRequests]);

  useEffect(() => {
    const init = async () => {
      await fetchRequests();
    };

    init();

    socket.on("request-updated", fetchRequests);

    return () => {
      socket.off("request-updated", fetchRequests);
    };
  }, [fetchRequests]);

  const filteredRequests =
    activeTab === "all"
      ? requests
      : requests.filter((r) => r.status === activeTab);

  /* ── Actions ── */
  const verifyAndSendToAdmin = async (id) => {
    try {
      const token = localStorage.getItem("staffToken");
      const { data } = await API.put(
        `/staff/requests/${id}`,
        { status: "completed" },
        { headers: { Authorization: `Bearer ${token}` } },
      );
      const updated = requests.map((r) => (r._id === id ? data : r));
      setRequests(updated);
      setLayoutRequests(updated);
      toast.success("Sent to admin for approval");
    } catch {
      toast.error("Failed to verify");
    }
  };

  const uploadPhoto = async (id, formData) => {
    const token = localStorage.getItem("staffToken");
    const { data } = await API.post(`/staff/requests/${id}/photos`, formData, {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "multipart/form-data",
      },
    });
    const updated = requests.map((r) => (r._id === id ? data : r));
    setRequests(updated);
    setLayoutRequests(updated);
  };

  const addNote = async (id) => {
    const note = noteInputs[id]?.trim();
    if (!note) return toast.error("Enter a note first");
    try {
      const token = localStorage.getItem("staffToken");
      const { data } = await API.post(
        `/staff/requests/${id}/notes`,
        { note },
        { headers: { Authorization: `Bearer ${token}` } },
      );
      const updated = requests.map((r) => (r._id === id ? data : r));
      setRequests(updated);
      setLayoutRequests(updated);
      setNoteInputs((prev) => ({ ...prev, [id]: "" }));
      toast.success("Note added");
    } catch {
      toast.error("Failed to add note");
    }
  };

  /* ── Empty state ── */
  if (filteredRequests.length === 0) {
    return (
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          minHeight: "480px",
          textAlign: "center",
          padding: "48px 24px",
          border: "2px dashed rgba(123,63,242,0.15)",
          borderRadius: "28px",
          background: "rgba(255,255,255,0.6)",
        }}
      >
        <div style={{ fontSize: "3rem", marginBottom: "16px" }}>👨‍⚕️</div>
        <h4
          style={{ fontSize: "1.25rem", color: "#1e293b", margin: "0 0 10px" }}
        >
          {activeTab === "all"
            ? "No Assigned Requests"
            : activeTab === "in-progress"
              ? "No Requests In Progress"
              : "No Completed Requests"}
        </h4>
        <p
          style={{
            color: "rgba(15,23,42,0.55)",
            maxWidth: "260px",
            lineHeight: 1.6,
            margin: 0,
          }}
        >
          {activeTab === "all"
            ? "Requests assigned by admin will appear here automatically."
            : "Switch tabs to view other requests."}
        </p>
      </div>
    );
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "28px" }}>
      {/* ── Hero stat bar ── */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          gap: "24px",
          padding: "32px 38px",
          borderRadius: "32px",
          flexWrap: "wrap",
          ...GLASS,
        }}
      >
        <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
          <span
            style={{
              fontSize: "0.72rem",
              fontWeight: 900,
              letterSpacing: "0.12em",
              color: "#7c3aed",
              background: "rgba(124,58,237,0.08)",
              padding: "5px 12px",
              borderRadius: "999px",
              display: "inline-block",
            }}
          >
            STAFF PORTAL
          </span>
          <h1
            style={{
              fontSize: "clamp(1.8rem,3vw,2.6rem)",
              color: "#0f172a",
              margin: 0,
              lineHeight: 1.1,
              fontWeight: 800,
            }}
          >
            Welcome, {staff?.name}
          </h1>
          <p
            style={{
              color: "rgba(15,23,42,0.6)",
              margin: 0,
              lineHeight: 1.6,
              maxWidth: "480px",
            }}
          >
            Collaborate with vendors, upload job evidence and escalate to admin.
          </p>
        </div>

        <div
          style={{
            display: "flex",
            gap: "14px",
            flexShrink: 0,
            flexWrap: "wrap",
          }}
        >
          {[
            { label: "Assigned", value: requests.length },
            {
              label: "In Progress",
              value: requests.filter((r) => r.status === "in-progress").length,
            },
            {
              label: "Completed",
              value: requests.filter((r) => r.status === "completed").length,
            },
          ].map(({ label, value }) => (
            <div
              key={label}
              style={{
                minWidth: "110px",
                padding: "18px 22px",
                borderRadius: "20px",
                background: "rgba(255,255,255,0.75)",
                textAlign: "center",
                border: "1px solid rgba(123,63,242,0.09)",
              }}
            >
              <span
                style={{
                  display: "block",
                  fontSize: "0.72rem",
                  color: "rgba(15,23,42,0.55)",
                  fontWeight: 600,
                  textTransform: "uppercase",
                  letterSpacing: "0.04em",
                  marginBottom: "6px",
                }}
              >
                {label}
              </span>
              <strong
                style={{ fontSize: "2rem", color: "#7c3aed", lineHeight: 1 }}
              >
                {value}
              </strong>
            </div>
          ))}
        </div>
      </div>

      {/* ── Card grid panel ── */}
      <div style={{ padding: "32px", borderRadius: "28px", ...GLASS }}>
        <div style={{ marginBottom: "24px" }}>
          <h2
            style={{
              margin: "0 0 6px",
              fontSize: "1.3rem",
              color: "#0f172a",
              fontWeight: 700,
            }}
          >
            {activeTab === "all"
              ? "All Assigned Requests"
              : activeTab === "in-progress"
                ? "In Progress Requests"
                : "Completed Requests"}
          </h2>
          <p
            style={{
              margin: 0,
              color: "rgba(15,23,42,0.5)",
              fontSize: "0.88rem",
            }}
          >
            Upload before/after photos, add notes and escalate verified work to
            admin.
          </p>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(330px, 1fr))",
            gap: "20px",
          }}
        >
          {filteredRequests.map((request) => (
            <RequestCard
              key={request._id}
              request={request}
              onVerify={verifyAndSendToAdmin}
              onUploadPhoto={uploadPhoto}
              onAddNote={addNote}
              noteInputs={noteInputs}
              setNoteInputs={setNoteInputs}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

export default StaffDashboard;

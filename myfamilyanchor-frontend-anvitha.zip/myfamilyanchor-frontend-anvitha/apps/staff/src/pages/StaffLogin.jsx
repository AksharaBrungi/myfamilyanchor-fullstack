import { useState } from "react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import API from "@api/axios";
import { useStaffAuth } from "@auth/StaffAuthContext";
import PasswordInput from "@ui/PasswordInput";
import ForgotPasswordModal from "@ui/ForgotPasswordModal";

function StaffLogin() {
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [showForgot, setShowForgot] = useState(false);
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();
  const { login } = useStaffAuth();

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      setLoading(true);

      const { data } = await API.post("/staff-auth/login", {
        identifier,
        password,
      });

      await login(data.token);

      toast.success("Welcome");

      navigate("/staff/dashboard");
    } catch (error) {
      toast.error(error.response?.data?.message || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  const inputCls = `
w-full
h-[64px]
px-6
pr-[74px]
rounded-[18px]
border
border-[rgba(148,163,184,0.18)]
bg-[rgba(255,255,255,0.82)]
text-[16px]
text-slate-900
placeholder:text-slate-400
transition-all
duration-300
focus:outline-none
focus:border-[#7b3ff2]
focus:ring-4
focus:ring-[rgba(123,63,242,0.08)]
`;

  return (
    <section className="[min-height:calc(100vh_-_160px)] [display:flex] [align-items:center] [justify-content:center] [padding:60px_24px] max-[640px]:[padding:40px_18px]">
      <form
        className="
          relative
          overflow-hidden
          w-full
          max-w-[560px]
          rounded-[30px]
          border
        border-white/80
        bg-white/75
          backdrop-blur-2xl
          shadow-[0_30px_80px_rgba(123,63,242,0.12)]
          px-12
          py-11
          flex
          flex-col
          gap-5

          before:absolute
          before:-right-24
          before:-top-24
          before:h-72
          before:w-72
          before:rounded-full
          before:bg-[radial-gradient(circle,rgba(123,63,242,0.14),transparent_70%)]
          before:pointer-events-none

          max-md:px-7
          max-md:py-8
          max-md:rounded-[24px]
        "
        onSubmit={handleSubmit}
      >
        <div className="relative z-10 mb-2">
          <span className="text-[13px] font-extrabold uppercase tracking-[0.24em] text-[#7b3ff2]">
            Service Team Portal
          </span>

          <h1 className="mt-3 text-[56px] leading-[1.02] font-semibold tracking-[-0.03em] text-slate-900">
            Staff Login
          </h1>

          <p className="mt-4 text-[16px] leading-7 text-slate-500 max-w-[420px]">
            Access assigned requests, customer details and service updates.
          </p>
        </div>

        <input
          className={inputCls}
          type="text"
          placeholder="Email or Phone Number"
          value={identifier}
          onChange={(e) => setIdentifier(e.target.value)}
          required
        />

        <PasswordInput
          className={inputCls}
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />

        <button
          type="button"
          className="
            self-end
            text-[14px]
            font-semibold
          text-[#7b3ff2]
            transition-all
            duration-300
          hover:text-[#ff5ca8]
            hover:underline
            underline-offset-4
"
          onClick={() => setShowForgot(true)}
        >
          Forgot Password?
        </button>

        <button
          type="submit"
          className="
            h-[64px]
            w-full
            rounded-[18px]
            font-bold
            text-lg
          text-white
            bg-[linear-gradient(135deg,#7b3ff2,#ff5ca8,#ff9b54)]
            shadow-[0_22px_45px_rgba(123,63,242,0.25)]
            transition-all
            duration-300
            hover:-translate-y-[2px]
            hover:shadow-[0_28px_55px_rgba(123,63,242,0.35)]
            active:translate-y-0
          "
          disabled={loading}
        >
          {loading ? "Logging in..." : "Login"}
        </button>
      </form>

      {showForgot && (
        <ForgotPasswordModal
          role="staff"
          onClose={() => setShowForgot(false)}
        />
      )}
    </section>
  );
}

export default StaffLogin;

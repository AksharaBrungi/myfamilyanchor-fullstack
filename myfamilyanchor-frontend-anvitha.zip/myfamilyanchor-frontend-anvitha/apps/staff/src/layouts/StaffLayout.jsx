import { Outlet, useNavigate } from "react-router-dom";
import { useState, useEffect, useMemo } from "react";
import { FiMenu, FiX } from "react-icons/fi";
import StaffSidebar from "../components/StaffSidebar";
import LogoutModal from "@ui/LogoutModal";

const PAGE_BG =
  "bg-[radial-gradient(circle_at_24%_0%,rgba(255,92,168,0.12),transparent_30%),radial-gradient(circle_at_88%_4%,rgba(255,155,84,0.14),transparent_28%),linear-gradient(180deg,#fff8fc_0%,#f8f3ff_52%,#ffffff_100%)]";

export default function StaffLayout() {
  const [showLogoutModal, setShowLogoutModal] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("all");
  const [requests, setRequests] = useState([]);
  const navigate = useNavigate();

  const outletContext = useMemo(
    () => ({
      activeTab,
      setActiveTab,
      setRequests,
    }),
    [activeTab, setRequests],
  );

  const handleLogout = () => {
    localStorage.removeItem("staffToken");
    localStorage.removeItem("staffData");
    sessionStorage.clear();
    navigate("/staff/login", { replace: true });
  };

  // Lock body scroll when drawer is open
  useEffect(() => {
    document.body.style.overflow = drawerOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [drawerOpen]);

  // Close drawer on Escape
  useEffect(() => {
    const handleKey = (e) => {
      if (e.key === "Escape") setDrawerOpen(false);
    };
    document.addEventListener("keydown", handleKey);
    return () => document.removeEventListener("keydown", handleKey);
  }, []);

  const sidebarProps = {
    activeTab,
    onTabChange: setActiveTab,
    requests,
    onLogoutClick: () => setShowLogoutModal(true),
  };

  return (
    <div
      className={`flex min-h-screen items-stretch ${PAGE_BG} lg:h-screen lg:max-h-screen lg:overflow-hidden`}
    >
      <LogoutModal
        open={showLogoutModal}
        onClose={() => setShowLogoutModal(false)}
        onConfirm={handleLogout}
      />

      {/* Desktop sidebar — left side */}
      <div className="hidden lg:flex">
        <StaffSidebar {...sidebarProps} />
      </div>

      {/* Mobile right-side drawer overlay */}
      <div
        className={`fixed inset-0 z-[999] transition-all duration-300 lg:hidden ${
          drawerOpen
            ? "visible opacity-100"
            : "invisible opacity-0 pointer-events-none"
        }`}
      >
        {/* Backdrop */}
        <div
          className="absolute inset-0 bg-black/40 backdrop-blur-sm"
          onClick={() => setDrawerOpen(false)}
          aria-hidden="true"
        />

        {/* Drawer panel — slides from RIGHT */}
        <div
          className={`absolute right-0 top-0 h-full w-[280px] max-w-[85vw] overflow-y-auto shadow-2xl transition-transform duration-300 ${
            drawerOpen ? "translate-x-0" : "translate-x-full"
          }`}
        >
          {/* Close button */}
          <div className="flex justify-start bg-white/95 p-3">
            <button
              type="button"
              onClick={() => setDrawerOpen(false)}
              className="flex h-9 w-9 items-center justify-center rounded-xl text-slate-500 transition hover:bg-slate-100 hover:text-slate-800"
              aria-label="Close menu"
            >
              <FiX size={20} />
            </button>
          </div>
          <StaffSidebar
            {...sidebarProps}
            onClose={() => setDrawerOpen(false)}
            onLogoutClick={() => {
              setDrawerOpen(false);
              setShowLogoutModal(true);
            }}
          />
        </div>
      </div>

      {/* Main content */}
      <main className="flex min-h-screen flex-1 flex-col overflow-y-auto px-8 py-9 lg:h-screen max-lg:px-4 max-lg:py-5">
        {/* Mobile top bar */}
        <header className="mb-6 flex h-14 items-center justify-between rounded-2xl border border-white/60 bg-white/80 px-4 backdrop-blur-xl lg:hidden">
          {/* Left spacer */}
          <div className="w-9" aria-hidden="true" />

          <span className="font-black text-[#111827]">Staff Portal</span>

          {/* Hamburger on the RIGHT */}
          <button
            type="button"
            onClick={() => setDrawerOpen(true)}
            className="flex h-9 w-9 items-center justify-center rounded-xl text-slate-600 transition hover:bg-slate-100"
            aria-label="Open menu"
          >
            <FiMenu size={20} />
          </button>
        </header>

        {/* Pass activeTab + setRequests down via context or Outlet context */}
        <Outlet context={outletContext} />
      </main>
    </div>
  );
}

import { useStaffAuth } from "@auth/StaffAuthContext";
import { FiClipboard, FiLoader, FiCheckCircle, FiLogOut } from "react-icons/fi";

const TABS = [
  { key: "all", label: "All Requests", icon: FiClipboard, statusKey: null },
  {
    key: "in-progress",
    label: "In Progress",
    icon: FiLoader,
    statusKey: "in-progress",
  },
  {
    key: "completed",
    label: "Completed",
    icon: FiCheckCircle,
    statusKey: "completed",
  },
];

export default function StaffSidebar({
  activeTab,
  onTabChange,
  onLogoutClick,
  requests = [],
  onClose, // called after tab change on mobile so drawer can close
}) {
  const { staff } = useStaffAuth();

  const getCount = (statusKey) =>
    statusKey === null
      ? requests.length
      : requests.filter((r) => r.status === statusKey).length;

  const handleTabClick = (key) => {
    if (typeof onTabChange === "function") onTabChange(key);
    if (typeof onClose === "function") onClose();
  };

  return (
    <aside className="flex h-full w-[280px] shrink-0 flex-col gap-6 overflow-y-auto border-l border-[rgba(123,63,242,0.08)] bg-gradient-to-b from-[rgba(255,255,255,0.98)] to-[rgba(255,248,252,0.90)] px-5 py-7 shadow-[-4px_0_32px_rgba(123,63,242,0.06)] backdrop-blur-xl lg:h-screen lg:border-r lg:border-l-0 lg:shadow-[4px_0_32px_rgba(123,63,242,0.06)]">
      {/* Brand */}
      <div className="flex shrink-0 flex-col gap-[22px]">
        <div className="flex items-center gap-3.5">
          <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-[#7b3ff2] via-[#ff5ca8] to-[#ff9b54] text-lg font-bold text-white shadow-[0_12px_28px_rgba(123,63,242,0.22)]">
            ⚡
          </div>
          <div>
            <h2 className="mb-0.5 text-[1.05rem] font-semibold leading-tight text-[#111827]">
              MyFamilyAnchor
            </h2>
            <p className="text-[0.74rem] text-[#6b7280]">Staff Portal</p>
          </div>
        </div>

        {/* User card */}
        <div className="flex shrink-0 items-center gap-3 rounded-[22px] border border-white/80 bg-white/72 px-4 py-4 shadow-[0_8px_28px_rgba(123,63,242,0.10)] backdrop-blur-xl">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-[#7b3ff2] to-[#ff5ca8] text-[1.05rem] font-extrabold text-white">
            {staff?.name?.charAt(0)?.toUpperCase() || "S"}
          </div>
          <div className="min-w-0">
            <h3 className="mb-0.5 overflow-hidden text-ellipsis whitespace-nowrap text-base font-semibold text-[#111827]">
              {staff?.name || "Staff Member"}
            </h3>
            <span className="capitalize text-[0.8rem] text-[#6b7280]">
              {staff?.role || "Staff"}
            </span>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex shrink-0 flex-col gap-1">
        {TABS.map(({ key, label, icon: Icon, statusKey }) => {
          const count = getCount(statusKey);
          const isActive = activeTab === key;
          return (
            <button
              key={key}
              type="button"
              onClick={() => handleTabClick(key)}
              className={`relative flex min-h-[52px] w-full cursor-pointer items-center gap-3 rounded-2xl border-none px-[18px] font-[inherit] text-[0.92rem] font-extrabold transition-[background,color,box-shadow] duration-[220ms] ease-in-out ${
                isActive
                  ? "bg-[rgba(123,63,242,0.08)] text-[#7b3ff2] shadow-[0_8px_24px_rgba(123,63,242,0.07)]"
                  : "bg-transparent text-[#374151] hover:bg-[rgba(123,63,242,0.08)] hover:text-[#7b3ff2]"
              }`}
            >
              {isActive && (
                <span className="absolute left-2 h-5 w-1 rounded-full bg-gradient-to-b from-[#7b3ff2] to-[#ff5ca8]" />
              )}
              <Icon size={18} />
              <span className="flex-1 text-left">{label}</span>
              <span
                className={`flex h-6 min-w-[24px] items-center justify-center rounded-full px-2 text-[0.72rem] font-black transition-all duration-200 ${
                  isActive
                    ? "bg-gradient-to-r from-[#7b3ff2] to-[#ff5ca8] text-white"
                    : count > 0
                      ? "bg-[rgba(123,63,242,0.12)] text-[#7b3ff2]"
                      : "bg-slate-100 text-slate-400"
                }`}
              >
                {count}
              </span>
            </button>
          );
        })}

        <button
          type="button"
          onClick={onLogoutClick}
          className="flex min-h-[52px] w-full cursor-pointer items-center gap-3 rounded-2xl border-none bg-transparent px-[18px] font-[inherit] text-[0.92rem] font-extrabold text-[#6b7280] transition-[background,color] duration-[220ms] ease-in-out hover:bg-[rgba(220,38,38,0.07)] hover:text-[#dc2626]"
        >
          <FiLogOut size={18} />
          Logout
        </button>
      </nav>
    </aside>
  );
}
